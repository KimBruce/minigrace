;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["bind"] = "classes:\nconfidential:\n a\n x\n x:=(x': Number) \u2192 Done\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/bind.grace\npublic:\n A\npublicMethodTypes:\ntypedec-of:A:\n type A = interface {\n            y \u2192 Number\n            y:=(s:Number) \u2192 Done}\ntypes:\n A\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["bind"] = [
    "dialect \"StaticTyping\"",
    "",
    "type A = {",
    "    y → Number",
    "    y:= (s: Number) → Done",
    "}",
    "",
    "def a: A = object {",
    "    var y: Number is public := 0",
    "    y:= 1",
    "}",
    "",
    "a.y := 3",
    "print (a.y)",
    "",
    "var x: Number := 1",
    "self.x := self.x + 22",
    "print(x)" ];
}
function gracecode_bind() {
  setModuleName("bind");
  importedModules["bind"] = this;
  var module$bind = this;
  this.definitionModule = "bind";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_bind_0");
  this.outer_bind_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(3);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit1 = new GraceType("A");
  typeLit1.typeMethods.push("y");
  typeLit1.typeMethods.push("y:=(1)");
  var var_A = typeLit1;
  var type0 = typeLit1;
  var func2 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 1;
  func2.definitionModule = "bind";
  setLineNumber(8);    // compilenode object
  var obj3_build = function(ignore, outerObj, aliases, exclusions) {
    this.closureKeys = this.closureKeys || [];
    this.closureKeys.push("outer_bind_8");
    this.outer_bind_8 = outerObj;
    var inheritedExclusions = { };
    for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
        var exMeth = exclusions[eix];
        inheritedExclusions[exMeth] = this.methods[exMeth];
    }
    this.data.y = undefined;
    var reader4_y = function() {  // reader method y
        if (this.data.y === undefined) raiseUninitializedVariable("y");
        return this.data.y;
    };
    reader4_y.isVar = true;
    this.methods["y"] = reader4_y;
    var writer5_y = function(argcv, n) {   // writer method y:=(_)
      assertTypeOrMsg(n, var_Number, "argument to y:=(_)", "Number");
      this.data.y = n;
      return GraceDone;
    };
    this.methods["y:=(1)"] = writer5_y;
    this.mutable = true;
    for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
        var oneAlias = aliases[aix];
        this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
    }
    for (var exName in inheritedExclusions) {
        if (inheritedExclusions.hasOwnProperty(exName)) {
            if (inheritedExclusions[exName]) {
                this.methods[exName] = inheritedExclusions[exName];
            } else {
                delete this.methods[exName];
            }
        }
    }
    var obj3_init = function() {    // init of object on line 8
      setModuleName("bind");
      setLineNumber(9);    // typecheck
      assertTypeOrMsg(new GraceNum(0), var_Number, "value assigned to y", "Number");
      this.data.y = new GraceNum(0);
      setLineNumber(10);    // compilenode num
      // call case 4: self request
      var call6 = selfRequest(this, "y:=(1)", [1], new GraceNum(1));
    };
    return obj3_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
  };
  var obj3 = emptyGraceObject("a", "bind", 8);
  var obj3_init = obj3_build.call(obj3, null, this, [], []);
  obj3_init.call(obj3);  // end of compileobject
  var var_a = obj3;
  var reader7_a = function() {  // reader method a
      if (var_a === undefined) raiseUninitializedVariable("a");
      return var_a;
  };
  reader7_a.isDef = true;
  reader7_a.confidential = true;
  this.methods["a"] = reader7_a;
  setLineNumber(8);    // typecheck
  assertTypeOrMsg(var_a, var_A, "value of def a", "A");
  setLineNumber(13);    // compilenode num
  // call case 6: other requests
  if (var_a === undefined) raiseUninitializedVariable("a");
  var call8 = request(var_a, "y:=(1)", [1], new GraceNum(3));
  setLineNumber(14);    // compilenode member
  // call case 6: other requests
  if (var_a === undefined) raiseUninitializedVariable("a");
  var call9 = request(var_a, "y", [0]);
  Grace_print(call9);
  setLineNumber(16);    // typecheck
  assertTypeOrMsg(new GraceNum(1), var_Number, "initial value of var x", "Number");
  var var_x = new GraceNum(1);
  var reader10_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader10_x.isVar = true;
  reader10_x.confidential = true;
  this.methods["x"] = reader10_x;
  var writer11_x = function(argcv, n) {   // writer method x:=(_)
    assertTypeOrMsg(n, var_Number, "argument to x:=(_)", "Number");
    var_x = n;
    return GraceDone;
  };
  writer11_x.confidential = true;
  this.methods["x:=(1)"] = writer11_x;
  setLineNumber(17);    // compilenode member
  // call case 4: self request
  var call13 = selfRequest(this, "x", [0]);
  var sum14 = request(call13, "+(1)", [1], new GraceNum(22));
  // call case 4: self request
  var call12 = selfRequest(this, "x:=(1)", [1], sum14);
  setLineNumber(18);    // compilenode call
  Grace_print(var_x);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_bind = gracecode_bind;
if (typeof window !== "undefined")
  window.gracecode_bind = gracecode_bind;
gracecode_bind.imports = ["StaticTyping"];
