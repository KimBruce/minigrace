;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["Init_test"] = "classes:\n a\nconfidential:\n a\n aa\n b\n s\n s:=(s': String) \u2192 Done\nconstructors-of:a:\n new(1)\ndialect:\n StaticTyping\nfresh-methods:\n new(1)\nfresh:new(1):\nmethods-of:a.new(1):\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/Init_test.grace\npublic:\n A\n Object\n new(1)\npublicMethod:new(1):\n new(arg:String) \u2192 Object\npublicMethodTypes:\n new(arg:String) \u2192 Object\ntypedec-of:A:\n type A = interface {\n            new(arg:String) \u2192 Object}\ntypedec-of:Object:\n type Object = interface {}\ntypes:\n A\n Object\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["Init_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "var s: String := \"a\"",
    "",
    "type Object = {}",
    "",
    "type A = {",
    "    new(arg:String) → Object",
    "}",
    "",
    "def aa: Object = object {",
    "    method new → Number {4}",
    "}",
    "",
    "def b: Object = object {",
    "    s := s ++ \"object b \"",
    "}",
    "",
    "method new(arg:String) → Object {",
    "    object {",
    "        s := s ++ \"object a ({arg})\"",
    "    }",
    "}",
    "",
    "def a:A = object {",
    "    method new(arg:String) → Object {",
    "        object {",
    "            s := s ++ \"object a ({arg})\"",
    "        }",
    "    }",
    "    method asString → String { \"a\" }",
    "}",
    "",
    "print \"test succeeded\"" ];
}
function gracecode_Init__95__test() {
  setModuleName("Init_test");
  importedModules["Init_test"] = this;
  var module$Init__95__test = this;
  this.definitionModule = "Init_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_Init__95__test_0");
  this.outer_Init__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv, var_arg) {    // method new(_), line 19
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_arg, var_String, "argument to request of `new(_)`", "String");
    var ouc = emptyGraceObject("new(_)", "Init_test", 19);
    var ouc_init = this.methods["new(1)$build(3)"].call(this, null, var_arg, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(23);    // typecheck
    assertTypeOrMsg(ouc, var_Object, "object returned from new(_)", "Object");
    return ouc;
  };    // end of method new(_)
  func0.paramTypes = [];
  func0.paramTypes.push([type_String, "arg"]);
  this.methods["new(1)"] = func0;
  func0.paramCounts = [1];
  func0.paramNames = ["arg"];
  func0.typeParamNames = [];
  func0.definitionLine = 19;
  func0.definitionModule = "Init_test";
  var func1 = function(argcv, var_arg, inheritingObject, aliases, exclusions) {    // method new(_)$build(_,_,_), line 19
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_arg, var_String, "argument to request of `new(_)`", "String");
    var obj2_build = function(ignore, var_arg, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_Init__95__test_20");
      this.outer_Init__95__test_20 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 20
        setModuleName("Init_test");
        setLineNumber(21);    // compilenode op
        if (var_s === undefined) raiseUninitializedVariable("s");
        var string3 = new GraceString("object a (");
        var opresult4 = request(string3, "++(1)", [1], var_arg);
        var string5 = new GraceString(")");
        var opresult6 = request(opresult4, "++(1)", [1], string5);
        var opresult7 = request(var_s, "++(1)", [1], opresult6);
        var_s = opresult7;
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, var_arg, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method new(_)$build(_,_,_)
  func1.paramTypes = [];
  func1.paramTypes.push([type_String, "arg"]);
  this.methods["new(1)$build(3)"] = func1;
  func1.paramCounts = [1];
  func1.paramNames = ["arg"];
  func1.typeParamNames = [];
  func1.definitionLine = 19;
  func1.definitionModule = "Init_test";
  setLineNumber(3);    // compilenode string
  var string8 = new GraceString("a");
  assertTypeOrMsg(string8, var_String, "initial value of var s", "String");
  var var_s = string8;
  var reader9_s = function() {  // reader method s
      if (var_s === undefined) raiseUninitializedVariable("s");
      return var_s;
  };
  reader9_s.isVar = true;
  reader9_s.confidential = true;
  this.methods["s"] = reader9_s;
  var writer10_s = function(argcv, n) {   // writer method s:=(_)
    assertTypeOrMsg(n, var_String, "argument to s:=(_)", "String");
    var_s = n;
    return GraceDone;
  };
  writer10_s.confidential = true;
  this.methods["s:=(1)"] = writer10_s;
  setLineNumber(5);    // compilenode typedec
  // Type decl Object
  //   Type literal 
  var typeLit12 = new GraceType("Object");
  var var_Object = typeLit12;
  var type11 = typeLit12;
  var func13 = function(argcv) {     // accessor method Object
    return var_Object;
  };    // end of method Object
  this.methods["Object"] = func13;
  func13.paramCounts = [0];
  func13.paramNames = [];
  func13.typeParamNames = [];
  func13.definitionLine = 1;
  func13.definitionModule = "Init_test";
  setLineNumber(7);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit15 = new GraceType("A");
  typeLit15.typeMethods.push("new(1)");
  var var_A = typeLit15;
  var type14 = typeLit15;
  var func16 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func16;
  func16.paramCounts = [0];
  func16.paramNames = [];
  func16.typeParamNames = [];
  func16.definitionLine = 1;
  func16.definitionModule = "Init_test";
  setLineNumber(11);    // compilenode object
  var obj17_build = function(ignore, outerObj, aliases, exclusions) {
    this.closureKeys = this.closureKeys || [];
    this.closureKeys.push("outer_Init__95__test_11");
    this.outer_Init__95__test_11 = outerObj;
    var inheritedExclusions = { };
    for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
        var exMeth = exclusions[eix];
        inheritedExclusions[exMeth] = this.methods[exMeth];
    }
    var func18 = function(argcv) {    // method new, line 12
      var returnTarget = invocationCount;
      invocationCount++;
      setModuleName("Init_test");
      setLineNumber(12);    // typecheck
      assertTypeOrMsg(new GraceNum(4), var_Number, "result of method new", "Number");
      return new GraceNum(4);
    };    // end of method new
    this.methods["new"] = func18;
    func18.paramCounts = [0];
    func18.paramNames = [];
    func18.typeParamNames = [];
    func18.definitionLine = 12;
    func18.definitionModule = "Init_test";
    for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
        var oneAlias = aliases[aix];
        this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
    }
    for (var exName in inheritedExclusions) {
        if (inheritedExclusions.hasOwnProperty(exName)) {
            if (inheritedExclusions[exName]) {
                this.methods[exName] = inheritedExclusions[exName];
            } else {
                delete this.methods[exName];
            }
        }
    }
    var obj17_init = function() {    // init of object on line 11
      setModuleName("Init_test");
    };
    return obj17_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
  };
  var obj17 = emptyGraceObject("aa", "Init_test", 11);
  var obj17_init = obj17_build.call(obj17, null, this, [], []);
  obj17_init.call(obj17);  // end of compileobject
  var var_aa = obj17;
  var reader19_aa = function() {  // reader method aa
      if (var_aa === undefined) raiseUninitializedVariable("aa");
      return var_aa;
  };
  reader19_aa.isDef = true;
  reader19_aa.confidential = true;
  this.methods["aa"] = reader19_aa;
  setLineNumber(11);    // typecheck
  assertTypeOrMsg(var_aa, var_Object, "value of def aa", "Object");
  setLineNumber(15);    // compilenode object
  var obj20_build = function(ignore, outerObj, aliases, exclusions) {
    this.closureKeys = this.closureKeys || [];
    this.closureKeys.push("outer_Init__95__test_15");
    this.outer_Init__95__test_15 = outerObj;
    var inheritedExclusions = { };
    for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
        var exMeth = exclusions[eix];
        inheritedExclusions[exMeth] = this.methods[exMeth];
    }
    for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
        var oneAlias = aliases[aix];
        this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
    }
    for (var exName in inheritedExclusions) {
        if (inheritedExclusions.hasOwnProperty(exName)) {
            if (inheritedExclusions[exName]) {
                this.methods[exName] = inheritedExclusions[exName];
            } else {
                delete this.methods[exName];
            }
        }
    }
    var obj20_init = function() {    // init of object on line 15
      setModuleName("Init_test");
      setLineNumber(16);    // compilenode string
      var string21 = new GraceString("object b ");
      var opresult22 = request(var_s, "++(1)", [1], string21);
      var_s = opresult22;
    };
    return obj20_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
  };
  var obj20 = emptyGraceObject("b", "Init_test", 15);
  var obj20_init = obj20_build.call(obj20, null, this, [], []);
  obj20_init.call(obj20);  // end of compileobject
  var var_b = obj20;
  var reader23_b = function() {  // reader method b
      if (var_b === undefined) raiseUninitializedVariable("b");
      return var_b;
  };
  reader23_b.isDef = true;
  reader23_b.confidential = true;
  this.methods["b"] = reader23_b;
  setLineNumber(15);    // typecheck
  assertTypeOrMsg(var_b, var_Object, "value of def b", "Object");
  setLineNumber(25);    // compilenode object
  var obj24_build = function(ignore, outerObj, aliases, exclusions) {
    this.closureKeys = this.closureKeys || [];
    this.closureKeys.push("outer_Init__95__test_25");
    this.outer_Init__95__test_25 = outerObj;
    var inheritedExclusions = { };
    for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
        var exMeth = exclusions[eix];
        inheritedExclusions[exMeth] = this.methods[exMeth];
    }
    var func25 = function(argcv, var_arg) {    // method new(_), line 26
      var returnTarget = invocationCount;
      invocationCount++;
      assertTypeOrMsg(var_arg, var_String, "argument to request of `new(_)`", "String");
      var ouc = emptyGraceObject("a.new(_)", "Init_test", 26);
      var ouc_init = this.methods["new(1)$build(3)"].call(this, null, var_arg, ouc, [], []);
      ouc_init.call(ouc);
      setLineNumber(30);    // typecheck
      assertTypeOrMsg(ouc, var_Object, "object returned from new(_)", "Object");
      return ouc;
    };    // end of method new(_)
    func25.paramTypes = [];
    func25.paramTypes.push([type_String, "arg"]);
    this.methods["new(1)"] = func25;
    func25.paramCounts = [1];
    func25.paramNames = ["arg"];
    func25.typeParamNames = [];
    func25.definitionLine = 26;
    func25.definitionModule = "Init_test";
    var func26 = function(argcv, var_arg, inheritingObject, aliases, exclusions) {    // method new(_)$build(_,_,_), line 26
      var returnTarget = invocationCount;
      invocationCount++;
      assertTypeOrMsg(var_arg, var_String, "argument to request of `new(_)`", "String");
      var obj27_build = function(ignore, var_arg, outerObj, aliases, exclusions) {
        this.closureKeys = this.closureKeys || [];
        this.closureKeys.push("outer_Init__95__test_27");
        this.outer_Init__95__test_27 = outerObj;
        var inheritedExclusions = { };
        for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
            var exMeth = exclusions[eix];
            inheritedExclusions[exMeth] = this.methods[exMeth];
        }
        for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
            var oneAlias = aliases[aix];
            this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
        }
        for (var exName in inheritedExclusions) {
            if (inheritedExclusions.hasOwnProperty(exName)) {
                if (inheritedExclusions[exName]) {
                    this.methods[exName] = inheritedExclusions[exName];
                } else {
                    delete this.methods[exName];
                }
            }
        }
        var obj27_init = function() {    // init of object on line 27
          setModuleName("Init_test");
          setLineNumber(28);    // compilenode op
          if (var_s === undefined) raiseUninitializedVariable("s");
          var string28 = new GraceString("object a (");
          var opresult29 = request(string28, "++(1)", [1], var_arg);
          var string30 = new GraceString(")");
          var opresult31 = request(opresult29, "++(1)", [1], string30);
          var opresult32 = request(var_s, "++(1)", [1], opresult31);
          var_s = opresult32;
        };
        return obj27_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
      };
      var obj27_init = obj27_build.call(inheritingObject, null, var_arg, this, aliases, exclusions);
      return obj27_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
    };    // end of method new(_)$build(_,_,_)
    func26.paramTypes = [];
    func26.paramTypes.push([type_String, "arg"]);
    this.methods["new(1)$build(3)"] = func26;
    func26.paramCounts = [1];
    func26.paramNames = ["arg"];
    func26.typeParamNames = [];
    func26.definitionLine = 26;
    func26.definitionModule = "Init_test";
    var func33 = function(argcv) {    // method asString, line 31
      var returnTarget = invocationCount;
      invocationCount++;
      setModuleName("Init_test");
      setLineNumber(31);    // compilenode string
      var string34 = new GraceString("a");
      assertTypeOrMsg(string34, var_String, "result of method asString", "String");
      return string34;
    };    // end of method asString
    this.methods["asString"] = func33;
    func33.paramCounts = [0];
    func33.paramNames = [];
    func33.typeParamNames = [];
    func33.definitionLine = 31;
    func33.definitionModule = "Init_test";
    for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
        var oneAlias = aliases[aix];
        this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
    }
    for (var exName in inheritedExclusions) {
        if (inheritedExclusions.hasOwnProperty(exName)) {
            if (inheritedExclusions[exName]) {
                this.methods[exName] = inheritedExclusions[exName];
            } else {
                delete this.methods[exName];
            }
        }
    }
    var obj24_init = function() {    // init of object on line 25
      setModuleName("Init_test");
    };
    return obj24_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
  };
  var obj24 = emptyGraceObject("a", "Init_test", 25);
  var obj24_init = obj24_build.call(obj24, null, this, [], []);
  obj24_init.call(obj24);  // end of compileobject
  var var_a = obj24;
  var reader35_a = function() {  // reader method a
      if (var_a === undefined) raiseUninitializedVariable("a");
      return var_a;
  };
  reader35_a.isDef = true;
  reader35_a.confidential = true;
  this.methods["a"] = reader35_a;
  setLineNumber(25);    // typecheck
  assertTypeOrMsg(var_a, var_A, "value of def a", "A");
  setLineNumber(34);    // compilenode string
  var string36 = new GraceString("test succeeded");
  Grace_print(string36);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_Init__95__test = gracecode_Init__95__test;
if (typeof window !== "undefined")
  window.gracecode_Init__95__test = gracecode_Init__95__test;
gracecode_Init__95__test.imports = ["StaticTyping"];
