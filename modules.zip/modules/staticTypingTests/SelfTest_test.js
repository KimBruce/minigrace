;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["SelfTest_test"] = "classes:\nconfidential:\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/SelfTest_test.grace\npublic:\n m(1)\npublicMethod:m(1):\n m(n:Number) \u2192 Number\npublicMethodTypes:\n m(n:Number) \u2192 Number\ntypes:\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["SelfTest_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "method m(n: Number) → Number {n}",
    "",
    "print(self.m(20))" ];
}
function gracecode_SelfTest__95__test() {
  setModuleName("SelfTest_test");
  importedModules["SelfTest_test"] = this;
  var module$SelfTest__95__test = this;
  this.definitionModule = "SelfTest_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_SelfTest__95__test_0");
  this.outer_SelfTest__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv, var_n) {     // accessor method m(1)
    return var_n;
  };    // end of method m(_)
  func0.paramTypes = [];
  func0.paramTypes.push([type_Number, "n"]);
  this.methods["m(1)"] = func0;
  func0.paramCounts = [1];
  func0.paramNames = ["n"];
  func0.typeParamNames = [];
  func0.definitionLine = 3;
  func0.definitionModule = "SelfTest_test";
  setLineNumber(5);    // compilenode num
  // call case 4: self request
  var call1 = selfRequest(this, "m(1)", [1], new GraceNum(20));
  Grace_print(call1);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_SelfTest__95__test = gracecode_SelfTest__95__test;
if (typeof window !== "undefined")
  window.gracecode_SelfTest__95__test = gracecode_SelfTest__95__test;
gracecode_SelfTest__95__test.imports = ["StaticTyping"];
