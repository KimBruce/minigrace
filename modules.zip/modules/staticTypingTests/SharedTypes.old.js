;"use strict";
if (typeof gctCache !== "undefined")
  gctCache["SharedTypes.old"] = "classes:\nconfidential:\n ast\n io\n noSuchMethod\n sg\n stripNewLines(1)\n xmodule\ndialect:\nfresh-methods:\n aPatternMatchingNode(1)\n booleanPattern(1)\nfresh:aPatternMatchingNode(1):\n match(1)\nfresh:booleanPattern(1):\n match(1)\nmodules:\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/SharedTypes.old.grace\npublic:\n AndPattern\n Answer\n ArrayLiteral\n AstNode\n BasicPattern\n Bind\n Binding\n BindingPattern\n Block0\n Block1\n Block2\n BlockLiteral\n BoundsError\n Class\n Collection\n ConcurrentModification\n Def\n Dialect\n Dictionary\n Enumerable\n ExceptionKind\n Expandable\n Extractable\n FailedMatch\n Function0\n Function1\n Function2\n Function3\n Generic\n GenericType\n GenericTypeFactory\n Identifier\n If\n Import\n Inherit\n Iterable\n Iterator\n IteratorExhausted\n List\n MatchAndDestructuringPattern\n MatchCase\n MatchResult\n Member\n Method\n MethodSignature\n MethodType\n MethodTypeFactory\n MixPart\n Module\n NoSuchObject\n NumberLiteral\n ObjectLiteral\n ObjectType\n ObjectTypeFactory\n OctetsLiteral\n Operator\n OrPattern\n Outer\n Param\n ParamFactory\n Parameter\n Pattern\n Point\n Predicate0\n Predicate1\n Predicate2\n Predicate3\n Procedure0\n Procedure1\n Procedure2\n Procedure3\n Request\n RequestError\n Return\n Sequence\n Set\n Singleton\n StringLiteral\n SubobjectResponsibility\n SuccessfulMatch\n TryCatch\n TypeAnnotation\n TypeDeclaration\n TypeIntersection\n TypeLiteral\n TypeOp\n TypePair\n TypeSubtraction\n TypeUnion\n TypeVariant\n UninitializedVariable\n Var\n VariablePattern\n WildcardPattern\n aPatternMatchingNode(1)\n abstract\n alwaysEqual\n ast.AliasPair\n ast.AstNode\n ast.AstVisitor\n ast.Position\n ast.Range\n ast.SymbolTable\n ast.k.T\n ast.util.filePath.io.FileStream\n ast.util.filePath.io.IO\n ast.util.filePath.io.Process\n ast.util.io.FileStream\n ast.util.io.IO\n ast.util.io.Process\n ast.util.sys.Environment\n binding\n booleanPattern(1)\n coll.Binding\u27e6K, T\u27e7\n coll.Collection\u27e6T\u27e7\n coll.ComparableToDictionary\u27e6K, T\u27e7\n coll.Dictionary\u27e6K, T\u27e7\n coll.Enumerable\u27e6T\u27e7\n coll.Expandable\u27e6T\u27e7\n coll.Function0\u27e6ResultT\u27e7\n coll.Function1\u27e6ArgT1, ResultT\u27e7\n coll.Function2\u27e6ArgT1, ArgT2, ResultT\u27e7\n coll.Iterable\u27e6T\u27e7\n coll.Iterator\u27e6T\u27e7\n coll.List\u27e6T\u27e7\n coll.MinimalyIterable\n coll.Predicate1\u27e6ArgT1\u27e7\n coll.Procedure0\n coll.Procedure1\u27e6ArgT1\u27e7\n coll.Procedure2\u27e6ArgT1, ArgT2\u27e7\n coll.SelfType\n coll.Sequence\u27e6T\u27e7\n coll.Set\u27e6T\u27e7\n collection\n collections\n dictionary\n dictionary(1)\n do(1)while(1)\n emptyDictionary\n emptyList\n emptySequence\n emptySet\n enumerable\n for(1)and(1)do(1)\n hashCombine(2)\n indexable\n io.FileStream\n io.IO\n io.Process\n list\n list(1)\n max(2)\n methods\n min(2)\n pi\n point2Dx(1)y(1)\n range\n repeat(1)times(1)\n required\n sequence\n sequence(1)\n set\n set(1)\n sg.Binding\u27e6K, T\u27e7\n sg.Block0\u27e6R\u27e7\n sg.Block1\u27e6T, R\u27e7\n sg.Block2\u27e6S, T, R\u27e7\n sg.Collection\u27e6T\u27e7\n sg.Dictionary\u27e6K, T\u27e7\n sg.Enumerable\u27e6T\u27e7\n sg.ExceptionKind\n sg.Expandable\u27e6T\u27e7\n sg.Extractable\n sg.Function0\u27e6ResultT\u27e7\n sg.Function1\u27e6ArgT1, ResultT\u27e7\n sg.Function2\u27e6ArgT1, ArgT2, ResultT\u27e7\n sg.Function3\u27e6ArgT1, ArgT2, ArgT3, ResultT\u27e7\n sg.Iterable\u27e6T\u27e7\n sg.Iterator\u27e6T\u27e7\n sg.List\u27e6T\u27e7\n sg.MatchResult\n sg.Pattern\n sg.Point\n sg.Predicate0\n sg.Predicate1\u27e6ArgT1\u27e7\n sg.Predicate2\u27e6ArgT1, ArgT2\u27e7\n sg.Predicate3\u27e6ArgT1, ArgT2, ArgT3\u27e7\n sg.Procedure0\n sg.Procedure1\u27e6ArgT1\u27e7\n sg.Procedure2\u27e6ArgT1, ArgT2\u27e7\n sg.Procedure3\u27e6ArgT1, ArgT2, ArgT3\u27e7\n sg.Sequence\u27e6T\u27e7\n sg.Set\u27e6T\u27e7\n sg.coll.Binding\u27e6K, T\u27e7\n sg.coll.Collection\u27e6T\u27e7\n sg.coll.ComparableToDictionary\u27e6K, T\u27e7\n sg.coll.Dictionary\u27e6K, T\u27e7\n sg.coll.Enumerable\u27e6T\u27e7\n sg.coll.Expandable\u27e6T\u27e7\n sg.coll.Function0\u27e6ResultT\u27e7\n sg.coll.Function1\u27e6ArgT1, ResultT\u27e7\n sg.coll.Function2\u27e6ArgT1, ArgT2, ResultT\u27e7\n sg.coll.Iterable\u27e6T\u27e7\n sg.coll.Iterator\u27e6T\u27e7\n sg.coll.List\u27e6T\u27e7\n sg.coll.MinimalyIterable\n sg.coll.Predicate1\u27e6ArgT1\u27e7\n sg.coll.Procedure0\n sg.coll.Procedure1\u27e6ArgT1\u27e7\n sg.coll.Procedure2\u27e6ArgT1, ArgT2\u27e7\n sg.coll.SelfType\n sg.coll.Sequence\u27e6T\u27e7\n sg.coll.Set\u27e6T\u27e7\n singleton\n singleton(1)\n valueOf(1)\n xmodule.LinePos\n xmodule.RangeSuggestions\n xmodule.ast.AliasPair\n xmodule.ast.AstNode\n xmodule.ast.AstVisitor\n xmodule.ast.Position\n xmodule.ast.Range\n xmodule.ast.SymbolTable\n xmodule.ast.k.T\n xmodule.ast.util.filePath.io.FileStream\n xmodule.ast.util.filePath.io.IO\n xmodule.ast.util.filePath.io.Process\n xmodule.ast.util.io.FileStream\n xmodule.ast.util.io.IO\n xmodule.ast.util.io.Process\n xmodule.ast.util.sys.Environment\n xmodule.errormessages.io.FileStream\n xmodule.errormessages.io.IO\n xmodule.errormessages.io.Process\n xmodule.errormessages.sys.Environment\n xmodule.errormessages.util.filePath.io.FileStream\n xmodule.errormessages.util.filePath.io.IO\n xmodule.errormessages.util.filePath.io.Process\n xmodule.errormessages.util.io.FileStream\n xmodule.errormessages.util.io.IO\n xmodule.errormessages.util.io.Process\n xmodule.errormessages.util.sys.Environment\n xmodule.filePath.io.FileStream\n xmodule.filePath.io.IO\n xmodule.filePath.io.Process\n xmodule.io.FileStream\n xmodule.io.IO\n xmodule.io.Process\n xmodule.lexer.errormessages.io.FileStream\n xmodule.lexer.errormessages.io.IO\n xmodule.lexer.errormessages.io.Process\n xmodule.lexer.errormessages.sys.Environment\n xmodule.lexer.errormessages.util.filePath.io.FileStream\n xmodule.lexer.errormessages.util.filePath.io.IO\n xmodule.lexer.errormessages.util.filePath.io.Process\n xmodule.lexer.errormessages.util.io.FileStream\n xmodule.lexer.errormessages.util.io.IO\n xmodule.lexer.errormessages.util.io.Process\n xmodule.lexer.errormessages.util.sys.Environment\n xmodule.lexer.util.filePath.io.FileStream\n xmodule.lexer.util.filePath.io.IO\n xmodule.lexer.util.filePath.io.Process\n xmodule.lexer.util.io.FileStream\n xmodule.lexer.util.io.IO\n xmodule.lexer.util.io.Process\n xmodule.lexer.util.sys.Environment\n xmodule.mirrors.ArgList\n xmodule.mirrors.MethodMirror\n xmodule.mirrors.Mirror\n xmodule.parser.ast.AliasPair\n xmodule.parser.ast.AstNode\n xmodule.parser.ast.AstVisitor\n xmodule.parser.ast.Position\n xmodule.parser.ast.Range\n xmodule.parser.ast.SymbolTable\n xmodule.parser.ast.k.T\n xmodule.parser.ast.util.filePath.io.FileStream\n xmodule.parser.ast.util.filePath.io.IO\n xmodule.parser.ast.util.filePath.io.Process\n xmodule.parser.ast.util.io.FileStream\n xmodule.parser.ast.util.io.IO\n xmodule.parser.ast.util.io.Process\n xmodule.parser.ast.util.sys.Environment\n xmodule.parser.errormessages.io.FileStream\n xmodule.parser.errormessages.io.IO\n xmodule.parser.errormessages.io.Process\n xmodule.parser.errormessages.sys.Environment\n xmodule.parser.errormessages.util.filePath.io.FileStream\n xmodule.parser.errormessages.util.filePath.io.IO\n xmodule.parser.errormessages.util.filePath.io.Process\n xmodule.parser.errormessages.util.io.FileStream\n xmodule.parser.errormessages.util.io.IO\n xmodule.parser.errormessages.util.io.Process\n xmodule.parser.errormessages.util.sys.Environment\n xmodule.parser.io.FileStream\n xmodule.parser.io.IO\n xmodule.parser.io.Process\n xmodule.parser.util.filePath.io.FileStream\n xmodule.parser.util.filePath.io.IO\n xmodule.parser.util.filePath.io.Process\n xmodule.parser.util.io.FileStream\n xmodule.parser.util.io.IO\n xmodule.parser.util.io.Process\n xmodule.parser.util.sys.Environment\n xmodule.sys.Environment\n xmodule.util.filePath.io.FileStream\n xmodule.util.filePath.io.IO\n xmodule.util.filePath.io.Process\n xmodule.util.io.FileStream\n xmodule.util.io.IO\n xmodule.util.io.Process\n xmodule.util.sys.Environment\npublicMethod:ArrayLiteral:\n ArrayLiteral \u2192 Pattern\npublicMethod:Bind:\n Bind \u2192 Pattern\npublicMethod:BlockLiteral:\n BlockLiteral \u2192 Pattern\npublicMethod:Class:\n Class \u2192 Pattern\npublicMethod:Def:\n Def \u2192 Pattern\npublicMethod:Dialect:\n Dialect \u2192 Pattern\npublicMethod:Generic:\n Generic \u2192 Pattern\npublicMethod:Identifier:\n Identifier \u2192 Pattern\npublicMethod:If:\n If \u2192 Pattern\npublicMethod:Import:\n Import \u2192 Pattern\npublicMethod:Inherit:\n Inherit \u2192 Pattern\npublicMethod:MatchCase:\n MatchCase \u2192 Pattern\npublicMethod:Member:\n Member \u2192 Pattern\npublicMethod:Method:\n Method \u2192 Pattern\npublicMethod:MethodSignature:\n MethodSignature \u2192 Pattern\npublicMethod:Module:\n Module \u2192 Pattern\npublicMethod:NumberLiteral:\n NumberLiteral \u2192 Pattern\npublicMethod:ObjectLiteral:\n ObjectLiteral \u2192 Pattern\npublicMethod:OctetsLiteral:\n OctetsLiteral \u2192 Pattern\npublicMethod:Operator:\n Operator \u2192 Pattern\npublicMethod:Outer:\n Outer \u2192 Pattern\npublicMethod:Parameter:\n Parameter \u2192 Pattern\npublicMethod:Request:\n Request \u2192 Pattern\npublicMethod:Return:\n Return \u2192 Pattern\npublicMethod:StringLiteral:\n StringLiteral \u2192 Pattern\npublicMethod:TryCatch:\n TryCatch \u2192 Pattern\npublicMethod:TypeAnnotation:\n TypeAnnotation \u2192 Pattern\npublicMethod:TypeDeclaration:\n TypeDeclaration \u2192 Pattern\npublicMethod:TypeLiteral:\n TypeLiteral \u2192 Pattern\npublicMethod:Var:\n Var \u2192 Pattern\npublicMethod:aPatternMatchingNode(1):\n aPatternMatchingNode(kind:String) \u2192 Pattern\npublicMethod:booleanPattern(1):\n booleanPattern(predicate:Function1\u27e6AstNode\u27e7) \u2192 Pattern\npublicMethodTypes:\n ArrayLiteral \u2192 Pattern\n Bind \u2192 Pattern\n BlockLiteral \u2192 Pattern\n Class \u2192 Pattern\n Def \u2192 Pattern\n Dialect \u2192 Pattern\n Generic \u2192 Pattern\n Identifier \u2192 Pattern\n If \u2192 Pattern\n Import \u2192 Pattern\n Inherit \u2192 Pattern\n MatchCase \u2192 Pattern\n Member \u2192 Pattern\n Method \u2192 Pattern\n MethodSignature \u2192 Pattern\n Module \u2192 Pattern\n NumberLiteral \u2192 Pattern\n ObjectLiteral \u2192 Pattern\n OctetsLiteral \u2192 Pattern\n Operator \u2192 Pattern\n Outer \u2192 Pattern\n Parameter \u2192 Pattern\n Request \u2192 Pattern\n Return \u2192 Pattern\n StringLiteral \u2192 Pattern\n TryCatch \u2192 Pattern\n TypeAnnotation \u2192 Pattern\n TypeDeclaration \u2192 Pattern\n TypeLiteral \u2192 Pattern\n Var \u2192 Pattern\n aPatternMatchingNode(kind:String) \u2192 Pattern\n booleanPattern(predicate:Function1\u27e6AstNode\u27e7) \u2192 Pattern\ntypedec-of:Answer:\n type Answer = interface {\n            ans \u2192 Boolean\n            trials \u2192 List\u27e6TypePair\u27e7\n            asString \u2192 String}\ntypedec-of:AstNode:\n type AstNode = interface {\n            kind \u2192 String}\ntypedec-of:GenericType:\n type GenericType = interface {\n            name \u2192 String\n            typeParams \u2192 List\u27e6String\u27e7\n            oType \u2192 ObjectType\n            apply(replacementTypes:List\u27e6ObjectType\u27e7) \u2192 ObjectType}\ntypedec-of:GenericTypeFactory:\n type GenericTypeFactory = interface {\n            fromName(name':String)parameters(typeParams':List\u27e6String\u27e7)objectType(oType':ObjectType) \u2192 GenericType\n            fromTypeDec(node:AstNode) \u2192 GenericType}\ntypedec-of:MethodType:\n type MethodType = interface {\n            name \u2192 String\n            nameString \u2192 String\n            signature \u2192 List\u27e6MixPart\u27e7\n            retType \u2192 ObjectType\n            typeParams \u2192 List\u27e6String\u27e7\n            hasTypeParams \u2192 Boolean\n            ==(other:MethodType) \u2192 Boolean\n            restriction(other:MethodType) \u2192 MethodType\n            isSpecialisationOf(trials:List\u27e6TypePair\u27e7, other:MethodType) \u2192 Answer\n            apply(replacementTypes:List\u27e6ObjectType\u27e7) \u2192 MethodType\n            replaceGenericsWith(replacements:Dictionary\u27e6String, ObjectType\u27e7) \u2192 MethodType}\ntypedec-of:MethodTypeFactory:\n type MethodTypeFactory = interface {\n            signature(signature':List\u27e6MixPart\u27e7)returnType(rType:ObjectType) \u2192 MethodType\n            member(name:String)ofType(rType:ObjectType) \u2192 MethodType\n            fromGctLine(line:String, importName:String) \u2192 MethodType\n            fromNode(node:AstNode) \u2192 MethodType}\ntypedec-of:MixPart:\n type MixPart = interface {\n            name \u2192 String\n            parameters \u2192 List\u27e6Param\u27e7}\ntypedec-of:ObjectType:\n type ObjectType = interface {\n            methods \u2192 Set\u27e6MethodType\u27e7\n            getMethod(name:String) \u2192 MethodType | noSuchMethod\n            resolve \u2192 ObjectType\n            isResolved \u2192 Boolean\n            isOp \u2192 Boolean\n            isDynamic \u2192 Boolean\n            ==(other:ObjectType) \u2192 Boolean\n            isSubtypeOf(other:ObjectType) \u2192 Boolean\n            isSubtypeHelper(trials:List\u27e6TypePair\u27e7, other:ObjectType) \u2192 Answer\n            restriction(other:ObjectType) \u2192 ObjectType\n            isConsistentSubtypeOf(other:ObjectType) \u2192 Boolean\n            getVariantTypes \u2192 List\u27e6ObjectType\u27e7\n            setVariantTypes(newVariantTypes:List\u27e6ObjectType\u27e7) \u2192 Done\n            getOpNode \u2192 TypeOp\n            setOpNode(op:TypeOp) \u2192 Done\n            |(other:ObjectType) \u2192 ObjectType\n            &(other:ObjectType) \u2192 ObjectType}\ntypedec-of:ObjectTypeFactory:\n type ObjectTypeFactory = interface {\n            definedByNode(node:AstNode) \u2192 ObjectType\n            fromMethods(methods':Set\u27e6MethodType\u27e7) \u2192 ObjectType\n            fromMethods(methods':Set\u27e6MethodType\u27e7)withName(name:String) \u2192 ObjectType\n            fromDType(dtype) \u2192 ObjectType\n            fromGeneric(node:Generic) \u2192 ObjectType\n            fromIdentifier(ident:Identifier) \u2192 ObjectType\n            dynamic \u2192 ObjectType\n            bottom \u2192 ObjectType\n            blockTaking(params:List\u27e6Parameter\u27e7)returning(rType:ObjectType) \u2192 ObjectType\n            blockReturning(rType:ObjectType) \u2192 ObjectType\n            preludeTypes \u2192 Set\u27e6String\u27e7\n            base \u2192 ObjectType\n            doneType \u2192 ObjectType\n            pattern \u2192 ObjectType\n            iterator \u2192 ObjectType\n            boolean \u2192 ObjectType\n            number \u2192 ObjectType\n            string \u2192 ObjectType\n            listTp \u2192 ObjectType\n            set \u2192 ObjectType\n            sequence \u2192 ObjectType\n            dictionary \u2192 ObjectType\n            point \u2192 ObjectType\n            binding \u2192 ObjectType}\ntypedec-of:Param:\n type Param = interface {\n            name \u2192 String\n            typeAnnotation \u2192 ObjectType}\ntypedec-of:ParamFactory:\n type ParamFactory = interface {\n            withName(name':String)ofType(type':ObjectType) \u2192 Param\n            ofType(type':ObjectType) \u2192 Param}\ntypedec-of:TypeOp:\n type TypeOp = interface {\n            op \u2192 String\n            left \u2192 ObjectType\n            right \u2192 ObjectType}\ntypedec-of:TypePair:\n type TypePair = interface {\n            first \u2192 ObjectType\n            second \u2192 ObjectType\n            ==(other:Object) \u2192 Boolean\n            asString \u2192 String}\ntypedec-of:ast.AliasPair:\n type AliasPair = interface {\n            newName \u2192 Done\n            oldName \u2192 Done}\ntypedec-of:ast.AstNode:\n type AstNode = interface {\n            kind \u2192 String\n            register \u2192 String\n            line \u2192 Number\n            line:=(ln:Number) \u2192 Done\n            column \u2192 Number\n            linePos \u2192 Number\n            linePos:=(lp:Number) \u2192 Done\n            scope \u2192 SymbolTable\n            pretty(n:Number) \u2192 String\n            comments \u2192 AstNode\n            range \u2192 Range\n            start \u2192 Position\n            end \u2192 Position}\ntypedec-of:ast.AstVisitor:\n type AstVisitor = interface {\n            visitIf(o)up(ac) \u2192 Boolean\n            visitBlock(o)up(ac) \u2192 Boolean\n            visitMatchCase(o)up(ac) \u2192 Boolean\n            visitTryCatch(o)up(ac) \u2192 Boolean\n            visitMethodType(o)up(ac) \u2192 Boolean\n            visitSignaturePart(o)up(ac) \u2192 Boolean\n            visitTypeLiteral(o)up(ac) \u2192 Boolean\n            visitTypeParameters(o)up(ac) \u2192 Boolean\n            visitTypeDec(o)up(ac) \u2192 Boolean\n            visitMethod(o)up(ac) \u2192 Boolean\n            visitCall(o)up(ac) \u2192 Boolean\n            visitObject(o)up(ac) \u2192 Boolean\n            visitModule(o)up(ac) \u2192 Boolean\n            visitArray(o)up(ac) \u2192 Boolean\n            visitMember(o)up(ac) \u2192 Boolean\n            visitGeneric(o)up(ac) \u2192 Boolean\n            visitIdentifier(o)up(ac) \u2192 Boolean\n            visitString(o)up(ac) \u2192 Boolean\n            visitNum(o)up(ac) \u2192 Boolean\n            visitOp(o)up(ac) \u2192 Boolean\n            visitBind(o)up(ac) \u2192 Boolean\n            visitDefDec(o)up(ac) \u2192 Boolean\n            visitVarDec(o)up(ac) \u2192 Boolean\n            visitImport(o)up(ac) \u2192 Boolean\n            visitReturn(o)up(ac) \u2192 Boolean\n            visitInherits(o)up(ac) \u2192 Boolean\n            visitDialect(o)up(ac) \u2192 Boolean\n            visitComment(o)up(ac) \u2192 Boolean\n            visitImplicit(o)up(ac) \u2192 Boolean\n            visitOuter(o)up(ac) \u2192 Boolean}\ntypedec-of:ast.Position:\n type Position = interface {\n            line \u2192 Number\n            column \u2192 Number\n            >(other) \u2192 Boolean\n            \u2265(other) \u2192 Boolean\n            ==(other) \u2192 Boolean\n            <(other) \u2192 Boolean\n            \u2264(other) \u2192 Boolean}\ntypedec-of:ast.Range:\n type Range = interface {\n            start \u2192 Position\n            end \u2192 Position}\ntypedec-of:ast.SymbolTable:\n type SymbolTable = Unknown\ntypedec-of:ast.k.T:\n type T = interface {\n            isParameter \u2192 Boolean\n            isAssignable \u2192 Boolean\n            isImplicit \u2192 Boolean\n            forUsers \u2192 Boolean\n            fromParent \u2192 Boolean\n            ==(o:T) \u2192 Boolean}\ntypedec-of:ast.util.filePath.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:ast.util.filePath.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:ast.util.filePath.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:ast.util.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:ast.util.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:ast.util.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:ast.util.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:sg.Binding\u27e6K, T\u27e7:\n type Binding\u27e6K, T\u27e7 = collections.Binding\ntypedec-of:sg.Block0\u27e6R\u27e7:\n type Block0\u27e6R\u27e7 = Function0\ntypedec-of:sg.Block1\u27e6T, R\u27e7:\n type Block1\u27e6T, R\u27e7 = Function1\ntypedec-of:sg.Block2\u27e6S, T, R\u27e7:\n type Block2\u27e6S, T, R\u27e7 = Function2\ntypedec-of:sg.Collection\u27e6T\u27e7:\n type Collection\u27e6T\u27e7 = collections.Collection\ntypedec-of:sg.Dictionary\u27e6K, T\u27e7:\n type Dictionary\u27e6K, T\u27e7 = collections.Dictionary\ntypedec-of:sg.Enumerable\u27e6T\u27e7:\n type Enumerable\u27e6T\u27e7 = collections.Enumerable\ntypedec-of:sg.ExceptionKind:\n type ExceptionKind = Pattern & interface {\n    refine(parentKind:ExceptionKind) \u2192 ExceptionKind\n    parent \u2192 ExceptionKind\n    raise(message:String) \u2192 Done\n    raise(message:String)with(argument:Object) \u2192 Done}\ntypedec-of:sg.Expandable\u27e6T\u27e7:\n type Expandable\u27e6T\u27e7 = collections.Expandable\ntypedec-of:sg.Extractable:\n type Extractable = interface {\n            extract \u2192 Done}\ntypedec-of:sg.Function0\u27e6ResultT\u27e7:\n type Function0\u27e6ResultT\u27e7 = interface {\n            apply \u2192 ResultT}\ntypedec-of:sg.Function1\u27e6ArgT1, ResultT\u27e7:\n type Function1\u27e6ArgT1, ResultT\u27e7 = interface {\n            apply(a1:ArgT1) \u2192 ResultT}\ntypedec-of:sg.Function2\u27e6ArgT1, ArgT2, ResultT\u27e7:\n type Function2\u27e6ArgT1, ArgT2, ResultT\u27e7 = interface {\n            apply(a1:ArgT1, a2:ArgT2) \u2192 ResultT}\ntypedec-of:sg.Function3\u27e6ArgT1, ArgT2, ArgT3, ResultT\u27e7:\n type Function3\u27e6ArgT1, ArgT2, ArgT3, ResultT\u27e7 = interface {\n            apply(a1:ArgT1, a2:ArgT2, a3:ArgT3) \u2192 ResultT}\ntypedec-of:sg.Iterable\u27e6T\u27e7:\n type Iterable\u27e6T\u27e7 = collections.Iterable\ntypedec-of:sg.Iterator\u27e6T\u27e7:\n type Iterator\u27e6T\u27e7 = collections.Iterator\ntypedec-of:sg.List\u27e6T\u27e7:\n type List\u27e6T\u27e7 = collections.List\ntypedec-of:sg.MatchResult:\n type MatchResult = Boolean | (Boolean & interface {\n    result \u2192 Unknown\n    bindings \u2192 List\u27e6Unknown\u27e7})\ntypedec-of:sg.Pattern:\n type Pattern = interface {\n            &(other:Pattern) \u2192 Pattern\n            |(other:Pattern) \u2192 Pattern\n            match(value:Object) \u2192 MatchResult}\ntypedec-of:sg.Point:\n type Point = interface {\n            x \u2192 Number\n            y \u2192 Number\n            ==(other:Object) \u2192 Boolean\n            +(other:Point | Number) \u2192 Point\n            -(other:Point | Number) \u2192 Point\n            prefix- \u2192 Point\n            *(factor:Number) \u2192 Point\n            /(factor:Number) \u2192 Point\n            length \u2192 Number\n            distanceTo(other:Point) \u2192 Number\n            dot(other:Point) \u2192 Number\n            \u22c5(other:Point) \u2192 Number\n            norm \u2192 Point\n            hash \u2192 Number}\ntypedec-of:sg.Predicate0:\n type Predicate0 = Function0\ntypedec-of:sg.Predicate1\u27e6ArgT1\u27e7:\n type Predicate1\u27e6ArgT1\u27e7 = Function1\ntypedec-of:sg.Predicate2\u27e6ArgT1, ArgT2\u27e7:\n type Predicate2\u27e6ArgT1, ArgT2\u27e7 = Function2\ntypedec-of:sg.Predicate3\u27e6ArgT1, ArgT2, ArgT3\u27e7:\n type Predicate3\u27e6ArgT1, ArgT2, ArgT3\u27e7 = Function3\ntypedec-of:sg.Procedure0:\n type Procedure0 = Function0\ntypedec-of:sg.Procedure1\u27e6ArgT1\u27e7:\n type Procedure1\u27e6ArgT1\u27e7 = Function1\ntypedec-of:sg.Procedure2\u27e6ArgT1, ArgT2\u27e7:\n type Procedure2\u27e6ArgT1, ArgT2\u27e7 = Function2\ntypedec-of:sg.Procedure3\u27e6ArgT1, ArgT2, ArgT3\u27e7:\n type Procedure3\u27e6ArgT1, ArgT2, ArgT3\u27e7 = Function3\ntypedec-of:sg.Sequence\u27e6T\u27e7:\n type Sequence\u27e6T\u27e7 = collections.Sequence\ntypedec-of:sg.Set\u27e6T\u27e7:\n type Set\u27e6T\u27e7 = collections.Set\ntypedec-of:sg.coll.Binding\u27e6K, T\u27e7:\n type Binding\u27e6K, T\u27e7 = interface {\n            key \u2192 K\n            value \u2192 T\n            hash \u2192 Number\n            ==(other) \u2192 Boolean}\ntypedec-of:sg.coll.Collection\u27e6T\u27e7:\n type Collection\u27e6T\u27e7 = Object & interface {\n    iterator \u2192 Iterator\u27e6T\u27e7\n    isEmpty \u2192 Boolean\n    size \u2192 Number\n    sizeIfUnknown(action:Function0\u27e6Number\u27e7) \u2192 Done\n    ==(other) \u2192 Boolean\n    first \u2192 T\n    do(body:Procedure1\u27e6T\u27e7) \u2192 Done\n    do(body:Procedure1\u27e6T\u27e7)separatedBy(separator:Procedure0) \u2192 Done\n    ++(other:Collection\u27e6T\u27e7) \u2192 Collection\u27e6T\u27e7\n    fold(binaryFunction:Function2\u27e6T, T, T\u27e7)startingWith(initial:T) \u2192 T\n    map\u27e6U\u27e7(function:Function1\u27e6T, U\u27e7) \u2192 Collection\u27e6U\u27e7\n    filter(condition:Predicate1\u27e6T\u27e7) \u2192 Collection\u27e6T\u27e7\n    >>(target:Collection\u27e6T\u27e7) \u2192 Collection\u27e6T\u27e7}\ntypedec-of:sg.coll.ComparableToDictionary\u27e6K, T\u27e7:\n type ComparableToDictionary\u27e6K, T\u27e7 = interface {\n            size \u2192 Number\n            at(_:K)ifAbsent(_) \u2192 T}\ntypedec-of:sg.coll.Dictionary\u27e6K, T\u27e7:\n type Dictionary\u27e6K, T\u27e7 = Collection & interface {\n    size \u2192 Number\n    containsKey(k:K) \u2192 Boolean\n    containsValue(v:T) \u2192 Boolean\n    contains(elem:T) \u2192 Boolean\n    at(key:K)ifAbsent(action:Function0\u27e6Unknown\u27e7) \u2192 Unknown\n    at(key:K)put(value:T) \u2192 Dictionary\u27e6K, T\u27e7\n    at(k:K) \u2192 T\n    removeAllKeys(keys:Collection\u27e6K\u27e7) \u2192 Dictionary\u27e6K, T\u27e7\n    removeKey(key:K) \u2192 Dictionary\u27e6K, T\u27e7\n    removeAllValues(removals:Collection\u27e6T\u27e7) \u2192 Dictionary\u27e6K, T\u27e7\n    removeValue(v:T) \u2192 Dictionary\u27e6K, T\u27e7\n    clear \u2192 Dictionary\u27e6K, T\u27e7\n    keys \u2192 Enumerable\u27e6K\u27e7\n    values \u2192 Enumerable\u27e6T\u27e7\n    bindings \u2192 Enumerable\u27e6Binding\u27e6K, T\u27e7\u27e7\n    keysAndValuesDo(action:Procedure2\u27e6K, T\u27e7) \u2192 Done\n    keysDo(action:Procedure1\u27e6K\u27e7) \u2192 Done\n    valuesDo(action:Procedure1\u27e6T\u27e7) \u2192 Done\n    ==(other:Object) \u2192 Boolean\n    copy \u2192 Dictionary\u27e6K, T\u27e7\n    ++(other:Dictionary\u27e6K, T\u27e7) \u2192 Dictionary\u27e6K, T\u27e7\n    --(other:Dictionary\u27e6K, T\u27e7) \u2192 Dictionary\u27e6K, T\u27e7\n    asDictionary \u2192 Dictionary\u27e6K, T\u27e7}\ntypedec-of:sg.coll.Enumerable\u27e6T\u27e7:\n type Enumerable\u27e6T\u27e7 = Collection & interface {\n    values \u2192 Collection\u27e6T\u27e7\n    asDictionary \u2192 Dictionary\u27e6Number, T\u27e7\n    keysAndValuesDo(action:Function2\u27e6Number, T, Object\u27e7) \u2192 Done\n    into(existing:Expandable\u27e6Unknown\u27e7) \u2192 Collection\u27e6Unknown\u27e7\n    sortedBy(comparison:Function2\u27e6T, T, Number\u27e7) \u2192 SelfType\n    sorted \u2192 SelfType}\ntypedec-of:sg.coll.Expandable\u27e6T\u27e7:\n type Expandable\u27e6T\u27e7 = Collection & interface {\n    add(x:T) \u2192 SelfType\n    addAll(xs:Collection\u27e6T\u27e7) \u2192 SelfType}\ntypedec-of:sg.coll.Function0\u27e6ResultT\u27e7:\n type Function0\u27e6ResultT\u27e7 = interface {\n            apply \u2192 ResultT}\ntypedec-of:sg.coll.Function1\u27e6ArgT1, ResultT\u27e7:\n type Function1\u27e6ArgT1, ResultT\u27e7 = interface {\n            apply(a1:ArgT1) \u2192 ResultT}\ntypedec-of:sg.coll.Function2\u27e6ArgT1, ArgT2, ResultT\u27e7:\n type Function2\u27e6ArgT1, ArgT2, ResultT\u27e7 = interface {\n            apply(a1:ArgT1, a2:ArgT2) \u2192 ResultT}\ntypedec-of:sg.coll.Iterable\u27e6T\u27e7:\n type Iterable\u27e6T\u27e7 = Collection\ntypedec-of:sg.coll.Iterator\u27e6T\u27e7:\n type Iterator\u27e6T\u27e7 = interface {\n            hasNext \u2192 Boolean\n            next \u2192 T}\ntypedec-of:sg.coll.List\u27e6T\u27e7:\n type List\u27e6T\u27e7 = Sequence & interface {\n    add(x:T) \u2192 List\u27e6T\u27e7\n    addAll(xs:Collection\u27e6T\u27e7) \u2192 List\u27e6T\u27e7\n    addFirst(x:T) \u2192 List\u27e6T\u27e7\n    addAllFirst(xs:Collection\u27e6T\u27e7) \u2192 List\u27e6T\u27e7\n    addLast(x:T) \u2192 List\u27e6T\u27e7\n    at(ix:Number)put(v:T) \u2192 List\u27e6T\u27e7\n    clear \u2192 List\u27e6T\u27e7\n    removeFirst \u2192 T\n    removeAt(n:Number) \u2192 T\n    removeLast \u2192 T\n    remove(v:T) \u2192 Done\n    remove(v:T)ifAbsent(action:Procedure0) \u2192 Done\n    removeAll(vs:Collection\u27e6T\u27e7) \u2192 Done\n    removeAll(vs:Collection\u27e6T\u27e7)ifAbsent(action:Function0\u27e6Unknown\u27e7) \u2192 Done\n    pop \u2192 T\n    ++(o:List\u27e6T\u27e7) \u2192 List\u27e6T\u27e7\n    addAll(l:Collection\u27e6T\u27e7) \u2192 List\u27e6T\u27e7\n    copy \u2192 List\u27e6T\u27e7\n    sort \u2192 List\u27e6T\u27e7\n    sortBy(sortBlock:Function2\u27e6T, T, Number\u27e7) \u2192 List\u27e6T\u27e7\n    reverse \u2192 List\u27e6T\u27e7\n    reversed \u2192 List\u27e6T\u27e7}\ntypedec-of:sg.coll.MinimalyIterable:\n type MinimalyIterable = interface {\n            iterator \u2192 Iterator}\ntypedec-of:sg.coll.Predicate1\u27e6ArgT1\u27e7:\n type Predicate1\u27e6ArgT1\u27e7 = Function1\ntypedec-of:sg.coll.Procedure0:\n type Procedure0 = Function0\ntypedec-of:sg.coll.Procedure1\u27e6ArgT1\u27e7:\n type Procedure1\u27e6ArgT1\u27e7 = Function1\ntypedec-of:sg.coll.Procedure2\u27e6ArgT1, ArgT2\u27e7:\n type Procedure2\u27e6ArgT1, ArgT2\u27e7 = Function1\ntypedec-of:sg.coll.SelfType:\n type SelfType = Unknown\ntypedec-of:sg.coll.Sequence\u27e6T\u27e7:\n type Sequence\u27e6T\u27e7 = Enumerable & interface {\n    size \u2192 Number\n    at(n:Number) \u2192 T\n    indices \u2192 Sequence\u27e6Number\u27e7\n    keys \u2192 Sequence\u27e6Number\u27e7\n    second \u2192 T\n    third \u2192 T\n    fourth \u2192 T\n    fifth \u2192 T\n    last \u2192 T\n    indexOf\u27e6W\u27e7(elem:T)ifAbsent(action:Function0\u27e6W\u27e7) \u2192 Number | W\n    indexOf(elem:T) \u2192 Number\n    contains(elem:T) \u2192 Boolean\n    reversed \u2192 Sequence\u27e6T\u27e7}\ntypedec-of:sg.coll.Set\u27e6T\u27e7:\n type Set\u27e6T\u27e7 = Collection & interface {\n    size \u2192 Number\n    add(x:T) \u2192 SelfType\n    addAll(elements:Collection\u27e6T\u27e7) \u2192 SelfType\n    remove(x:T) \u2192 Set\u27e6T\u27e7\n    remove(x:T)ifAbsent(block:Procedure0) \u2192 Set\u27e6T\u27e7\n    clear \u2192 Set\u27e6T\u27e7\n    includes(booleanBlock:Predicate1\u27e6T\u27e7) \u2192 Boolean\n    find(booleanBlock:Predicate1\u27e6T\u27e7)ifNone(notFoundBlock:Function0\u27e6T\u27e7) \u2192 T\n    copy \u2192 Set\u27e6T\u27e7\n    contains(elem:T) \u2192 Boolean\n    **(other:Set\u27e6T\u27e7) \u2192 Set\u27e6T\u27e7\n    --(other:Set\u27e6T\u27e7) \u2192 Set\u27e6T\u27e7\n    ++(other:Set\u27e6T\u27e7) \u2192 Set\u27e6T\u27e7\n    isSubset(s2:Set\u27e6T\u27e7) \u2192 Boolean\n    isSuperset(s2:Collection\u27e6T\u27e7) \u2192 Boolean\n    removeAll(elems:Collection\u27e6T\u27e7) \u2192 Done\n    removeAll(elems:Collection\u27e6T\u27e7)ifAbsent(action:Procedure0) \u2192 Set\u27e6T\u27e7\n    into(existing:Expandable\u27e6Unknown\u27e7) \u2192 Collection\u27e6Unknown\u27e7}\ntypedec-of:xmodule.LinePos:\n type LinePos = interface {\n            line \u2192 Number\n            linePos \u2192 Number}\ntypedec-of:xmodule.RangeSuggestions:\n type RangeSuggestions = interface {\n            line \u2192 Number\n            posStart \u2192 Number\n            posEnd \u2192 Number\n            suggestions \u2192 Done}\ntypedec-of:xmodule.ast.AliasPair:\n type AliasPair = interface {\n            newName \u2192 Done\n            oldName \u2192 Done}\ntypedec-of:xmodule.ast.AstNode:\n type AstNode = interface {\n            kind \u2192 String\n            register \u2192 String\n            line \u2192 Number\n            line:=(ln:Number) \u2192 Done\n            column \u2192 Number\n            linePos \u2192 Number\n            linePos:=(lp:Number) \u2192 Done\n            scope \u2192 SymbolTable\n            pretty(n:Number) \u2192 String\n            comments \u2192 AstNode\n            range \u2192 Range\n            start \u2192 Position\n            end \u2192 Position}\ntypedec-of:xmodule.ast.AstVisitor:\n type AstVisitor = interface {\n            visitIf(o)up(ac) \u2192 Boolean\n            visitBlock(o)up(ac) \u2192 Boolean\n            visitMatchCase(o)up(ac) \u2192 Boolean\n            visitTryCatch(o)up(ac) \u2192 Boolean\n            visitMethodType(o)up(ac) \u2192 Boolean\n            visitSignaturePart(o)up(ac) \u2192 Boolean\n            visitTypeLiteral(o)up(ac) \u2192 Boolean\n            visitTypeParameters(o)up(ac) \u2192 Boolean\n            visitTypeDec(o)up(ac) \u2192 Boolean\n            visitMethod(o)up(ac) \u2192 Boolean\n            visitCall(o)up(ac) \u2192 Boolean\n            visitObject(o)up(ac) \u2192 Boolean\n            visitModule(o)up(ac) \u2192 Boolean\n            visitArray(o)up(ac) \u2192 Boolean\n            visitMember(o)up(ac) \u2192 Boolean\n            visitGeneric(o)up(ac) \u2192 Boolean\n            visitIdentifier(o)up(ac) \u2192 Boolean\n            visitString(o)up(ac) \u2192 Boolean\n            visitNum(o)up(ac) \u2192 Boolean\n            visitOp(o)up(ac) \u2192 Boolean\n            visitBind(o)up(ac) \u2192 Boolean\n            visitDefDec(o)up(ac) \u2192 Boolean\n            visitVarDec(o)up(ac) \u2192 Boolean\n            visitImport(o)up(ac) \u2192 Boolean\n            visitReturn(o)up(ac) \u2192 Boolean\n            visitInherits(o)up(ac) \u2192 Boolean\n            visitDialect(o)up(ac) \u2192 Boolean\n            visitComment(o)up(ac) \u2192 Boolean\n            visitImplicit(o)up(ac) \u2192 Boolean\n            visitOuter(o)up(ac) \u2192 Boolean}\ntypedec-of:xmodule.ast.Position:\n type Position = interface {\n            line \u2192 Number\n            column \u2192 Number\n            >(other) \u2192 Boolean\n            \u2265(other) \u2192 Boolean\n            ==(other) \u2192 Boolean\n            <(other) \u2192 Boolean\n            \u2264(other) \u2192 Boolean}\ntypedec-of:xmodule.ast.Range:\n type Range = interface {\n            start \u2192 Position\n            end \u2192 Position}\ntypedec-of:xmodule.ast.SymbolTable:\n type SymbolTable = Unknown\ntypedec-of:xmodule.ast.k.T:\n type T = interface {\n            isParameter \u2192 Boolean\n            isAssignable \u2192 Boolean\n            isImplicit \u2192 Boolean\n            forUsers \u2192 Boolean\n            fromParent \u2192 Boolean\n            ==(o:T) \u2192 Boolean}\ntypedec-of:xmodule.ast.util.filePath.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.ast.util.filePath.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.ast.util.filePath.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.ast.util.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.ast.util.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.ast.util.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.ast.util.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:xmodule.errormessages.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.errormessages.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.errormessages.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.errormessages.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:xmodule.errormessages.util.filePath.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.errormessages.util.filePath.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.errormessages.util.filePath.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.errormessages.util.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.errormessages.util.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.errormessages.util.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.errormessages.util.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:xmodule.filePath.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.filePath.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.filePath.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.lexer.errormessages.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.lexer.errormessages.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.lexer.errormessages.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.lexer.errormessages.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:xmodule.lexer.errormessages.util.filePath.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.lexer.errormessages.util.filePath.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.lexer.errormessages.util.filePath.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.lexer.errormessages.util.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.lexer.errormessages.util.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.lexer.errormessages.util.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.lexer.errormessages.util.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:xmodule.lexer.util.filePath.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.lexer.util.filePath.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.lexer.util.filePath.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.lexer.util.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.lexer.util.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.lexer.util.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.lexer.util.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:xmodule.mirrors.ArgList:\n type ArgList = List\ntypedec-of:xmodule.mirrors.MethodMirror:\n type MethodMirror = Object & interface {\n    name \u2192 String\n    partcount \u2192 Number\n    paramcounts \u2192 List\u27e6Number\u27e7\n    isVariableArity \u2192 List\u27e6Boolean\u27e7\n    request(args:List\u27e6ArgList\u27e7) \u2192 Unknown\n    requestWithArgs(args:List\u27e6Object\u27e7) \u2192 Unknown}\ntypedec-of:xmodule.mirrors.Mirror:\n type Mirror = Object & interface {\n    methods \u2192 List\u27e6MethodMirror\u27e7\n    methodNames \u2192 Set\u27e6String\u27e7\n    getMethod(nm:String) \u2192 MethodMirror}\ntypedec-of:xmodule.parser.ast.AliasPair:\n type AliasPair = interface {\n            newName \u2192 Done\n            oldName \u2192 Done}\ntypedec-of:xmodule.parser.ast.AstNode:\n type AstNode = interface {\n            kind \u2192 String\n            register \u2192 String\n            line \u2192 Number\n            line:=(ln:Number) \u2192 Done\n            column \u2192 Number\n            linePos \u2192 Number\n            linePos:=(lp:Number) \u2192 Done\n            scope \u2192 SymbolTable\n            pretty(n:Number) \u2192 String\n            comments \u2192 AstNode\n            range \u2192 Range\n            start \u2192 Position\n            end \u2192 Position}\ntypedec-of:xmodule.parser.ast.AstVisitor:\n type AstVisitor = interface {\n            visitIf(o)up(ac) \u2192 Boolean\n            visitBlock(o)up(ac) \u2192 Boolean\n            visitMatchCase(o)up(ac) \u2192 Boolean\n            visitTryCatch(o)up(ac) \u2192 Boolean\n            visitMethodType(o)up(ac) \u2192 Boolean\n            visitSignaturePart(o)up(ac) \u2192 Boolean\n            visitTypeLiteral(o)up(ac) \u2192 Boolean\n            visitTypeParameters(o)up(ac) \u2192 Boolean\n            visitTypeDec(o)up(ac) \u2192 Boolean\n            visitMethod(o)up(ac) \u2192 Boolean\n            visitCall(o)up(ac) \u2192 Boolean\n            visitObject(o)up(ac) \u2192 Boolean\n            visitModule(o)up(ac) \u2192 Boolean\n            visitArray(o)up(ac) \u2192 Boolean\n            visitMember(o)up(ac) \u2192 Boolean\n            visitGeneric(o)up(ac) \u2192 Boolean\n            visitIdentifier(o)up(ac) \u2192 Boolean\n            visitString(o)up(ac) \u2192 Boolean\n            visitNum(o)up(ac) \u2192 Boolean\n            visitOp(o)up(ac) \u2192 Boolean\n            visitBind(o)up(ac) \u2192 Boolean\n            visitDefDec(o)up(ac) \u2192 Boolean\n            visitVarDec(o)up(ac) \u2192 Boolean\n            visitImport(o)up(ac) \u2192 Boolean\n            visitReturn(o)up(ac) \u2192 Boolean\n            visitInherits(o)up(ac) \u2192 Boolean\n            visitDialect(o)up(ac) \u2192 Boolean\n            visitComment(o)up(ac) \u2192 Boolean\n            visitImplicit(o)up(ac) \u2192 Boolean\n            visitOuter(o)up(ac) \u2192 Boolean}\ntypedec-of:xmodule.parser.ast.Position:\n type Position = interface {\n            line \u2192 Number\n            column \u2192 Number\n            >(other) \u2192 Boolean\n            \u2265(other) \u2192 Boolean\n            ==(other) \u2192 Boolean\n            <(other) \u2192 Boolean\n            \u2264(other) \u2192 Boolean}\ntypedec-of:xmodule.parser.ast.Range:\n type Range = interface {\n            start \u2192 Position\n            end \u2192 Position}\ntypedec-of:xmodule.parser.ast.SymbolTable:\n type SymbolTable = Unknown\ntypedec-of:xmodule.parser.ast.k.T:\n type T = interface {\n            isParameter \u2192 Boolean\n            isAssignable \u2192 Boolean\n            isImplicit \u2192 Boolean\n            forUsers \u2192 Boolean\n            fromParent \u2192 Boolean\n            ==(o:T) \u2192 Boolean}\ntypedec-of:xmodule.parser.ast.util.filePath.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.parser.ast.util.filePath.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.parser.ast.util.filePath.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.parser.ast.util.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.parser.ast.util.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.parser.ast.util.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.parser.ast.util.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:xmodule.parser.errormessages.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.parser.errormessages.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.parser.errormessages.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.parser.errormessages.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:xmodule.parser.errormessages.util.filePath.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.parser.errormessages.util.filePath.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.parser.errormessages.util.filePath.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.parser.errormessages.util.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.parser.errormessages.util.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.parser.errormessages.util.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.parser.errormessages.util.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:xmodule.parser.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.parser.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.parser.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.parser.util.filePath.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.parser.util.filePath.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.parser.util.filePath.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.parser.util.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.parser.util.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.parser.util.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.parser.util.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:xmodule.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypedec-of:xmodule.util.filePath.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.util.filePath.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.util.filePath.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.util.io.FileStream:\n type FileStream = Object & interface {\n    read \u2192 String\n    size \u2192 Number\n    hasNext \u2192 Boolean\n    next \u2192 String\n    nextLine \u2192 String\n    write(s:String) \u2192 Done\n    close \u2192 Done\n    seek(n:Number) \u2192 FileStream\n    seekForward(n:Number) \u2192 FileStream\n    seekBackward(n:Number) \u2192 FileStream\n    iterator \u2192 FileStream\n    pathname \u2192 String\n    isatty \u2192 Boolean\n    ==(other) \u2192 Boolean\n    clear \u2192 FileStream}\ntypedec-of:xmodule.util.io.IO:\n type IO = Object & interface {\n    IoException \u2192 ExceptionKind\n    input \u2192 FileStream\n    output \u2192 FileStream\n    error \u2192 FileStream\n    ask(question:String) \u2192 String\n    open(path:String, mode:String) \u2192 FileStream\n    system(command:String) \u2192 Boolean\n    exists(path:String) \u2192 Boolean\n    unlink(path:String) \u2192 Done\n    newer(path1:String, path2:String) \u2192 Boolean\n    realpath(path:String) \u2192 String\n    listdir(dirPath:String) \u2192 Sequence\u27e6String\u27e7\n    changeDirectory(dirPath:String) \u2192 Done\n    env \u2192 Dictionary\u27e6String, String\u27e7\n    spawn(executable:String, args:Collection\u27e6String\u27e7) \u2192 Process}\ntypedec-of:xmodule.util.io.Process:\n type Process = Object & interface {\n    wait \u2192 Number\n    success \u2192 Boolean\n    terminated \u2192 Boolean\n    status \u2192 Number}\ntypedec-of:xmodule.util.sys.Environment:\n type Environment = interface {\n            at(key:String) \u2192 String\n            at(key:String)put(value:String) \u2192 Boolean\n            contains(key:String) \u2192 Boolean}\ntypes:\n Answer\n AstNode\n GenericType\n GenericTypeFactory\n MethodType\n MethodTypeFactory\n MixPart\n ObjectType\n ObjectTypeFactory\n Param\n ParamFactory\n TypeOp\n TypePair\n ast.AliasPair\n ast.AstNode\n ast.AstVisitor\n ast.Position\n ast.Range\n ast.SymbolTable\n ast.k.T\n ast.util.filePath.io.FileStream\n ast.util.filePath.io.IO\n ast.util.filePath.io.Process\n ast.util.io.FileStream\n ast.util.io.IO\n ast.util.io.Process\n ast.util.sys.Environment\n io.FileStream\n io.IO\n io.Process\n sg.Binding\u27e6K, T\u27e7\n sg.Block0\u27e6R\u27e7\n sg.Block1\u27e6T, R\u27e7\n sg.Block2\u27e6S, T, R\u27e7\n sg.Collection\u27e6T\u27e7\n sg.Dictionary\u27e6K, T\u27e7\n sg.Enumerable\u27e6T\u27e7\n sg.ExceptionKind\n sg.Expandable\u27e6T\u27e7\n sg.Extractable\n sg.Function0\u27e6ResultT\u27e7\n sg.Function1\u27e6ArgT1, ResultT\u27e7\n sg.Function2\u27e6ArgT1, ArgT2, ResultT\u27e7\n sg.Function3\u27e6ArgT1, ArgT2, ArgT3, ResultT\u27e7\n sg.Iterable\u27e6T\u27e7\n sg.Iterator\u27e6T\u27e7\n sg.List\u27e6T\u27e7\n sg.MatchResult\n sg.Pattern\n sg.Point\n sg.Predicate0\n sg.Predicate1\u27e6ArgT1\u27e7\n sg.Predicate2\u27e6ArgT1, ArgT2\u27e7\n sg.Predicate3\u27e6ArgT1, ArgT2, ArgT3\u27e7\n sg.Procedure0\n sg.Procedure1\u27e6ArgT1\u27e7\n sg.Procedure2\u27e6ArgT1, ArgT2\u27e7\n sg.Procedure3\u27e6ArgT1, ArgT2, ArgT3\u27e7\n sg.Sequence\u27e6T\u27e7\n sg.Set\u27e6T\u27e7\n sg.coll.Binding\u27e6K, T\u27e7\n sg.coll.Collection\u27e6T\u27e7\n sg.coll.ComparableToDictionary\u27e6K, T\u27e7\n sg.coll.Dictionary\u27e6K, T\u27e7\n sg.coll.Enumerable\u27e6T\u27e7\n sg.coll.Expandable\u27e6T\u27e7\n sg.coll.Function0\u27e6ResultT\u27e7\n sg.coll.Function1\u27e6ArgT1, ResultT\u27e7\n sg.coll.Function2\u27e6ArgT1, ArgT2, ResultT\u27e7\n sg.coll.Iterable\u27e6T\u27e7\n sg.coll.Iterator\u27e6T\u27e7\n sg.coll.List\u27e6T\u27e7\n sg.coll.MinimalyIterable\n sg.coll.Predicate1\u27e6ArgT1\u27e7\n sg.coll.Procedure0\n sg.coll.Procedure1\u27e6ArgT1\u27e7\n sg.coll.Procedure2\u27e6ArgT1, ArgT2\u27e7\n sg.coll.SelfType\n sg.coll.Sequence\u27e6T\u27e7\n sg.coll.Set\u27e6T\u27e7\n xmodule.LinePos\n xmodule.RangeSuggestions\n xmodule.ast.AliasPair\n xmodule.ast.AstNode\n xmodule.ast.AstVisitor\n xmodule.ast.Position\n xmodule.ast.Range\n xmodule.ast.SymbolTable\n xmodule.ast.k.T\n xmodule.ast.util.filePath.io.FileStream\n xmodule.ast.util.filePath.io.IO\n xmodule.ast.util.filePath.io.Process\n xmodule.ast.util.io.FileStream\n xmodule.ast.util.io.IO\n xmodule.ast.util.io.Process\n xmodule.ast.util.sys.Environment\n xmodule.errormessages.io.FileStream\n xmodule.errormessages.io.IO\n xmodule.errormessages.io.Process\n xmodule.errormessages.sys.Environment\n xmodule.errormessages.util.filePath.io.FileStream\n xmodule.errormessages.util.filePath.io.IO\n xmodule.errormessages.util.filePath.io.Process\n xmodule.errormessages.util.io.FileStream\n xmodule.errormessages.util.io.IO\n xmodule.errormessages.util.io.Process\n xmodule.errormessages.util.sys.Environment\n xmodule.filePath.io.FileStream\n xmodule.filePath.io.IO\n xmodule.filePath.io.Process\n xmodule.io.FileStream\n xmodule.io.IO\n xmodule.io.Process\n xmodule.lexer.errormessages.io.FileStream\n xmodule.lexer.errormessages.io.IO\n xmodule.lexer.errormessages.io.Process\n xmodule.lexer.errormessages.sys.Environment\n xmodule.lexer.errormessages.util.filePath.io.FileStream\n xmodule.lexer.errormessages.util.filePath.io.IO\n xmodule.lexer.errormessages.util.filePath.io.Process\n xmodule.lexer.errormessages.util.io.FileStream\n xmodule.lexer.errormessages.util.io.IO\n xmodule.lexer.errormessages.util.io.Process\n xmodule.lexer.errormessages.util.sys.Environment\n xmodule.lexer.util.filePath.io.FileStream\n xmodule.lexer.util.filePath.io.IO\n xmodule.lexer.util.filePath.io.Process\n xmodule.lexer.util.io.FileStream\n xmodule.lexer.util.io.IO\n xmodule.lexer.util.io.Process\n xmodule.lexer.util.sys.Environment\n xmodule.mirrors.ArgList\n xmodule.mirrors.MethodMirror\n xmodule.mirrors.Mirror\n xmodule.parser.ast.AliasPair\n xmodule.parser.ast.AstNode\n xmodule.parser.ast.AstVisitor\n xmodule.parser.ast.Position\n xmodule.parser.ast.Range\n xmodule.parser.ast.SymbolTable\n xmodule.parser.ast.k.T\n xmodule.parser.ast.util.filePath.io.FileStream\n xmodule.parser.ast.util.filePath.io.IO\n xmodule.parser.ast.util.filePath.io.Process\n xmodule.parser.ast.util.io.FileStream\n xmodule.parser.ast.util.io.IO\n xmodule.parser.ast.util.io.Process\n xmodule.parser.ast.util.sys.Environment\n xmodule.parser.errormessages.io.FileStream\n xmodule.parser.errormessages.io.IO\n xmodule.parser.errormessages.io.Process\n xmodule.parser.errormessages.sys.Environment\n xmodule.parser.errormessages.util.filePath.io.FileStream\n xmodule.parser.errormessages.util.filePath.io.IO\n xmodule.parser.errormessages.util.filePath.io.Process\n xmodule.parser.errormessages.util.io.FileStream\n xmodule.parser.errormessages.util.io.IO\n xmodule.parser.errormessages.util.io.Process\n xmodule.parser.errormessages.util.sys.Environment\n xmodule.parser.io.FileStream\n xmodule.parser.io.IO\n xmodule.parser.io.Process\n xmodule.parser.util.filePath.io.FileStream\n xmodule.parser.util.filePath.io.IO\n xmodule.parser.util.filePath.io.Process\n xmodule.parser.util.io.FileStream\n xmodule.parser.util.io.IO\n xmodule.parser.util.io.Process\n xmodule.parser.util.sys.Environment\n xmodule.sys.Environment\n xmodule.util.filePath.io.FileStream\n xmodule.util.filePath.io.IO\n xmodule.util.filePath.io.Process\n xmodule.util.io.FileStream\n xmodule.util.io.IO\n xmodule.util.io.Process\n xmodule.util.sys.Environment\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["SharedTypes.old"] = [
    "#pragma ExtendedLineups",
    "#pragma noTypeChecks",
    "dialect \"none\"",
    "import \"standardGrace\" as sg",
    "",
    "import \"ast\" as ast",
    "import \"xmodule\" as xmodule",
    "import \"io\" as io",
    "",
    "inherit sg.methods",
    "",
    "// Returned when searching for a method that is not there.",
    "def noSuchMethod: outer.Pattern = object {",
    "    inherit BasicPattern.new",
    "",
    "    method match(obj : Object) {",
    "        if(self.isMe(obj)) then {",
    "            SuccessfulMatch.new(self, list[])",
    "        } else {",
    "            FailedMatch.new(obj)",
    "        }",
    "    }",
    "}",
    "",
    "// Replace newline characters with spaces. This is a",
    "// workaround for issue #116 on the gracelang/minigrace",
    "// git repo. The result of certain astNodes.toGrace(0)",
    "// is a string containing newlines, and error messages",
    "// containing these strings get cut off at the first",
    "// newline character, resulting in an unhelpful error",
    "// message.",
    "method stripNewLines(str) → String is confidential {",
    "    str.replace(\"\\n\")with(\" \")",
    "}",
    "",
    "//This type is used for checking subtyping",
    "type TypePair = {",
    "    first → ObjectType",
    "    second → ObjectType",
    "    == (other:Object)→ Boolean",
    "    asString → String",
    "}",
    "",
    "//This type is used for checking subtyping",
    "type Answer = {",
    "    ans → Boolean",
    "    trials → List⟦TypePair⟧",
    "    asString → String",
    "}",
    "",
    "//Stores needed information used when type-checking a type defined by an opNode",
    "type TypeOp = {",
    "    op → String",
    "    left → ObjectType",
    "    right → ObjectType",
    "}",
    "",
    "// type of a parameter",
    "type Param = {",
    "    name → String",
    "    typeAnnotation → ObjectType",
    "}",
    "",
    "type ParamFactory = {",
    "    withName (name' : String) ofType (type' : ObjectType) → Param",
    "    ofType (type' : ObjectType) → Param",
    "}",
    "",
    "// MixPart is a \"segment\" of a method:",
    "// Ex. for (param1) do (param2), for(param1) and do(param2) are separate \"MixParts.\"",
    "type MixPart = {",
    "    name → String",
    "    parameters → List⟦Param⟧",
    "}",
    "",
    "// Method signature information.",
    "// isSpecialisation and restriction are used for type-checking",
    "type MethodType = {",
    "    // name of the method",
    "    name → String",
    "",
    "    // name of the method with number of parameters for each part",
    "    nameString → String",
    "",
    "    // parameters and their types for each part",
    "    signature → List⟦MixPart⟧",
    "",
    "    // return type",
    "    retType → ObjectType",
    "",
    "    // optional type parameters",
    "    typeParams → List⟦String⟧",
    "",
    "    // checks if method has type parameters",
    "    hasTypeParams → Boolean",
    "",
    "    // check equivalence of part names, param types, and return type;",
    "    // does not check if param names are the same",
    "    == (other: MethodType) → Boolean",
    "",
    "    // create restriction of method type using other",
    "    restriction (other : MethodType) → MethodType",
    "",
    "    // Does it extend other",
    "    isSpecialisationOf (trials : List⟦TypePair⟧, other : MethodType) → Answer",
    "",
    "    // pre-condition: This MethodType has type parameters",
    "    apply(replacementTypes : List⟦ObjectType⟧) → MethodType",
    "",
    "    // Takes a mapping of generic-to-ObjectType and returns a copy of self",
    "    // with all of the generics replaced with their corresponding ObjectType",
    "    replaceGenericsWith(replacements:Dictionary⟦String, ObjectType⟧) → MethodType",
    "}",
    "",
    "type MethodTypeFactory = {",
    "    signature (signature' : List⟦MixPart⟧)",
    "            returnType (rType : ObjectType)→ MethodType",
    "    member (name : String) ofType (rType : ObjectType) → MethodType",
    "    fromGctLine (line : String, importName: String) → MethodType",
    "    fromNode (node: AstNode) → MethodType",
    "}",
    "",
    "type GenericType = {",
    "    name → String",
    "    typeParams → List⟦String⟧",
    "    oType → ObjectType",
    "    apply (replacementTypes : List⟦ObjectType⟧) → ObjectType",
    "}",
    "",
    "type GenericTypeFactory = {",
    "    fromName (name' : String) parameters (typeParams' : List⟦String⟧)",
    "                            objectType (oType' : ObjectType) → GenericType",
    "    fromTypeDec (node : AstNode) → GenericType",
    "}",
    "",
    "type ObjectType = {",
    "    methods → Set⟦MethodType⟧",
    "    getMethod (name : String) → MethodType | noSuchMethod",
    "    resolve → ObjectType",
    "    isResolved → Boolean",
    "    isOp → Boolean",
    "    isDynamic → Boolean",
    "    == (other:ObjectType) → Boolean",
    "    isSubtypeOf (other : ObjectType) → Boolean",
    "    isSubtypeHelper (trials : List⟦TypePair⟧, other : ObjectType) → Answer",
    "    restriction (other : ObjectType) → ObjectType",
    "    isConsistentSubtypeOf (other : ObjectType) → Boolean",
    "    getVariantTypes → List⟦ObjectType⟧",
    "    setVariantTypes(newVariantTypes:List⟦ObjectType⟧) → Done",
    "    getOpNode → TypeOp",
    "    setOpNode (op : TypeOp) → Done",
    "    | (other : ObjectType) → ObjectType",
    "    & (other : ObjectType) → ObjectType",
    "}",
    "",
    "// methods to create an object type from various inputs",
    "type ObjectTypeFactory = {",
    "    definedByNode (node : AstNode) → ObjectType",
    "    fromMethods (methods' : Set⟦MethodType⟧) → ObjectType",
    "    fromMethods(methods' : Set⟦MethodType⟧) withName(name : String) → ObjectType",
    "    fromDType (dtype) → ObjectType",
    "    fromGeneric (node : Generic) → ObjectType",
    "    fromIdentifier(ident : Identifier) → ObjectType",
    "    dynamic → ObjectType",
    "    bottom → ObjectType",
    "    blockTaking(params:List⟦Parameter⟧) returning(rType:ObjectType) → ObjectType",
    "    blockReturning (rType : ObjectType) → ObjectType",
    "    preludeTypes → Set⟦String⟧",
    "    base → ObjectType",
    "    doneType → ObjectType",
    "    pattern → ObjectType",
    "    iterator → ObjectType",
    "    boolean → ObjectType",
    "    number → ObjectType",
    "    string → ObjectType",
    "    listTp → ObjectType",
    "    set → ObjectType",
    "    sequence → ObjectType",
    "    dictionary → ObjectType",
    "    point → ObjectType",
    "    binding → ObjectType",
    "}",
    "",
    "type AstNode = { kind → String }",
    "",
    "// Create a pattern for matching kind",
    "class aPatternMatchingNode (kind : String) → Pattern {",
    "    inherit outer.BasicPattern.new",
    "",
    "    method match (obj : Object) → MatchResult | false {",
    "        match (obj)",
    "          case { node : AstNode →",
    "            if (kind == node.kind) then {",
    "                SuccessfulMatch.new (node, outer.emptySequence)",
    "            } else {",
    "                false",
    "            }",
    "        } case { _ → false }",
    "    }",
    "}",
    "",
    "// Same as Pattern??",
    "//type Matcher = {",
    "//    match(obj: AstNode) → MatchResult | false",
    "//}",
    "",
    "// A pattern that matches if parameter satisfies predicate",
    "class booleanPattern (predicate: Function1⟦AstNode⟧) → Pattern {",
    "    inherit BasicPattern.new",
    "    method match (obj: AstNode) → MatchResult | false{",
    "        if (predicate.apply (obj)) then {",
    "            SuccessfulMatch.new (obj, outer.emptySequence)",
    "        } else {",
    "            false",
    "        }",
    "    }",
    "}",
    "",
    "// patterns for built-in AST Nodes",
    "def If: Pattern is public = aPatternMatchingNode \"if\"",
    "def BlockLiteral: Pattern is public = aPatternMatchingNode \"block\"",
    "def MatchCase: Pattern is public = aPatternMatchingNode \"matchcase\"",
    "def TryCatch: Pattern is public = aPatternMatchingNode \"trycatch\"",
    "def Outer: Pattern is public = aPatternMatchingNode \"outer\"",
    "def MethodSignature: Pattern is public = aPatternMatchingNode \"methodtype\"",
    "def TypeLiteral: Pattern is public = aPatternMatchingNode \"typeliteral\"",
    "def TypeDeclaration: Pattern is public = aPatternMatchingNode \"typedec\"",
    "def TypeAnnotation: Pattern is public = aPatternMatchingNode \"dtype\"",
    "def Member: Pattern is public = aPatternMatchingNode \"member\"",
    "def Method: Pattern is public = aPatternMatchingNode \"method\"",
    "def Parameter: Pattern is public = aPatternMatchingNode \"parameter\"",
    "// matches anything that is a call",
    "def Request: Pattern is public = booleanPattern { x → x.isCall }",
    "def Class: Pattern is public = aPatternMatchingNode \"class\"",
    "def ObjectLiteral: Pattern is public = aPatternMatchingNode \"object\"",
    "def ArrayLiteral: Pattern is public = aPatternMatchingNode \"array\"",
    "def Generic: Pattern is public = aPatternMatchingNode \"generic\"",
    "def Identifier: Pattern is public = aPatternMatchingNode \"identifier\"",
    "def OctetsLiteral: Pattern is public = aPatternMatchingNode \"octets\"",
    "def StringLiteral: Pattern is public = aPatternMatchingNode \"string\"",
    "def NumberLiteral: Pattern is public = aPatternMatchingNode \"num\"",
    "def Operator: Pattern is public = aPatternMatchingNode \"op\"",
    "def Bind: Pattern is public = aPatternMatchingNode \"bind\"",
    "def Def: Pattern is public = aPatternMatchingNode \"defdec\"",
    "def Var: Pattern is public = aPatternMatchingNode \"vardec\"",
    "def Import: Pattern is public = aPatternMatchingNode \"import\"",
    "def Dialect: Pattern is public = aPatternMatchingNode \"dialect\"",
    "def Return: Pattern is public = aPatternMatchingNode \"return\"",
    "def Inherit: Pattern is public = aPatternMatchingNode \"inherit\"",
    "def Module: Pattern is public = aPatternMatchingNode \"module\"" ];
}
function gracecode_SharedTypes__46__old() {
  setModuleName("SharedTypes.old");
  importedModules["SharedTypes.old"] = this;
  var module$SharedTypes__46__old = this;
  this.definitionModule = "SharedTypes.old";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_SharedTypes__46__old_0");
  this.outer_SharedTypes__46__old_0 = var_prelude;
  setLineNumber(4);    // compilenode import
  // Import of "standardGrace" as sg
  if (typeof gracecode_standardGrace == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module standardGrace"));
  var var_sg = do_import("standardGrace", gracecode_standardGrace);
  var func0 = function(argcv) {     // accessor method sg
    if (var_sg === undefined) raiseUninitializedVariable("sg");
    return var_sg;
  };    // end of method sg
  this.methods["sg"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 4;
  func0.definitionModule = "SharedTypes.old";
  func0.debug = "import";
  func0.confidential = true;
  setModuleName("SharedTypes.old");
  setLineNumber(6);    // compilenode import
  // Import of "ast" as ast
  if (typeof gracecode_ast == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module ast"));
  var var_ast = do_import("ast", gracecode_ast);
  var func1 = function(argcv) {     // accessor method ast
    if (var_ast === undefined) raiseUninitializedVariable("ast");
    return var_ast;
  };    // end of method ast
  this.methods["ast"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 6;
  func1.definitionModule = "SharedTypes.old";
  func1.debug = "import";
  func1.confidential = true;
  setModuleName("SharedTypes.old");
  setLineNumber(7);    // compilenode import
  // Import of "xmodule" as xmodule
  if (typeof gracecode_xmodule == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module xmodule"));
  var var_xmodule = do_import("xmodule", gracecode_xmodule);
  var func2 = function(argcv) {     // accessor method xmodule
    if (var_xmodule === undefined) raiseUninitializedVariable("xmodule");
    return var_xmodule;
  };    // end of method xmodule
  this.methods["xmodule"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 7;
  func2.definitionModule = "SharedTypes.old";
  func2.debug = "import";
  func2.confidential = true;
  setModuleName("SharedTypes.old");
  setLineNumber(8);    // compilenode import
  // Import of "io" as io
  if (typeof gracecode_io == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module io"));
  var var_io = do_import("io", gracecode_io);
  var func3 = function(argcv) {     // accessor method io
    if (var_io === undefined) raiseUninitializedVariable("io");
    return var_io;
  };    // end of method io
  this.methods["io"] = func3;
  func3.paramCounts = [0];
  func3.paramNames = [];
  func3.typeParamNames = [];
  func3.definitionLine = 8;
  func3.definitionModule = "SharedTypes.old";
  func3.debug = "import";
  func3.confidential = true;
  setModuleName("SharedTypes.old");
  setLineNumber(10);    // reuse call
  var initFun4 = request(var_sg, "methods$build(3)", [null], this, [], []);  // compileReuseCall
  var func5 = function(argcv, var_str) {    // method stripNewLines(_), line 32
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("SharedTypes.old");
    setLineNumber(33);    // compilenode string
    var string7 = new GraceString("\n");
    var string8 = new GraceString(" ");
    // call case 6: other requests
    var call6 = request(var_str, "replace(1)with(1)", [1, 1], string7, string8);
    return call6;
  };    // end of method stripNewLines(_)
  func5.confidential = true;
  this.methods["stripNewLines(1)"] = func5;
  func5.paramCounts = [1];
  func5.paramNames = ["str"];
  func5.typeParamNames = [];
  func5.definitionLine = 32;
  func5.definitionModule = "SharedTypes.old";
  var func9 = function(argcv, var_kind) {    // method aPatternMatchingNode(_), line 187
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("aPatternMatchingNode(_)", "SharedTypes.old", 187);
    var ouc_init = this.methods["aPatternMatchingNode(1)$build(3)"].call(this, null, var_kind, ouc, [], []);
    ouc_init.call(ouc);
    return ouc;
  };    // end of method aPatternMatchingNode(_)
  func9.paramTypes = [];
  func9.paramTypes.push([type_String, "kind"]);
  this.methods["aPatternMatchingNode(1)"] = func9;
  func9.paramCounts = [1];
  func9.paramNames = ["kind"];
  func9.typeParamNames = [];
  func9.definitionLine = 187;
  func9.definitionModule = "SharedTypes.old";
  var func10 = function(argcv, var_kind, inheritingObject, aliases, exclusions) {    // method aPatternMatchingNode(_)$build(_,_,_), line 187
    var returnTarget = invocationCount;
    invocationCount++;
    var obj11_build = function(ignore, var_kind, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_SharedTypes__46__old_187");
      this.outer_SharedTypes__46__old_187 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      setLineNumber(188);    // compilenode member
      // call case 2: outer request
      var call12 = selfRequest(this.outer_SharedTypes__46__old_187, "BasicPattern", [0]);
      var initFun13 = request(call12, "new$build(3)", [null], this, [], []);  // compileReuseCall
      var func14 = function(argcv, var_obj) {    // method match(_), line 190
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("SharedTypes.old");
        setLineNumber(191);    // compilenode matchcase
        var cases15 = [];
        setLineNumber(192);    // compilenode block
        var block16 = new GraceBlock(this, 192, 1);
        block16.paramTypes = [var_AstNode];
        var matches17 = function(var_node) {
          setModuleName("SharedTypes.old");
          if (!Grace_isTrue(request(var_AstNode, "match(1)", [1], var_node)))
              return false;
          return true;
        };
        block16.guard = matches17;
        block16.real = function(var_node) {
          setModuleName("SharedTypes.old");
          var if18 = GraceDone;
          setLineNumber(193);    // compilenode member
          // call case 6: other requests
          var call19 = request(var_node, "kind", [0]);
          var opresult20 = request(var_kind, "==(1)", [1], call19);
          if (Grace_isTrue(opresult20)) {
            setLineNumber(194);    // compilenode member
            // call case 2: outer request
            var call22 = selfRequest(this.outer_SharedTypes__46__old_187, "emptySequence", [0]);
            // call case 6: other requests
            // call case 2: outer request
            var call23 = selfRequest(importedModules["SharedTypes.old"], "SuccessfulMatch", [0]);
            var call21 = request(call23, "new(2)", [2], var_node, call22);
            if18 = call21;
          } else {
            if18 = GraceFalse;
          }
          return if18;
        };
        cases15.push(block16);
        setLineNumber(198);    // compilenode block
        var block24 = new GraceBlock(this, 198, 1);
        var matches25 = function(var___95____95__1) {
          setModuleName("SharedTypes.old");
          return true;
        };
        block24.guard = matches25;
        block24.real = function(var___95____95__1) {
          setModuleName("SharedTypes.old");
          setLineNumber(198);    // compileBlock
          return GraceFalse;
        };
        cases15.push(block24);
        setLineNumber(191);    // compilematchcase
        var matchres15 = matchCase(var_obj,cases15);
        setModuleName("SharedTypes.old");
        return matchres15;
      };    // end of method match(_)
      func14.paramTypes = [];
      func14.paramTypes.push([type_Object, "obj"]);
      this.methods["match(1)"] = func14;
      func14.paramCounts = [1];
      func14.paramNames = ["obj"];
      func14.typeParamNames = [];
      func14.definitionLine = 190;
      func14.definitionModule = "SharedTypes.old";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj11_init = function() {    // init of object on line 187
        initFun13.call(this);
        setModuleName("SharedTypes.old");
      };
      return obj11_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj11_init = obj11_build.call(inheritingObject, null, var_kind, this, aliases, exclusions);
    return obj11_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method aPatternMatchingNode(_)$build(_,_,_)
  func10.paramTypes = [];
  func10.paramTypes.push([type_String, "kind"]);
  this.methods["aPatternMatchingNode(1)$build(3)"] = func10;
  func10.paramCounts = [1];
  func10.paramNames = ["kind"];
  func10.typeParamNames = [];
  func10.definitionLine = 187;
  func10.definitionModule = "SharedTypes.old";
  var func26 = function(argcv, var_predicate) {    // method booleanPattern(_), line 208
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("booleanPattern(_)", "SharedTypes.old", 208);
    var ouc_init = this.methods["booleanPattern(1)$build(3)"].call(this, null, var_predicate, ouc, [], []);
    ouc_init.call(ouc);
    return ouc;
  };    // end of method booleanPattern(_)
  this.methods["booleanPattern(1)"] = func26;
  func26.paramCounts = [1];
  func26.paramNames = ["predicate"];
  func26.typeParamNames = [];
  func26.definitionLine = 208;
  func26.definitionModule = "SharedTypes.old";
  var func27 = function(argcv, var_predicate, inheritingObject, aliases, exclusions) {    // method booleanPattern(_)$build(_,_,_), line 208
    var returnTarget = invocationCount;
    invocationCount++;
    var obj28_build = function(ignore, var_predicate, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_SharedTypes__46__old_208");
      this.outer_SharedTypes__46__old_208 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      setLineNumber(209);    // compilenode member
      // call case 2: outer request
      var call29 = selfRequest(importedModules["SharedTypes.old"], "BasicPattern", [0]);
      var initFun30 = request(call29, "new$build(3)", [null], this, [], []);  // compileReuseCall
      var func31 = function(argcv, var_obj) {    // method match(_), line 210
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("SharedTypes.old");
        var if32 = GraceDone;
        setLineNumber(211);    // compilenode call
        // call case 6: other requests
        var call33 = request(var_predicate, "apply(1)", [1], var_obj);
        if (Grace_isTrue(call33)) {
          setLineNumber(212);    // compilenode member
          // call case 2: outer request
          var call35 = selfRequest(this.outer_SharedTypes__46__old_208, "emptySequence", [0]);
          // call case 6: other requests
          // call case 2: outer request
          var call36 = selfRequest(importedModules["SharedTypes.old"], "SuccessfulMatch", [0]);
          var call34 = request(call36, "new(2)", [2], var_obj, call35);
          if32 = call34;
        } else {
          if32 = GraceFalse;
        }
        return if32;
      };    // end of method match(_)
      func31.paramTypes = [];
      func31.paramTypes.push([]);
      this.methods["match(1)"] = func31;
      func31.paramCounts = [1];
      func31.paramNames = ["obj"];
      func31.typeParamNames = [];
      func31.definitionLine = 210;
      func31.definitionModule = "SharedTypes.old";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj28_init = function() {    // init of object on line 208
        initFun30.call(this);
        setModuleName("SharedTypes.old");
      };
      return obj28_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj28_init = obj28_build.call(inheritingObject, null, var_predicate, this, aliases, exclusions);
    return obj28_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method booleanPattern(_)$build(_,_,_)
  this.methods["booleanPattern(1)$build(3)"] = func27;
  func27.paramCounts = [1];
  func27.paramNames = ["predicate"];
  func27.typeParamNames = [];
  func27.definitionLine = 208;
  func27.definitionModule = "SharedTypes.old";
  initFun4.call(this);
  setLineNumber(13);    // compilenode object
  var obj37_build = function(ignore, outerObj, aliases, exclusions) {
    this.closureKeys = this.closureKeys || [];
    this.closureKeys.push("outer_SharedTypes__46__old_13");
    this.outer_SharedTypes__46__old_13 = outerObj;
    var inheritedExclusions = { };
    for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
        var exMeth = exclusions[eix];
        inheritedExclusions[exMeth] = this.methods[exMeth];
    }
    setLineNumber(14);    // compilenode member
    // call case 2: outer request
    var call38 = selfRequest(importedModules["SharedTypes.old"], "BasicPattern", [0]);
    var initFun39 = request(call38, "new$build(3)", [null], this, [], []);  // compileReuseCall
    var func40 = function(argcv, var_obj) {    // method match(_), line 16
      var returnTarget = invocationCount;
      invocationCount++;
      setModuleName("SharedTypes.old");
      var if41 = GraceDone;
      setLineNumber(17);    // compilenode call
      // call case 4: self request
      var call42 = selfRequest(this, "isMe(1)", [1], var_obj);
      if (Grace_isTrue(call42)) {
        setLineNumber(18);    // compilenode array
        var array45 = new PrimitiveGraceList([]);
        // call case 2: outer request
        var call44 = selfRequest(importedModules["SharedTypes.old"], "list(1)", [1], array45);
        // call case 6: other requests
        // call case 2: outer request
        var call46 = selfRequest(importedModules["SharedTypes.old"], "SuccessfulMatch", [0]);
        var call43 = request(call46, "new(2)", [2], this, call44);
        if41 = call43;
      } else {
        setLineNumber(20);    // compilenode call
        // call case 6: other requests
        // call case 2: outer request
        var call48 = selfRequest(importedModules["SharedTypes.old"], "FailedMatch", [0]);
        var call47 = request(call48, "new(1)", [1], var_obj);
        if41 = call47;
      }
      return if41;
    };    // end of method match(_)
    func40.paramTypes = [];
    func40.paramTypes.push([type_Object, "obj"]);
    this.methods["match(1)"] = func40;
    func40.paramCounts = [1];
    func40.paramNames = ["obj"];
    func40.typeParamNames = [];
    func40.definitionLine = 16;
    func40.definitionModule = "SharedTypes.old";
    for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
        var oneAlias = aliases[aix];
        this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
    }
    for (var exName in inheritedExclusions) {
        if (inheritedExclusions.hasOwnProperty(exName)) {
            if (inheritedExclusions[exName]) {
                this.methods[exName] = inheritedExclusions[exName];
            } else {
                delete this.methods[exName];
            }
        }
    }
    var obj37_init = function() {    // init of object on line 13
      initFun39.call(this);
      setModuleName("SharedTypes.old");
    };
    return obj37_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
  };
  var obj37 = emptyGraceObject("noSuchMethod", "SharedTypes.old", 13);
  var obj37_init = obj37_build.call(obj37, null, this, [], []);
  obj37_init.call(obj37);  // end of compileobject
  var var_noSuchMethod = obj37;
  var reader49_noSuchMethod = function() {  // reader method noSuchMethod
      if (var_noSuchMethod === undefined) raiseUninitializedVariable("noSuchMethod");
      return var_noSuchMethod;
  };
  reader49_noSuchMethod.isDef = true;
  reader49_noSuchMethod.confidential = true;
  this.methods["noSuchMethod"] = reader49_noSuchMethod;
  setLineNumber(37);    // compilenode typedec
  // Type decl TypePair
  //   Type literal 
  var typeLit51 = new GraceType("TypePair");
  typeLit51.typeMethods.push("first");
  typeLit51.typeMethods.push("second");
  typeLit51.typeMethods.push("==(1)");
  typeLit51.typeMethods.push("asString");
  var var_TypePair = typeLit51;
  var type50 = typeLit51;
  var func52 = function(argcv) {     // accessor method TypePair
    return var_TypePair;
  };    // end of method TypePair
  this.methods["TypePair"] = func52;
  func52.paramCounts = [0];
  func52.paramNames = [];
  func52.typeParamNames = [];
  func52.definitionLine = 1;
  func52.definitionModule = "SharedTypes.old";
  setLineNumber(45);    // compilenode typedec
  // Type decl Answer
  //   Type literal 
  var typeLit54 = new GraceType("Answer");
  typeLit54.typeMethods.push("ans");
  typeLit54.typeMethods.push("trials");
  typeLit54.typeMethods.push("asString");
  var var_Answer = typeLit54;
  var type53 = typeLit54;
  var func55 = function(argcv) {     // accessor method Answer
    return var_Answer;
  };    // end of method Answer
  this.methods["Answer"] = func55;
  func55.paramCounts = [0];
  func55.paramNames = [];
  func55.typeParamNames = [];
  func55.definitionLine = 1;
  func55.definitionModule = "SharedTypes.old";
  setLineNumber(52);    // compilenode typedec
  // Type decl TypeOp
  //   Type literal 
  var typeLit57 = new GraceType("TypeOp");
  typeLit57.typeMethods.push("op");
  typeLit57.typeMethods.push("left");
  typeLit57.typeMethods.push("right");
  var var_TypeOp = typeLit57;
  var type56 = typeLit57;
  var func58 = function(argcv) {     // accessor method TypeOp
    return var_TypeOp;
  };    // end of method TypeOp
  this.methods["TypeOp"] = func58;
  func58.paramCounts = [0];
  func58.paramNames = [];
  func58.typeParamNames = [];
  func58.definitionLine = 1;
  func58.definitionModule = "SharedTypes.old";
  setLineNumber(59);    // compilenode typedec
  // Type decl Param
  //   Type literal 
  var typeLit60 = new GraceType("Param");
  typeLit60.typeMethods.push("name");
  typeLit60.typeMethods.push("typeAnnotation");
  var var_Param = typeLit60;
  var type59 = typeLit60;
  var func61 = function(argcv) {     // accessor method Param
    return var_Param;
  };    // end of method Param
  this.methods["Param"] = func61;
  func61.paramCounts = [0];
  func61.paramNames = [];
  func61.typeParamNames = [];
  func61.definitionLine = 1;
  func61.definitionModule = "SharedTypes.old";
  setLineNumber(64);    // compilenode typedec
  // Type decl ParamFactory
  //   Type literal 
  var typeLit63 = new GraceType("ParamFactory");
  typeLit63.typeMethods.push("withName(1)ofType(1)");
  typeLit63.typeMethods.push("ofType(1)");
  var var_ParamFactory = typeLit63;
  var type62 = typeLit63;
  var func64 = function(argcv) {     // accessor method ParamFactory
    return var_ParamFactory;
  };    // end of method ParamFactory
  this.methods["ParamFactory"] = func64;
  func64.paramCounts = [0];
  func64.paramNames = [];
  func64.typeParamNames = [];
  func64.definitionLine = 1;
  func64.definitionModule = "SharedTypes.old";
  setLineNumber(71);    // compilenode typedec
  // Type decl MixPart
  //   Type literal 
  var typeLit66 = new GraceType("MixPart");
  typeLit66.typeMethods.push("name");
  typeLit66.typeMethods.push("parameters");
  var var_MixPart = typeLit66;
  var type65 = typeLit66;
  var func67 = function(argcv) {     // accessor method MixPart
    return var_MixPart;
  };    // end of method MixPart
  this.methods["MixPart"] = func67;
  func67.paramCounts = [0];
  func67.paramNames = [];
  func67.typeParamNames = [];
  func67.definitionLine = 1;
  func67.definitionModule = "SharedTypes.old";
  setLineNumber(78);    // compilenode typedec
  // Type decl MethodType
  //   Type literal 
  var typeLit69 = new GraceType("MethodType");
  typeLit69.typeMethods.push("name");
  typeLit69.typeMethods.push("nameString");
  typeLit69.typeMethods.push("signature");
  typeLit69.typeMethods.push("retType");
  typeLit69.typeMethods.push("typeParams");
  typeLit69.typeMethods.push("hasTypeParams");
  typeLit69.typeMethods.push("==(1)");
  typeLit69.typeMethods.push("restriction(1)");
  typeLit69.typeMethods.push("isSpecialisationOf(2)");
  typeLit69.typeMethods.push("apply(1)");
  typeLit69.typeMethods.push("replaceGenericsWith(1)");
  var var_MethodType = typeLit69;
  var type68 = typeLit69;
  var func70 = function(argcv) {     // accessor method MethodType
    return var_MethodType;
  };    // end of method MethodType
  this.methods["MethodType"] = func70;
  func70.paramCounts = [0];
  func70.paramNames = [];
  func70.typeParamNames = [];
  func70.definitionLine = 1;
  func70.definitionModule = "SharedTypes.old";
  setLineNumber(115);    // compilenode typedec
  // Type decl MethodTypeFactory
  //   Type literal 
  var typeLit72 = new GraceType("MethodTypeFactory");
  typeLit72.typeMethods.push("signature(1)returnType(1)");
  typeLit72.typeMethods.push("member(1)ofType(1)");
  typeLit72.typeMethods.push("fromGctLine(2)");
  typeLit72.typeMethods.push("fromNode(1)");
  var var_MethodTypeFactory = typeLit72;
  var type71 = typeLit72;
  var func73 = function(argcv) {     // accessor method MethodTypeFactory
    return var_MethodTypeFactory;
  };    // end of method MethodTypeFactory
  this.methods["MethodTypeFactory"] = func73;
  func73.paramCounts = [0];
  func73.paramNames = [];
  func73.typeParamNames = [];
  func73.definitionLine = 1;
  func73.definitionModule = "SharedTypes.old";
  setLineNumber(123);    // compilenode typedec
  // Type decl GenericType
  //   Type literal 
  var typeLit75 = new GraceType("GenericType");
  typeLit75.typeMethods.push("name");
  typeLit75.typeMethods.push("typeParams");
  typeLit75.typeMethods.push("oType");
  typeLit75.typeMethods.push("apply(1)");
  var var_GenericType = typeLit75;
  var type74 = typeLit75;
  var func76 = function(argcv) {     // accessor method GenericType
    return var_GenericType;
  };    // end of method GenericType
  this.methods["GenericType"] = func76;
  func76.paramCounts = [0];
  func76.paramNames = [];
  func76.typeParamNames = [];
  func76.definitionLine = 1;
  func76.definitionModule = "SharedTypes.old";
  setLineNumber(130);    // compilenode typedec
  // Type decl GenericTypeFactory
  //   Type literal 
  var typeLit78 = new GraceType("GenericTypeFactory");
  typeLit78.typeMethods.push("fromName(1)parameters(1)objectType(1)");
  typeLit78.typeMethods.push("fromTypeDec(1)");
  var var_GenericTypeFactory = typeLit78;
  var type77 = typeLit78;
  var func79 = function(argcv) {     // accessor method GenericTypeFactory
    return var_GenericTypeFactory;
  };    // end of method GenericTypeFactory
  this.methods["GenericTypeFactory"] = func79;
  func79.paramCounts = [0];
  func79.paramNames = [];
  func79.typeParamNames = [];
  func79.definitionLine = 1;
  func79.definitionModule = "SharedTypes.old";
  setLineNumber(136);    // compilenode typedec
  // Type decl ObjectType
  //   Type literal 
  var typeLit81 = new GraceType("ObjectType");
  typeLit81.typeMethods.push("methods");
  typeLit81.typeMethods.push("getMethod(1)");
  typeLit81.typeMethods.push("resolve");
  typeLit81.typeMethods.push("isResolved");
  typeLit81.typeMethods.push("isOp");
  typeLit81.typeMethods.push("isDynamic");
  typeLit81.typeMethods.push("==(1)");
  typeLit81.typeMethods.push("isSubtypeOf(1)");
  typeLit81.typeMethods.push("isSubtypeHelper(2)");
  typeLit81.typeMethods.push("restriction(1)");
  typeLit81.typeMethods.push("isConsistentSubtypeOf(1)");
  typeLit81.typeMethods.push("getVariantTypes");
  typeLit81.typeMethods.push("setVariantTypes(1)");
  typeLit81.typeMethods.push("getOpNode");
  typeLit81.typeMethods.push("setOpNode(1)");
  typeLit81.typeMethods.push("|(1)");
  typeLit81.typeMethods.push("&(1)");
  var var_ObjectType = typeLit81;
  var type80 = typeLit81;
  var func82 = function(argcv) {     // accessor method ObjectType
    return var_ObjectType;
  };    // end of method ObjectType
  this.methods["ObjectType"] = func82;
  func82.paramCounts = [0];
  func82.paramNames = [];
  func82.typeParamNames = [];
  func82.definitionLine = 1;
  func82.definitionModule = "SharedTypes.old";
  setLineNumber(157);    // compilenode typedec
  // Type decl ObjectTypeFactory
  //   Type literal 
  var typeLit84 = new GraceType("ObjectTypeFactory");
  typeLit84.typeMethods.push("definedByNode(1)");
  typeLit84.typeMethods.push("fromMethods(1)");
  typeLit84.typeMethods.push("fromMethods(1)withName(1)");
  typeLit84.typeMethods.push("fromDType(1)");
  typeLit84.typeMethods.push("fromGeneric(1)");
  typeLit84.typeMethods.push("fromIdentifier(1)");
  typeLit84.typeMethods.push("dynamic");
  typeLit84.typeMethods.push("bottom");
  typeLit84.typeMethods.push("blockTaking(1)returning(1)");
  typeLit84.typeMethods.push("blockReturning(1)");
  typeLit84.typeMethods.push("preludeTypes");
  typeLit84.typeMethods.push("base");
  typeLit84.typeMethods.push("doneType");
  typeLit84.typeMethods.push("pattern");
  typeLit84.typeMethods.push("iterator");
  typeLit84.typeMethods.push("boolean");
  typeLit84.typeMethods.push("number");
  typeLit84.typeMethods.push("string");
  typeLit84.typeMethods.push("listTp");
  typeLit84.typeMethods.push("set");
  typeLit84.typeMethods.push("sequence");
  typeLit84.typeMethods.push("dictionary");
  typeLit84.typeMethods.push("point");
  typeLit84.typeMethods.push("binding");
  var var_ObjectTypeFactory = typeLit84;
  var type83 = typeLit84;
  var func85 = function(argcv) {     // accessor method ObjectTypeFactory
    return var_ObjectTypeFactory;
  };    // end of method ObjectTypeFactory
  this.methods["ObjectTypeFactory"] = func85;
  func85.paramCounts = [0];
  func85.paramNames = [];
  func85.typeParamNames = [];
  func85.definitionLine = 1;
  func85.definitionModule = "SharedTypes.old";
  setLineNumber(184);    // compilenode typedec
  // Type decl AstNode
  //   Type literal 
  var typeLit87 = new GraceType("AstNode");
  typeLit87.typeMethods.push("kind");
  var var_AstNode = typeLit87;
  var type86 = typeLit87;
  var func88 = function(argcv) {     // accessor method AstNode
    return var_AstNode;
  };    // end of method AstNode
  this.methods["AstNode"] = func88;
  func88.paramCounts = [0];
  func88.paramNames = [];
  func88.typeParamNames = [];
  func88.definitionLine = 1;
  func88.definitionModule = "SharedTypes.old";
  setLineNumber(220);    // compilenode string
  var string90 = new GraceString("if");
  // call case 2: outer request
  var call89 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string90);
  var var_If = call89;
  var reader91_If = function() {  // reader method If
      if (var_If === undefined) raiseUninitializedVariable("If");
      return var_If;
  };
  reader91_If.isDef = true;
  this.methods["If"] = reader91_If;
  setLineNumber(221);    // compilenode string
  var string93 = new GraceString("block");
  // call case 2: outer request
  var call92 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string93);
  var var_BlockLiteral = call92;
  var reader94_BlockLiteral = function() {  // reader method BlockLiteral
      if (var_BlockLiteral === undefined) raiseUninitializedVariable("BlockLiteral");
      return var_BlockLiteral;
  };
  reader94_BlockLiteral.isDef = true;
  this.methods["BlockLiteral"] = reader94_BlockLiteral;
  setLineNumber(222);    // compilenode string
  var string96 = new GraceString("matchcase");
  // call case 2: outer request
  var call95 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string96);
  var var_MatchCase = call95;
  var reader97_MatchCase = function() {  // reader method MatchCase
      if (var_MatchCase === undefined) raiseUninitializedVariable("MatchCase");
      return var_MatchCase;
  };
  reader97_MatchCase.isDef = true;
  this.methods["MatchCase"] = reader97_MatchCase;
  setLineNumber(223);    // compilenode string
  var string99 = new GraceString("trycatch");
  // call case 2: outer request
  var call98 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string99);
  var var_TryCatch = call98;
  var reader100_TryCatch = function() {  // reader method TryCatch
      if (var_TryCatch === undefined) raiseUninitializedVariable("TryCatch");
      return var_TryCatch;
  };
  reader100_TryCatch.isDef = true;
  this.methods["TryCatch"] = reader100_TryCatch;
  setLineNumber(224);    // compilenode string
  var string102 = new GraceString("outer");
  // call case 2: outer request
  var call101 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string102);
  var var_Outer = call101;
  var reader103_Outer = function() {  // reader method Outer
      if (var_Outer === undefined) raiseUninitializedVariable("Outer");
      return var_Outer;
  };
  reader103_Outer.isDef = true;
  this.methods["Outer"] = reader103_Outer;
  setLineNumber(225);    // compilenode string
  var string105 = new GraceString("methodtype");
  // call case 2: outer request
  var call104 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string105);
  var var_MethodSignature = call104;
  var reader106_MethodSignature = function() {  // reader method MethodSignature
      if (var_MethodSignature === undefined) raiseUninitializedVariable("MethodSignature");
      return var_MethodSignature;
  };
  reader106_MethodSignature.isDef = true;
  this.methods["MethodSignature"] = reader106_MethodSignature;
  setLineNumber(226);    // compilenode string
  var string108 = new GraceString("typeliteral");
  // call case 2: outer request
  var call107 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string108);
  var var_TypeLiteral = call107;
  var reader109_TypeLiteral = function() {  // reader method TypeLiteral
      if (var_TypeLiteral === undefined) raiseUninitializedVariable("TypeLiteral");
      return var_TypeLiteral;
  };
  reader109_TypeLiteral.isDef = true;
  this.methods["TypeLiteral"] = reader109_TypeLiteral;
  setLineNumber(227);    // compilenode string
  var string111 = new GraceString("typedec");
  // call case 2: outer request
  var call110 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string111);
  var var_TypeDeclaration = call110;
  var reader112_TypeDeclaration = function() {  // reader method TypeDeclaration
      if (var_TypeDeclaration === undefined) raiseUninitializedVariable("TypeDeclaration");
      return var_TypeDeclaration;
  };
  reader112_TypeDeclaration.isDef = true;
  this.methods["TypeDeclaration"] = reader112_TypeDeclaration;
  setLineNumber(228);    // compilenode string
  var string114 = new GraceString("dtype");
  // call case 2: outer request
  var call113 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string114);
  var var_TypeAnnotation = call113;
  var reader115_TypeAnnotation = function() {  // reader method TypeAnnotation
      if (var_TypeAnnotation === undefined) raiseUninitializedVariable("TypeAnnotation");
      return var_TypeAnnotation;
  };
  reader115_TypeAnnotation.isDef = true;
  this.methods["TypeAnnotation"] = reader115_TypeAnnotation;
  setLineNumber(229);    // compilenode string
  var string117 = new GraceString("member");
  // call case 2: outer request
  var call116 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string117);
  var var_Member = call116;
  var reader118_Member = function() {  // reader method Member
      if (var_Member === undefined) raiseUninitializedVariable("Member");
      return var_Member;
  };
  reader118_Member.isDef = true;
  this.methods["Member"] = reader118_Member;
  setLineNumber(230);    // compilenode string
  var string120 = new GraceString("method");
  // call case 2: outer request
  var call119 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string120);
  var var_Method = call119;
  var reader121_Method = function() {  // reader method Method
      if (var_Method === undefined) raiseUninitializedVariable("Method");
      return var_Method;
  };
  reader121_Method.isDef = true;
  this.methods["Method"] = reader121_Method;
  setLineNumber(231);    // compilenode string
  var string123 = new GraceString("parameter");
  // call case 2: outer request
  var call122 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string123);
  var var_Parameter = call122;
  var reader124_Parameter = function() {  // reader method Parameter
      if (var_Parameter === undefined) raiseUninitializedVariable("Parameter");
      return var_Parameter;
  };
  reader124_Parameter.isDef = true;
  this.methods["Parameter"] = reader124_Parameter;
  setLineNumber(233);    // compilenode block
  var block126 = new GraceBlock(this, 233, 1);
  var matches127 = function(var_x) {
    setModuleName("SharedTypes.old");
    return true;
  };
  block126.guard = matches127;
  block126.real = function(var_x) {
    setModuleName("SharedTypes.old");
    setLineNumber(233);    // compilenode member
    // call case 6: other requests
    var call128 = request(var_x, "isCall", [0]);
    return call128;
  };
  // call case 2: outer request
  var call125 = selfRequest(importedModules["SharedTypes.old"], "booleanPattern(1)", [1], block126);
  var var_Request = call125;
  var reader129_Request = function() {  // reader method Request
      if (var_Request === undefined) raiseUninitializedVariable("Request");
      return var_Request;
  };
  reader129_Request.isDef = true;
  this.methods["Request"] = reader129_Request;
  setLineNumber(234);    // compilenode string
  var string131 = new GraceString("class");
  // call case 2: outer request
  var call130 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string131);
  var var_Class = call130;
  var reader132_Class = function() {  // reader method Class
      if (var_Class === undefined) raiseUninitializedVariable("Class");
      return var_Class;
  };
  reader132_Class.isDef = true;
  this.methods["Class"] = reader132_Class;
  setLineNumber(235);    // compilenode string
  var string134 = new GraceString("object");
  // call case 2: outer request
  var call133 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string134);
  var var_ObjectLiteral = call133;
  var reader135_ObjectLiteral = function() {  // reader method ObjectLiteral
      if (var_ObjectLiteral === undefined) raiseUninitializedVariable("ObjectLiteral");
      return var_ObjectLiteral;
  };
  reader135_ObjectLiteral.isDef = true;
  this.methods["ObjectLiteral"] = reader135_ObjectLiteral;
  setLineNumber(236);    // compilenode string
  var string137 = new GraceString("array");
  // call case 2: outer request
  var call136 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string137);
  var var_ArrayLiteral = call136;
  var reader138_ArrayLiteral = function() {  // reader method ArrayLiteral
      if (var_ArrayLiteral === undefined) raiseUninitializedVariable("ArrayLiteral");
      return var_ArrayLiteral;
  };
  reader138_ArrayLiteral.isDef = true;
  this.methods["ArrayLiteral"] = reader138_ArrayLiteral;
  setLineNumber(237);    // compilenode string
  var string140 = new GraceString("generic");
  // call case 2: outer request
  var call139 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string140);
  var var_Generic = call139;
  var reader141_Generic = function() {  // reader method Generic
      if (var_Generic === undefined) raiseUninitializedVariable("Generic");
      return var_Generic;
  };
  reader141_Generic.isDef = true;
  this.methods["Generic"] = reader141_Generic;
  setLineNumber(238);    // compilenode string
  var string143 = new GraceString("identifier");
  // call case 2: outer request
  var call142 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string143);
  var var_Identifier = call142;
  var reader144_Identifier = function() {  // reader method Identifier
      if (var_Identifier === undefined) raiseUninitializedVariable("Identifier");
      return var_Identifier;
  };
  reader144_Identifier.isDef = true;
  this.methods["Identifier"] = reader144_Identifier;
  setLineNumber(239);    // compilenode string
  var string146 = new GraceString("octets");
  // call case 2: outer request
  var call145 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string146);
  var var_OctetsLiteral = call145;
  var reader147_OctetsLiteral = function() {  // reader method OctetsLiteral
      if (var_OctetsLiteral === undefined) raiseUninitializedVariable("OctetsLiteral");
      return var_OctetsLiteral;
  };
  reader147_OctetsLiteral.isDef = true;
  this.methods["OctetsLiteral"] = reader147_OctetsLiteral;
  setLineNumber(240);    // compilenode string
  var string149 = new GraceString("string");
  // call case 2: outer request
  var call148 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string149);
  var var_StringLiteral = call148;
  var reader150_StringLiteral = function() {  // reader method StringLiteral
      if (var_StringLiteral === undefined) raiseUninitializedVariable("StringLiteral");
      return var_StringLiteral;
  };
  reader150_StringLiteral.isDef = true;
  this.methods["StringLiteral"] = reader150_StringLiteral;
  setLineNumber(241);    // compilenode string
  var string152 = new GraceString("num");
  // call case 2: outer request
  var call151 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string152);
  var var_NumberLiteral = call151;
  var reader153_NumberLiteral = function() {  // reader method NumberLiteral
      if (var_NumberLiteral === undefined) raiseUninitializedVariable("NumberLiteral");
      return var_NumberLiteral;
  };
  reader153_NumberLiteral.isDef = true;
  this.methods["NumberLiteral"] = reader153_NumberLiteral;
  setLineNumber(242);    // compilenode string
  var string155 = new GraceString("op");
  // call case 2: outer request
  var call154 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string155);
  var var_Operator = call154;
  var reader156_Operator = function() {  // reader method Operator
      if (var_Operator === undefined) raiseUninitializedVariable("Operator");
      return var_Operator;
  };
  reader156_Operator.isDef = true;
  this.methods["Operator"] = reader156_Operator;
  setLineNumber(243);    // compilenode string
  var string158 = new GraceString("bind");
  // call case 2: outer request
  var call157 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string158);
  var var_Bind = call157;
  var reader159_Bind = function() {  // reader method Bind
      if (var_Bind === undefined) raiseUninitializedVariable("Bind");
      return var_Bind;
  };
  reader159_Bind.isDef = true;
  this.methods["Bind"] = reader159_Bind;
  setLineNumber(244);    // compilenode string
  var string161 = new GraceString("defdec");
  // call case 2: outer request
  var call160 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string161);
  var var_Def = call160;
  var reader162_Def = function() {  // reader method Def
      if (var_Def === undefined) raiseUninitializedVariable("Def");
      return var_Def;
  };
  reader162_Def.isDef = true;
  this.methods["Def"] = reader162_Def;
  setLineNumber(245);    // compilenode string
  var string164 = new GraceString("vardec");
  // call case 2: outer request
  var call163 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string164);
  var var_Var = call163;
  var reader165_Var = function() {  // reader method Var
      if (var_Var === undefined) raiseUninitializedVariable("Var");
      return var_Var;
  };
  reader165_Var.isDef = true;
  this.methods["Var"] = reader165_Var;
  setLineNumber(246);    // compilenode string
  var string167 = new GraceString("import");
  // call case 2: outer request
  var call166 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string167);
  var var_Import = call166;
  var reader168_Import = function() {  // reader method Import
      if (var_Import === undefined) raiseUninitializedVariable("Import");
      return var_Import;
  };
  reader168_Import.isDef = true;
  this.methods["Import"] = reader168_Import;
  setLineNumber(247);    // compilenode string
  var string170 = new GraceString("dialect");
  // call case 2: outer request
  var call169 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string170);
  var var_Dialect = call169;
  var reader171_Dialect = function() {  // reader method Dialect
      if (var_Dialect === undefined) raiseUninitializedVariable("Dialect");
      return var_Dialect;
  };
  reader171_Dialect.isDef = true;
  this.methods["Dialect"] = reader171_Dialect;
  setLineNumber(248);    // compilenode string
  var string173 = new GraceString("return");
  // call case 2: outer request
  var call172 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string173);
  var var_Return = call172;
  var reader174_Return = function() {  // reader method Return
      if (var_Return === undefined) raiseUninitializedVariable("Return");
      return var_Return;
  };
  reader174_Return.isDef = true;
  this.methods["Return"] = reader174_Return;
  setLineNumber(249);    // compilenode string
  var string176 = new GraceString("inherit");
  // call case 2: outer request
  var call175 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string176);
  var var_Inherit = call175;
  var reader177_Inherit = function() {  // reader method Inherit
      if (var_Inherit === undefined) raiseUninitializedVariable("Inherit");
      return var_Inherit;
  };
  reader177_Inherit.isDef = true;
  this.methods["Inherit"] = reader177_Inherit;
  setLineNumber(250);    // compilenode string
  var string179 = new GraceString("module");
  // call case 2: outer request
  var call178 = selfRequest(importedModules["SharedTypes.old"], "aPatternMatchingNode(1)", [1], string179);
  var var_Module = call178;
  var reader180_Module = function() {  // reader method Module
      if (var_Module === undefined) raiseUninitializedVariable("Module");
      return var_Module;
  };
  reader180_Module.isDef = true;
  this.methods["Module"] = reader180_Module;
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_SharedTypes__46__old = gracecode_SharedTypes__46__old;
if (typeof window !== "undefined")
  window.gracecode_SharedTypes__46__old = gracecode_SharedTypes__46__old;
gracecode_SharedTypes__46__old.imports = ["ast", "io", "standardGrace", "xmodule"];
