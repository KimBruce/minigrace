;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["ShortCircuit"] = "classes:\nconfidential:\n x\n x:=(x': Number) \u2192 Done\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/ShortCircuit.grace\npublic:\npublicMethodTypes:\ntypes:\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["ShortCircuit"] = [
    "dialect \"StaticTyping\"",
    "",
    "var x: Number := 0",
    "",
    "if ((x == 0) || ((2/x) > 0)) then {",
    "    print \"OK\"",
    "} else {",
    "    print \"not OK\"",
    "}" ];
}
function gracecode_ShortCircuit() {
  setModuleName("ShortCircuit");
  importedModules["ShortCircuit"] = this;
  var module$ShortCircuit = this;
  this.definitionModule = "ShortCircuit";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_ShortCircuit_0");
  this.outer_ShortCircuit_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(3);    // typecheck
  assertTypeOrMsg(new GraceNum(0), var_Number, "initial value of var x", "Number");
  var var_x = new GraceNum(0);
  var reader0_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader0_x.isVar = true;
  reader0_x.confidential = true;
  this.methods["x"] = reader0_x;
  var writer1_x = function(argcv, n) {   // writer method x:=(_)
    assertTypeOrMsg(n, var_Number, "argument to x:=(_)", "Number");
    var_x = n;
    return GraceDone;
  };
  writer1_x.confidential = true;
  this.methods["x:=(1)"] = writer1_x;
  var if2 = GraceDone;
  setLineNumber(5);    // compilenode num
  var opresult3 = request(var_x, "==(1)", [1], new GraceNum(0));
  var quotient4 = request(new GraceNum(2), "/(1)", [1], var_x);
  var opresult5 = request(quotient4, ">(1)", [1], new GraceNum(0));
  var opresult6 = request(opresult3, "||(1)", [1], opresult5);
  if (Grace_isTrue(opresult6)) {
    setLineNumber(6);    // compilenode string
    var string7 = new GraceString("OK");
    Grace_print(string7);
    if2 = GraceDone;
  } else {
    setLineNumber(8);    // compilenode string
    var string8 = new GraceString("not OK");
    Grace_print(string8);
    if2 = GraceDone;
  }
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_ShortCircuit = gracecode_ShortCircuit;
if (typeof window !== "undefined")
  window.gracecode_ShortCircuit = gracecode_ShortCircuit;
gracecode_ShortCircuit.imports = ["StaticTyping"];
