;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["classCircle"] = "classes:\nconfidential:\n z\ndialect:\n StaticTyping\nfresh-methods:\n a\n b\nfresh:a:\n print\n x\n x:=(_)\nfresh:b:\n ::(1)\n aprint\n asDebugString\n asString\n basicAsString\n isMe(1)\n print\n x\n y\n y:=(_)\n \u2260(1)\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/classCircle.grace\npublic:\n A\n a\n b\npublicMethod:a:\n a \u2192 A\npublicMethod:b:\n b \u2192 A\npublicMethodTypes:\n a \u2192 A\n b \u2192 A\ntypedec-of:A:\n type A = interface {\n            print \u2192 Done}\ntypes:\n A\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["classCircle"] = [
    "dialect \"StaticTyping\"",
    "",
    "type A = {",
    "    print → Done",
    "}",
    "",
    "class a → A {",
    "    var x: Number := 0",
    "    method print -> Done {print \"in class a with {x} using {z}\"}",
    "}",
    "",
    "class b -> A {",
    "    inherit a ",
    "        alias aprint = print",
    "    var y: Number := 99",
    "    method print -> Done {",
    "        aprint",
    "        print \"in class b with {x} and {y}\"",
    "    }",
    "}",
    "",
    "def z: Number = 0",
    "    ",
    "b.print" ];
}
function gracecode_classCircle() {
  setModuleName("classCircle");
  importedModules["classCircle"] = this;
  var module$classCircle = this;
  this.definitionModule = "classCircle";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_classCircle_0");
  this.outer_classCircle_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method a, line 7
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("a", "classCircle", 7);
    var ouc_init = this.methods["a$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(18);    // typecheck
    assertTypeOrMsg(ouc, var_A, "object returned from a", "A");
    return ouc;
  };    // end of method a
  this.methods["a"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 7;
  func0.definitionModule = "classCircle";
  var func1 = function(argcv, inheritingObject, aliases, exclusions) {    // method a$build(_,_,_), line 7
    var returnTarget = invocationCount;
    invocationCount++;
    var obj2_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_classCircle_7");
      this.outer_classCircle_7 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      this.data.x = undefined;
      var reader3_x = function() {  // reader method x
          if (this.data.x === undefined) raiseUninitializedVariable("x");
          return this.data.x;
      };
      reader3_x.isVar = true;
      reader3_x.confidential = true;
      this.methods["x"] = reader3_x;
      var writer4_x = function(argcv, n) {   // writer method x:=(_)
        assertTypeOrMsg(n, var_Number, "argument to x:=(_)", "Number");
        this.data.x = n;
        return GraceDone;
      };
      writer4_x.confidential = true;
      this.methods["x:=(1)"] = writer4_x;
      var func5 = function(argcv) {    // method print, line 9
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("classCircle");
        setLineNumber(9);    // compilenode string
        var string6 = new GraceString("in class a with ");
        // call case 4: self request
        var call7 = selfRequest(this, "x", [0]);
        var opresult8 = request(string6, "++(1)", [1], call7);
        var string9 = new GraceString(" using ");
        var opresult10 = request(opresult8, "++(1)", [1], string9);
        if (var_z === undefined) raiseUninitializedVariable("z");
        var opresult11 = request(opresult10, "++(1)", [1], var_z);
        var string12 = new GraceString("");
        var opresult13 = request(opresult11, "++(1)", [1], string12);
        Grace_print(opresult13);
        return GraceDone;
      };    // end of method print
      this.methods["print"] = func5;
      func5.paramCounts = [0];
      func5.paramNames = [];
      func5.typeParamNames = [];
      func5.definitionLine = 9;
      func5.definitionModule = "classCircle";
      this.mutable = true;
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 7
        setModuleName("classCircle");
        setLineNumber(8);    // typecheck
        assertTypeOrMsg(new GraceNum(0), var_Number, "value assigned to x", "Number");
        this.data.x = new GraceNum(0);
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method a$build(_,_,_)
  this.methods["a$build(3)"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 7;
  func1.definitionModule = "classCircle";
  var func14 = function(argcv) {    // method b, line 12
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("b", "classCircle", 12);
    var ouc_init = this.methods["b$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_A, "object returned from b", "A");
    return ouc;
  };    // end of method b
  this.methods["b"] = func14;
  func14.paramCounts = [0];
  func14.paramNames = [];
  func14.typeParamNames = [];
  func14.definitionLine = 12;
  func14.definitionModule = "classCircle";
  var func15 = function(argcv, inheritingObject, aliases, exclusions) {    // method b$build(_,_,_), line 12
    var returnTarget = invocationCount;
    invocationCount++;
    var obj16_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_classCircle_12");
      this.outer_classCircle_12 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      setLineNumber(13);    // reuse call
      var initFun17 = selfRequest(importedModules["classCircle"], "a$build(3)", [null], this, [new Alias("aprint", "print")], []);  // compileReuseCall
      this.data.y = undefined;
      var reader18_y = function() {  // reader method y
          if (this.data.y === undefined) raiseUninitializedVariable("y");
          return this.data.y;
      };
      reader18_y.isVar = true;
      reader18_y.confidential = true;
      this.methods["y"] = reader18_y;
      var writer19_y = function(argcv, n) {   // writer method y:=(_)
        assertTypeOrMsg(n, var_Number, "argument to y:=(_)", "Number");
        this.data.y = n;
        return GraceDone;
      };
      writer19_y.confidential = true;
      this.methods["y:=(1)"] = writer19_y;
      var func20 = function(argcv) {    // method print, line 16
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("classCircle");
        setLineNumber(17);    // compilenode member
        // call case 4: self request
        var call21 = selfRequest(this, "aprint", [0]);
        setLineNumber(18);    // compilenode string
        var string22 = new GraceString("in class b with ");
        // call case 4: self request
        var call23 = selfRequest(this, "x", [0]);
        var opresult24 = request(string22, "++(1)", [1], call23);
        var string25 = new GraceString(" and ");
        var opresult26 = request(opresult24, "++(1)", [1], string25);
        // call case 4: self request
        var call27 = selfRequest(this, "y", [0]);
        var opresult28 = request(opresult26, "++(1)", [1], call27);
        var string29 = new GraceString("");
        var opresult30 = request(opresult28, "++(1)", [1], string29);
        Grace_print(opresult30);
        return GraceDone;
      };    // end of method print
      this.methods["print"] = func20;
      func20.paramCounts = [0];
      func20.paramNames = [];
      func20.typeParamNames = [];
      func20.definitionLine = 16;
      func20.definitionModule = "classCircle";
      this.mutable = true;
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj16_init = function() {    // init of object on line 12
        initFun17.call(this);
        setModuleName("classCircle");
        setLineNumber(15);    // typecheck
        assertTypeOrMsg(new GraceNum(99), var_Number, "value assigned to y", "Number");
        this.data.y = new GraceNum(99);
      };
      return obj16_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj16_init = obj16_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj16_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method b$build(_,_,_)
  this.methods["b$build(3)"] = func15;
  func15.paramCounts = [0];
  func15.paramNames = [];
  func15.typeParamNames = [];
  func15.definitionLine = 12;
  func15.definitionModule = "classCircle";
  setLineNumber(3);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit32 = new GraceType("A");
  typeLit32.typeMethods.push("print");
  var var_A = typeLit32;
  var type31 = typeLit32;
  var func33 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func33;
  func33.paramCounts = [0];
  func33.paramNames = [];
  func33.typeParamNames = [];
  func33.definitionLine = 1;
  func33.definitionModule = "classCircle";
  setLineNumber(22);    // compilenode num
  var var_z = new GraceNum(0);
  var reader34_z = function() {  // reader method z
      if (var_z === undefined) raiseUninitializedVariable("z");
      return var_z;
  };
  reader34_z.isDef = true;
  reader34_z.confidential = true;
  this.methods["z"] = reader34_z;
  assertTypeOrMsg(var_z, var_Number, "value of def z", "Number");
  setLineNumber(24);    // compilenode member
  // call case 6: other requests
  // call case 4: self request
  var call36 = selfRequest(this, "b", [0]);
  var call35 = request(call36, "print", [0]);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_classCircle = gracecode_classCircle;
if (typeof window !== "undefined")
  window.gracecode_classCircle = gracecode_classCircle;
gracecode_classCircle.imports = ["StaticTyping"];
