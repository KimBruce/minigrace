;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["classTest"] = "classes:\nconfidential:\ndialect:\n StaticTyping\nfresh-methods:\n a(1)\n b\nfresh:a(1):\n m(1)\n x\nfresh:b:\n ::(1)\n asDebugString\n asString\n basicAsString\n isMe(1)\n m(1)\n x\n y\n \u2260(1)\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/classTest.grace\npublic:\n A\n a(1)\n b\npublicMethod:a(1):\n a(i:Number) \u2192 A\npublicMethod:b:\n b \u2192 A\npublicMethodTypes:\n a(i:Number) \u2192 A\n b \u2192 A\ntypedec-of:A:\n type A = interface {\n            m(n:Number) \u2192 Number}\ntypes:\n A\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["classTest"] = [
    "dialect \"StaticTyping\"",
    "",
    "type A = {",
    "    m(n: Number) → Number",
    "}",
    "",
    "class a(i: Number) → A {",
    "    method m(n: Number) → Number {",
    "        n+i",
    "    }",
    "    def x: Number = 13",
    "}",
    "",
    "class b → A {",
    "    inherit a(47)",
    "    def y: Number = m(x)",
    "}",
    "",
    "print (b.m(3))",
    "//2+\"A\"" ];
}
function gracecode_classTest() {
  setModuleName("classTest");
  importedModules["classTest"] = this;
  var module$classTest = this;
  this.definitionModule = "classTest";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_classTest_0");
  this.outer_classTest_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv, var_i) {    // method a(_), line 7
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_i, var_Number, "argument to request of `a(_)`", "Number");
    var ouc = emptyGraceObject("a(_)", "classTest", 7);
    var ouc_init = this.methods["a(1)$build(3)"].call(this, null, var_i, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(17);    // typecheck
    assertTypeOrMsg(ouc, var_A, "object returned from a(_)", "A");
    return ouc;
  };    // end of method a(_)
  func0.paramTypes = [];
  func0.paramTypes.push([type_Number, "i"]);
  this.methods["a(1)"] = func0;
  func0.paramCounts = [1];
  func0.paramNames = ["i"];
  func0.typeParamNames = [];
  func0.definitionLine = 7;
  func0.definitionModule = "classTest";
  var func1 = function(argcv, var_i, inheritingObject, aliases, exclusions) {    // method a(_)$build(_,_,_), line 7
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_i, var_Number, "argument to request of `a(_)`", "Number");
    var obj2_build = function(ignore, var_i, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_classTest_7");
      this.outer_classTest_7 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv, var_n) {    // method m(_), line 8
        var returnTarget = invocationCount;
        invocationCount++;
        assertTypeOrMsg(var_n, var_Number, "argument to request of `m(_)`", "Number");
        setModuleName("classTest");
        setLineNumber(9);    // compilenode op
        var sum4 = request(var_n, "+(1)", [1], var_i);
        assertTypeOrMsg(sum4, var_Number, "result of method m(_)", "Number");
        return sum4;
      };    // end of method m(_)
      func3.paramTypes = [];
      func3.paramTypes.push([type_Number, "n"]);
      this.methods["m(1)"] = func3;
      func3.paramCounts = [1];
      func3.paramNames = ["n"];
      func3.typeParamNames = [];
      func3.definitionLine = 8;
      func3.definitionModule = "classTest";
      this.data.x = undefined;
      var reader5_x = function() {  // reader method x
          if (this.data.x === undefined) raiseUninitializedVariable("x");
          return this.data.x;
      };
      reader5_x.isDef = true;
      reader5_x.confidential = true;
      this.methods["x"] = reader5_x;
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 7
        setModuleName("classTest");
        setLineNumber(11);    // typecheck
        assertTypeOrMsg(new GraceNum(13), var_Number, "value bound to x", "Number");
        this.data.x = new GraceNum(13);
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, var_i, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method a(_)$build(_,_,_)
  func1.paramTypes = [];
  func1.paramTypes.push([type_Number, "i"]);
  this.methods["a(1)$build(3)"] = func1;
  func1.paramCounts = [1];
  func1.paramNames = ["i"];
  func1.typeParamNames = [];
  func1.definitionLine = 7;
  func1.definitionModule = "classTest";
  var func6 = function(argcv) {    // method b, line 14
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("b", "classTest", 14);
    var ouc_init = this.methods["b$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_A, "object returned from b", "A");
    return ouc;
  };    // end of method b
  this.methods["b"] = func6;
  func6.paramCounts = [0];
  func6.paramNames = [];
  func6.typeParamNames = [];
  func6.definitionLine = 14;
  func6.definitionModule = "classTest";
  var func7 = function(argcv, inheritingObject, aliases, exclusions) {    // method b$build(_,_,_), line 14
    var returnTarget = invocationCount;
    invocationCount++;
    var obj8_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_classTest_14");
      this.outer_classTest_14 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      setLineNumber(15);    // compilenode num
      var initFun9 = selfRequest(importedModules["classTest"], "a(1)$build(3)", [null], new GraceNum(47), this, [], []);  // compileReuseCall
      this.data.y = undefined;
      var reader10_y = function() {  // reader method y
          if (this.data.y === undefined) raiseUninitializedVariable("y");
          return this.data.y;
      };
      reader10_y.isDef = true;
      reader10_y.confidential = true;
      this.methods["y"] = reader10_y;
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj8_init = function() {    // init of object on line 14
        initFun9.call(this);
        setModuleName("classTest");
        setLineNumber(16);    // compilenode member
        // call case 4: self request
        var call12 = selfRequest(this, "x", [0]);
        // call case 4: self request
        var call11 = selfRequest(this, "m(1)", [1], call12);
        assertTypeOrMsg(call11, var_Number, "value bound to y", "Number");
        this.data.y = call11;
      };
      return obj8_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj8_init = obj8_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj8_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method b$build(_,_,_)
  this.methods["b$build(3)"] = func7;
  func7.paramCounts = [0];
  func7.paramNames = [];
  func7.typeParamNames = [];
  func7.definitionLine = 14;
  func7.definitionModule = "classTest";
  setLineNumber(3);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit14 = new GraceType("A");
  typeLit14.typeMethods.push("m(1)");
  var var_A = typeLit14;
  var type13 = typeLit14;
  var func15 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func15;
  func15.paramCounts = [0];
  func15.paramNames = [];
  func15.typeParamNames = [];
  func15.definitionLine = 1;
  func15.definitionModule = "classTest";
  setLineNumber(19);    // compilenode num
  // call case 6: other requests
  // call case 4: self request
  var call17 = selfRequest(this, "b", [0]);
  var call16 = request(call17, "m(1)", [1], new GraceNum(3));
  Grace_print(call16);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_classTest = gracecode_classTest;
if (typeof window !== "undefined")
  window.gracecode_classTest = gracecode_classTest;
gracecode_classTest.imports = ["StaticTyping"];
