;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["doWhileDef_test"] = "classes:\nconfidential:\n i\n i:=(i': Number) \u2192 Done\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/doWhileDef_test.grace\npublic:\n BoolBlock\n Proc0\n do(1)while(1)\npublicMethod:do(1)while(1):\n do(block:Proc0)while(cond:BoolBlock) \u2192 Done\npublicMethodTypes:\n do(block:Proc0)while(cond:BoolBlock) \u2192 Done\ntypedec-of:BoolBlock:\n type BoolBlock = interface {\n            apply \u2192 Boolean}\ntypedec-of:Proc0:\n type Proc0 = interface {\n            apply \u2192 Done}\ntypes:\n BoolBlock\n Proc0\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["doWhileDef_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "type BoolBlock = {",
    "    apply → Boolean",
    "}",
    "",
    "type Proc0 = {",
    "    apply → Done",
    "}",
    "",
    "method do (block:Proc0) while (cond: BoolBlock) → Done {",
    "    block.apply",
    "    while (cond) do (block)",
    "}",
    "",
    "var i: Number := 1",
    "do {",
    "    print(i)",
    "    i := i + 1",
    "} while {i < 10}" ];
}
function gracecode_doWhileDef__95__test() {
  setModuleName("doWhileDef_test");
  importedModules["doWhileDef_test"] = this;
  var module$doWhileDef__95__test = this;
  this.definitionModule = "doWhileDef_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_doWhileDef__95__test_0");
  this.outer_doWhileDef__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv, var_block, var_cond) {    // method do(_)while(_), line 11
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_block, var_Proc0, "argument 1 in request of `do(_)while(_)`", "Proc0");
    assertTypeOrMsg(var_cond, var_BoolBlock, "argument 2 in request of `do(_)while(_)`", "BoolBlock");
    setModuleName("doWhileDef_test");
    setLineNumber(12);    // compilenode member
    // call case 6: other requests
    var call1 = request(var_block, "apply", [0]);
    setLineNumber(13);    // compilenode call
    // call case 2: outer request
    var call2 = selfRequest(var_prelude, "while(1)do(1)", [1, 1], var_cond, var_block);
    return call2;
  };    // end of method do(_)while(_)
  func0.paramTypes = [];
  func0.paramTypes.push([]);
  func0.paramTypes.push([]);
  this.methods["do(1)while(1)"] = func0;
  func0.paramCounts = [1, 1];
  func0.paramNames = ["block", "cond"];
  func0.typeParamNames = [];
  func0.definitionLine = 11;
  func0.definitionModule = "doWhileDef_test";
  setLineNumber(3);    // compilenode typedec
  // Type decl BoolBlock
  //   Type literal 
  var typeLit4 = new GraceType("BoolBlock");
  typeLit4.typeMethods.push("apply");
  var var_BoolBlock = typeLit4;
  var type3 = typeLit4;
  var func5 = function(argcv) {     // accessor method BoolBlock
    return var_BoolBlock;
  };    // end of method BoolBlock
  this.methods["BoolBlock"] = func5;
  func5.paramCounts = [0];
  func5.paramNames = [];
  func5.typeParamNames = [];
  func5.definitionLine = 1;
  func5.definitionModule = "doWhileDef_test";
  setLineNumber(7);    // compilenode typedec
  // Type decl Proc0
  //   Type literal 
  var typeLit7 = new GraceType("Proc0");
  typeLit7.typeMethods.push("apply");
  var var_Proc0 = typeLit7;
  var type6 = typeLit7;
  var func8 = function(argcv) {     // accessor method Proc0
    return var_Proc0;
  };    // end of method Proc0
  this.methods["Proc0"] = func8;
  func8.paramCounts = [0];
  func8.paramNames = [];
  func8.typeParamNames = [];
  func8.definitionLine = 1;
  func8.definitionModule = "doWhileDef_test";
  setLineNumber(16);    // typecheck
  assertTypeOrMsg(new GraceNum(1), var_Number, "initial value of var i", "Number");
  var var_i = new GraceNum(1);
  var reader9_i = function() {  // reader method i
      if (var_i === undefined) raiseUninitializedVariable("i");
      return var_i;
  };
  reader9_i.isVar = true;
  reader9_i.confidential = true;
  this.methods["i"] = reader9_i;
  var writer10_i = function(argcv, n) {   // writer method i:=(_)
    assertTypeOrMsg(n, var_Number, "argument to i:=(_)", "Number");
    var_i = n;
    return GraceDone;
  };
  writer10_i.confidential = true;
  this.methods["i:=(1)"] = writer10_i;
  setLineNumber(17);    // compilenode block
  var block12 = new GraceBlock(this, 17, 0);
  var matches13 = function() {
    setModuleName("doWhileDef_test");
    return true;
  };
  block12.guard = matches13;
  block12.real = function() {
    setModuleName("doWhileDef_test");
    setLineNumber(18);    // compilenode call
    if (var_i === undefined) raiseUninitializedVariable("i");
    Grace_print(var_i);
    setLineNumber(19);    // compilenode op
    if (var_i === undefined) raiseUninitializedVariable("i");
    var sum14 = request(var_i, "+(1)", [1], new GraceNum(1));
    var_i = sum14;
    return GraceDone;
  };
  setLineNumber(20);    // compilenode block
  var block15 = new GraceBlock(this, 20, 0);
  var matches16 = function() {
    setModuleName("doWhileDef_test");
    return true;
  };
  block15.guard = matches16;
  block15.real = function() {
    setModuleName("doWhileDef_test");
    setLineNumber(20);    // compilenode op
    if (var_i === undefined) raiseUninitializedVariable("i");
    var opresult17 = request(var_i, "<(1)", [1], new GraceNum(10));
    return opresult17;
  };
  // call case 2: outer request
  var call11 = selfRequest(importedModules["doWhileDef_test"], "do(1)while(1)", [1, 1], block12, block15);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_doWhileDef__95__test = gracecode_doWhileDef__95__test;
if (typeof window !== "undefined")
  window.gracecode_doWhileDef__95__test = gracecode_doWhileDef__95__test;
gracecode_doWhileDef__95__test.imports = ["StaticTyping"];
