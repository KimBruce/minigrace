;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["elseifTest_test"] = "classes:\nconfidential:\n x\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/elseifTest_test.grace\npublic:\npublicMethodTypes:\ntypes:\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["elseifTest_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "def x: Number = 3",
    "",
    "if (x > 0) then {print \"positive\"}",
    "    elseif {x < 0} then {print \"negative\"}",
    "    else {print \"zero\"}" ];
}
function gracecode_elseifTest__95__test() {
  setModuleName("elseifTest_test");
  importedModules["elseifTest_test"] = this;
  var module$elseifTest__95__test = this;
  this.definitionModule = "elseifTest_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_elseifTest__95__test_0");
  this.outer_elseifTest__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(3);    // compilenode num
  var var_x = new GraceNum(3);
  var reader0_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader0_x.isDef = true;
  reader0_x.confidential = true;
  this.methods["x"] = reader0_x;
  assertTypeOrMsg(var_x, var_Number, "value of def x", "Number");
  var if1 = GraceDone;
  setLineNumber(5);    // compilenode op
  if (var_x === undefined) raiseUninitializedVariable("x");
  var opresult2 = request(var_x, ">(1)", [1], new GraceNum(0));
  if (Grace_isTrue(opresult2)) {
    var string3 = new GraceString("positive");
    Grace_print(string3);
    if1 = GraceDone;
  } else {
    var if4 = GraceDone;
    setLineNumber(6);    // compilenode op
    if (var_x === undefined) raiseUninitializedVariable("x");
    var opresult5 = request(var_x, "<(1)", [1], new GraceNum(0));
    if (Grace_isTrue(opresult5)) {
      var string6 = new GraceString("negative");
      Grace_print(string6);
      if4 = GraceDone;
    } else {
      setLineNumber(7);    // compilenode string
      var string7 = new GraceString("zero");
      Grace_print(string7);
      if4 = GraceDone;
    }
    if1 = if4;
  }
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_elseifTest__95__test = gracecode_elseifTest__95__test;
if (typeof window !== "undefined")
  window.gracecode_elseifTest__95__test = gracecode_elseifTest__95__test;
gracecode_elseifTest__95__test.imports = ["StaticTyping"];
