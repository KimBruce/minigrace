;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["genericDrop"] = "classes:\nconfidential:\n x\ndialect:\n standardGrace\nfresh-methods:\n t\nfresh:t:\n m(1)\nmodules:\n collectionsPrelude\n standardGrace\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/genericDrop.grace\npublic:\n T\n t\npublicMethod:t:\n t\u27e6V\u27e7 \u2192 T\u27e6V\u27e7\npublicMethodTypes:\n t\u27e6V\u27e7 \u2192 T\u27e6V\u27e7\ntypedec-of:T\u27e6V\u27e7:\n type T\u27e6V\u27e7 = interface {\n            m(v:V) \u2192 Done}\ntypes:\n T\u27e6V\u27e7\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["genericDrop"] = [
    "type T⟦V⟧ = {",
    "   m(v:V) -> Done",
    "}",
    "//class s {",
    "class t⟦V⟧ → T⟦V⟧ {",
    "   method m(v:V) -> Done {",
    "       print(v)",
    "   }",
    "}",
    "",
    "def x : T⟦Number⟧ = t⟦Number⟧",
    "x.m(3)" ];
}
function gracecode_genericDrop() {
  setModuleName("genericDrop");
  importedModules["genericDrop"] = this;
  var module$genericDrop = this;
  this.definitionModule = "genericDrop";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_genericDrop_0");
  this.outer_genericDrop_0 = var_prelude;
  // Dialect "standardGrace"
  var_prelude = do_import("standardGrace", gracecode_standardGrace);
  this.outer = var_prelude;
  var func0 = function(argcv, var_V) {    // method t, line 5
    var returnTarget = invocationCount;
    invocationCount++;
    // Start type parameters
    if (var_V === undefined) var_V = var_Unknown;
    var numArgs = arguments.length - 1 - 0;
    if ((numArgs > 0) && (numArgs < 1)) {
        throw new GraceExceptionPacket(RequestErrorObject, 
            new GraceString("method t expects 1 type parameter, but was given " + (numArgs - 0)));
    }
    // End type parameters
    var ouc = emptyGraceObject("t", "genericDrop", 5);
    var ouc_init = this.methods["t$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_T, "object returned from t", "T");
    return ouc;
  };    // end of method t
  this.methods["t"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = ["V"];
  func0.definitionLine = 5;
  func0.definitionModule = "genericDrop";
  var func1 = function(argcv, inheritingObject, aliases, exclusions, var_V) {    // method t$build(_,_,_), line 5
    var returnTarget = invocationCount;
    invocationCount++;
    // Start type parameters
    if (var_V === undefined) var_V = var_Unknown;
    var numArgs = arguments.length - 1 - 3;
    if ((numArgs > 0) && (numArgs < 1)) {
        throw new GraceExceptionPacket(RequestErrorObject, 
            new GraceString("method t expects 1 type parameter, but was given " + (numArgs - 0)));
    }
    // End type parameters
    var obj2_build = function(ignore, outerObj, aliases, exclusions, var_V) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_genericDrop_5");
      this.outer_genericDrop_5 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv, var_v) {    // method m(_), line 6
        var returnTarget = invocationCount;
        invocationCount++;
        assertTypeOrMsg(var_v, var_V, "argument to request of `m(_)`", "V");
        setModuleName("genericDrop");
        setLineNumber(7);    // compilenode call
        Grace_print(var_v);
        return GraceDone;
      };    // end of method m(_)
      func3.paramTypes = [];
      func3.paramTypes.push([]);
      this.methods["m(1)"] = func3;
      func3.paramCounts = [1];
      func3.paramNames = ["v"];
      func3.typeParamNames = [];
      func3.definitionLine = 6;
      func3.definitionModule = "genericDrop";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 5
        setModuleName("genericDrop");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, this, aliases, exclusions, var_V);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method t$build(_,_,_)
  this.methods["t$build(3)"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = ["V"];
  func1.definitionLine = 5;
  func1.definitionModule = "genericDrop";
  setLineNumber(1);    // compilenode typedec
  // Type decl T
  //   Type literal 
  var typeLit5 = new GraceType("T");
  typeLit5.typeMethods.push("m(1)");
  var var_T = typeLit5;
  var type4 = typeLit5;
  var func6 = function(argcv) {     // accessor method T
    return var_T;
  };    // end of method T
  this.methods["T"] = func6;
  func6.paramCounts = [0];
  func6.paramNames = [];
  func6.typeParamNames = [];
  func6.definitionLine = 1;
  func6.definitionModule = "genericDrop";
  setLineNumber(11);    // compilenode member
  // call case 4: self request
  var call7 = selfRequest(this, "t", [0]);
  var var_x = call7;
  var reader8_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader8_x.isDef = true;
  reader8_x.confidential = true;
  this.methods["x"] = reader8_x;
  assertTypeOrMsg(var_x, var_T, "value of def x", "T");
  setLineNumber(12);    // compilenode num
  // call case 6: other requests
  if (var_x === undefined) raiseUninitializedVariable("x");
  var call9 = request(var_x, "m(1)", [1], new GraceNum(3));
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_genericDrop = gracecode_genericDrop;
if (typeof window !== "undefined")
  window.gracecode_genericDrop = gracecode_genericDrop;
gracecode_genericDrop.imports = ["standardGrace"];
