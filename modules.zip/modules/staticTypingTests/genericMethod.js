;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["genericMethod"] = "classes:\nconfidential:\ndialect:\n standardGrace\nfresh-methods:\nmodules:\n collectionsPrelude\n standardGrace\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/genericMethod.grace\npublic:\n m(1)\npublicMethod:m(1):\n m\u27e6T\u27e7(x:T) \u2192 T\npublicMethodTypes:\n m\u27e6T\u27e7(x:T) \u2192 T\ntypes:\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["genericMethod"] = [
    "method m[[T]](x:T) -> T {",
    "   x",
    "}" ];
}
function gracecode_genericMethod() {
  setModuleName("genericMethod");
  importedModules["genericMethod"] = this;
  var module$genericMethod = this;
  this.definitionModule = "genericMethod";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_genericMethod_0");
  this.outer_genericMethod_0 = var_prelude;
  // Dialect "standardGrace"
  var_prelude = do_import("standardGrace", gracecode_standardGrace);
  this.outer = var_prelude;
  var func0 = function(argcv, var_x, var_T) {     // accessor method m(1)
    return var_x;
  };    // end of method m(_)
  func0.paramTypes = [];
  func0.paramTypes.push([]);
  this.methods["m(1)"] = func0;
  func0.paramCounts = [1];
  func0.paramNames = ["x"];
  func0.typeParamNames = ["T"];
  func0.definitionLine = 1;
  func0.definitionModule = "genericMethod";
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_genericMethod = gracecode_genericMethod;
if (typeof window !== "undefined")
  window.gracecode_genericMethod = gracecode_genericMethod;
gracecode_genericMethod.imports = ["standardGrace"];
