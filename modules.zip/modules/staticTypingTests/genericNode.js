;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["genericNode"] = "classes:\nconfidential:\n n\ndialect:\n standardGrace\nfresh-methods:\n emptyNode(1)\nfresh:emptyNode(1):\n next\n val\nmodules:\n collectionsPrelude\n standardGrace\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/genericNode.grace\npublic:\n Node\n emptyNode(1)\npublicMethod:emptyNode(1):\n emptyNode\u27e6T\u27e7(v:Number) \u2192 Node\u27e6T\u27e7\npublicMethodTypes:\n emptyNode\u27e6T\u27e7(v:Number) \u2192 Node\u27e6T\u27e7\ntypedec-of:Node\u27e6T\u27e7:\n type Node\u27e6T\u27e7 = interface {\n            val \u2192 T\n            next \u2192 Node\u27e6T\u27e7}\ntypes:\n Node\u27e6T\u27e7\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["genericNode"] = [
    "//dialect \"StaticTyping\"",
    "type Node[[T]] = {",
    "   val -> T",
    "   next -> Node[[T]]",
    "}",
    "",
    "class emptyNode[[T]](v:Number) -> Node[[T]] {",
    "    method next -> Node[[T]] {",
    "       self",
    "    }",
    "    method val -> T {",
    "       ProgrammingError.raise \"call next on empty list\"",
    "    }",
    "}",
    "",
    "def n: Node[[Number]] = emptyNode[[Number]](2)",
    "print (n.val)" ];
}
function gracecode_genericNode() {
  setModuleName("genericNode");
  importedModules["genericNode"] = this;
  var module$genericNode = this;
  this.definitionModule = "genericNode";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_genericNode_0");
  this.outer_genericNode_0 = var_prelude;
  // Dialect "standardGrace"
  var_prelude = do_import("standardGrace", gracecode_standardGrace);
  this.outer = var_prelude;
  var func0 = function(argcv, var_v, var_T) {    // method emptyNode(_), line 7
    var returnTarget = invocationCount;
    invocationCount++;
    // Start type parameters
    if (var_T === undefined) var_T = var_Unknown;
    var numArgs = arguments.length - 1 - 0;
    if ((numArgs > 1) && (numArgs < 2)) {
        throw new GraceExceptionPacket(RequestErrorObject, 
            new GraceString("method emptyNode(_) expects 1 type parameter, but was given " + (numArgs - 1)));
    }
    // End type parameters
    assertTypeOrMsg(var_v, var_Number, "argument to request of `emptyNode(_)`", "Number");
    var ouc = emptyGraceObject("emptyNode(_)", "genericNode", 7);
    var ouc_init = this.methods["emptyNode(1)$build(3)"].call(this, null, var_v, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_Node, "object returned from emptyNode(_)", "Node");
    return ouc;
  };    // end of method emptyNode(_)
  func0.paramTypes = [];
  func0.paramTypes.push([type_Number, "v"]);
  this.methods["emptyNode(1)"] = func0;
  func0.paramCounts = [1];
  func0.paramNames = ["v"];
  func0.typeParamNames = ["T"];
  func0.definitionLine = 7;
  func0.definitionModule = "genericNode";
  var func1 = function(argcv, var_v, inheritingObject, aliases, exclusions, var_T) {    // method emptyNode(_)$build(_,_,_), line 7
    var returnTarget = invocationCount;
    invocationCount++;
    // Start type parameters
    if (var_T === undefined) var_T = var_Unknown;
    var numArgs = arguments.length - 1 - 3;
    if ((numArgs > 1) && (numArgs < 2)) {
        throw new GraceExceptionPacket(RequestErrorObject, 
            new GraceString("method emptyNode(_) expects 1 type parameter, but was given " + (numArgs - 1)));
    }
    // End type parameters
    assertTypeOrMsg(var_v, var_Number, "argument to request of `emptyNode(_)`", "Number");
    var obj2_build = function(ignore, var_v, outerObj, aliases, exclusions, var_T) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_genericNode_7");
      this.outer_genericNode_7 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv) {     // accessor method next
        return this;
      };    // end of method next
      this.methods["next"] = func3;
      func3.paramCounts = [0];
      func3.paramNames = [];
      func3.typeParamNames = [];
      func3.definitionLine = 8;
      func3.definitionModule = "genericNode";
      var func4 = function(argcv) {    // method val, line 11
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("genericNode");
        setLineNumber(12);    // compilenode string
        var string6 = new GraceString("call next on empty list");
        // call case 6: other requests
        // call case 2: outer request
        var call7 = selfRequest(var_prelude, "ProgrammingError", [0]);
        var call5 = request(call7, "raise(1)", [1], string6);
        assertTypeOrMsg(call5, var_T, "result of method val", "T");
        return call5;
      };    // end of method val
      this.methods["val"] = func4;
      func4.paramCounts = [0];
      func4.paramNames = [];
      func4.typeParamNames = [];
      func4.definitionLine = 11;
      func4.definitionModule = "genericNode";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 7
        setModuleName("genericNode");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, var_v, this, aliases, exclusions, var_T);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method emptyNode(_)$build(_,_,_)
  func1.paramTypes = [];
  func1.paramTypes.push([type_Number, "v"]);
  this.methods["emptyNode(1)$build(3)"] = func1;
  func1.paramCounts = [1];
  func1.paramNames = ["v"];
  func1.typeParamNames = ["T"];
  func1.definitionLine = 7;
  func1.definitionModule = "genericNode";
  setLineNumber(2);    // compilenode typedec
  // Type decl Node
  //   Type literal 
  var typeLit9 = new GraceType("Node");
  typeLit9.typeMethods.push("val");
  typeLit9.typeMethods.push("next");
  var var_Node = typeLit9;
  var type8 = typeLit9;
  var func10 = function(argcv) {     // accessor method Node
    return var_Node;
  };    // end of method Node
  this.methods["Node"] = func10;
  func10.paramCounts = [0];
  func10.paramNames = [];
  func10.typeParamNames = [];
  func10.definitionLine = 1;
  func10.definitionModule = "genericNode";
  setLineNumber(16);    // compilenode num
  // call case 2: outer request
  var call11 = selfRequest(importedModules["genericNode"], "emptyNode(1)", [1, 1], new GraceNum(2), var_Number);
  var var_n = call11;
  var reader12_n = function() {  // reader method n
      if (var_n === undefined) raiseUninitializedVariable("n");
      return var_n;
  };
  reader12_n.isDef = true;
  reader12_n.confidential = true;
  this.methods["n"] = reader12_n;
  assertTypeOrMsg(var_n, var_Node, "value of def n", "Node");
  setLineNumber(17);    // compilenode member
  // call case 6: other requests
  if (var_n === undefined) raiseUninitializedVariable("n");
  var call13 = request(var_n, "val", [0]);
  Grace_print(call13);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_genericNode = gracecode_genericNode;
if (typeof window !== "undefined")
  window.gracecode_genericNode = gracecode_genericNode;
gracecode_genericNode.imports = ["standardGrace"];
