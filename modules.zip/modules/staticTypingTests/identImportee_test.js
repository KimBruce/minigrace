;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["identImportee_test"] = "classes:\nconfidential:\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/identImportee_test.grace\npublic:\n T\n U\npublicMethodTypes:\ntypedec-of:T:\n type T = Number\ntypedec-of:U:\n type U = T\ntypes:\n T\n U\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["identImportee_test"] = [
    "dialect \"StaticTyping\"",
    "type T = Number",
    "type U = T" ];
}
function gracecode_identImportee__95__test() {
  setModuleName("identImportee_test");
  importedModules["identImportee_test"] = this;
  var module$identImportee__95__test = this;
  this.definitionModule = "identImportee_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_identImportee__95__test_0");
  this.outer_identImportee__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(2);    // compilenode typedec
  // Type decl T
  var var_T = var_Number;
  var type0 = var_Number;
  var func1 = function(argcv) {     // accessor method T
    return var_T;
  };    // end of method T
  this.methods["T"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 1;
  func1.definitionModule = "identImportee_test";
  setLineNumber(3);    // compilenode typedec
  // Type decl U
  var var_U = var_T;
  var type2 = var_T;
  var func3 = function(argcv) {     // accessor method U
    return var_U;
  };    // end of method U
  this.methods["U"] = func3;
  func3.paramCounts = [0];
  func3.paramNames = [];
  func3.typeParamNames = [];
  func3.definitionLine = 1;
  func3.definitionModule = "identImportee_test";
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_identImportee__95__test = gracecode_identImportee__95__test;
if (typeof window !== "undefined")
  window.gracecode_identImportee__95__test = gracecode_identImportee__95__test;
gracecode_identImportee__95__test.imports = ["StaticTyping"];
