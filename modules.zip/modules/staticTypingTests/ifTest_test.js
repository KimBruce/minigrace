;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["ifTest_test"] = "classes:\nconfidential:\n x\n y\n z\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/ifTest_test.grace\npublic:\n O\npublicMethodTypes:\ntypedec-of:O:\n type O = interface {\n            asString \u2192 String}\ntypes:\n O\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["ifTest_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "type O = {",
    "    asString → String",
    "}",
    "",
    "def z: O = if (true) then {12} else {\"s\"}",
    "def y: Number | String = if (true) then {12} else {\"s\"}",
    "",
    "print (z)",
    "",
    "def x: Number = if (true) then {4} else {5}",
    "",
    "print(x)" ];
}
function gracecode_ifTest__95__test() {
  setModuleName("ifTest_test");
  importedModules["ifTest_test"] = this;
  var module$ifTest__95__test = this;
  this.definitionModule = "ifTest_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_ifTest__95__test_0");
  this.outer_ifTest__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(3);    // compilenode typedec
  // Type decl O
  //   Type literal 
  var typeLit1 = new GraceType("O");
  typeLit1.typeMethods.push("asString");
  var var_O = typeLit1;
  var type0 = typeLit1;
  var func2 = function(argcv) {     // accessor method O
    return var_O;
  };    // end of method O
  this.methods["O"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 1;
  func2.definitionModule = "ifTest_test";
  var if3 = GraceDone;
  setLineNumber(7);    // compilenode if
  if (Grace_isTrue(GraceTrue)) {
    if3 = new GraceNum(12);
  } else {
    var string4 = new GraceString("s");
    if3 = string4;
  }
  var var_z = if3;
  var reader5_z = function() {  // reader method z
      if (var_z === undefined) raiseUninitializedVariable("z");
      return var_z;
  };
  reader5_z.isDef = true;
  reader5_z.confidential = true;
  this.methods["z"] = reader5_z;
  assertTypeOrMsg(var_z, var_O, "value of def z", "O");
  var if6 = GraceDone;
  setLineNumber(8);    // compilenode if
  if (Grace_isTrue(GraceTrue)) {
    if6 = new GraceNum(12);
  } else {
    var string7 = new GraceString("s");
    if6 = string7;
  }
  var var_y = if6;
  var reader8_y = function() {  // reader method y
      if (var_y === undefined) raiseUninitializedVariable("y");
      return var_y;
  };
  reader8_y.isDef = true;
  reader8_y.confidential = true;
  this.methods["y"] = reader8_y;
  var opresult9 = request(var_Number, "|(1)", [1], var_String);
  assertTypeOrMsg(var_y, opresult9, "value of def y", "Number | String");
  setLineNumber(10);    // compilenode call
  if (var_z === undefined) raiseUninitializedVariable("z");
  Grace_print(var_z);
  var if10 = GraceDone;
  setLineNumber(12);    // compilenode if
  if (Grace_isTrue(GraceTrue)) {
    if10 = new GraceNum(4);
  } else {
    if10 = new GraceNum(5);
  }
  var var_x = if10;
  var reader11_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader11_x.isDef = true;
  reader11_x.confidential = true;
  this.methods["x"] = reader11_x;
  assertTypeOrMsg(var_x, var_Number, "value of def x", "Number");
  setLineNumber(14);    // compilenode call
  if (var_x === undefined) raiseUninitializedVariable("x");
  Grace_print(var_x);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_ifTest__95__test = gracecode_ifTest__95__test;
if (typeof window !== "undefined")
  window.gracecode_ifTest__95__test = gracecode_ifTest__95__test;
gracecode_ifTest__95__test.imports = ["StaticTyping"];
