;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["iteFail"] = "classes:\nconfidential:\ndialect:\n standardGrace\nfresh-methods:\nmodules:\n collectionsPrelude\n standardGrace\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/iteFail.grace\npublic:\npublicMethodTypes:\ntypes:\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["iteFail"] = [
    "if (true) then{",
    "    print \"OK\"",
    "} else {",
    "    print \"what?\"",
    "}" ];
}
function gracecode_iteFail() {
  setModuleName("iteFail");
  importedModules["iteFail"] = this;
  var module$iteFail = this;
  this.definitionModule = "iteFail";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_iteFail_0");
  this.outer_iteFail_0 = var_prelude;
  // Dialect "standardGrace"
  var_prelude = do_import("standardGrace", gracecode_standardGrace);
  this.outer = var_prelude;
  var if0 = GraceDone;
  setLineNumber(1);    // compilenode if
  if (Grace_isTrue(GraceTrue)) {
    setLineNumber(2);    // compilenode string
    var string1 = new GraceString("OK");
    Grace_print(string1);
    if0 = GraceDone;
  } else {
    setLineNumber(4);    // compilenode string
    var string2 = new GraceString("what?");
    Grace_print(string2);
    if0 = GraceDone;
  }
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_iteFail = gracecode_iteFail;
if (typeof window !== "undefined")
  window.gracecode_iteFail = gracecode_iteFail;
gracecode_iteFail.imports = ["standardGrace"];
