;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["objectsMethodsClasses_test"] = "classes:\nconfidential:\n co\n d\n obj\n xy\ndialect:\n StaticTyping\nfresh-methods:\n c\n cc\nfresh:c:\n p(1)\n q\n sf\n sf:=(_)\nfresh:cc:\n p(1)\n q\n sf\n sf:=(_)\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/objectsMethodsClasses_test.grace\npublic:\n A\n c\n cc\n d(1)\n y\n y:=(1)\npublicMethod:c:\n c \u2192 A\npublicMethod:cc:\n cc \u2192 A\npublicMethod:d(1):\n d(aa:Number) \u2192 Number\npublicMethod:y:\n y \u2192 Number\npublicMethod:y:=(1):\n y:=(y': Number) \u2192 Done\npublicMethodTypes:\n c \u2192 A\n cc \u2192 A\n d(aa:Number) \u2192 Number\n y \u2192 Number\n y:=(y': Number) \u2192 Done\ntypedec-of:A:\n type A = interface {\n            p(n:Number) \u2192 Number\n            q \u2192 String\n            sf \u2192 Number\n            sf:=(n:Number) \u2192 Done}\ntypes:\n A\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["objectsMethodsClasses_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "method d(aa:Number) → Number {aa}",
    "",
    "print(d(5))",
    "type A = {",
    "    p(n:Number) -> Number",
    "    q → String",
    "    sf → Number",
    "    sf:= (n: Number) → Done",
    "}",
    "",
    "var y:Number is public := 16",
    "",
    "def obj: A = object {",
    "        var sf: Number is public := 12",
    "        method p(m: Number) → Number {m}",
    "        method q → String {\"d\"}",
    "}",
    "",
    "obj.sf",
    "",
    "obj.p(23)",
    "",
    "method c → A {",
    "    object {",
    "        var sf: Number is public := 12",
    "        method p(n: Number) → Number {n + 1}",
    "        method q → String {\"d\"}",
    "    }",
    "}",
    "",
    "class cc → A {",
    "    var sf: Number is public := 12",
    "    method p(n: Number) → Number {n + 1}",
    "    method q → String {\"d\"}",
    "}",
    "",
    "def co: A = cc",
    "co.sf",
    "co.sf := 5",
    "print \"co.sf = {co.sf}\"",
    "",
    "print \"{c.q}\"",
    "",
    "print (c.p (17))",
    "",
    "def d: A = c",
    "print(d.sf)",
    "d.sf := 12",
    "def xy: Number = d.sf - 47",
    "print(xy)",
    "",
    "print (1 + c.p(11))" ];
}
function gracecode_objectsMethodsClasses__95__test() {
  setModuleName("objectsMethodsClasses_test");
  importedModules["objectsMethodsClasses_test"] = this;
  var module$objectsMethodsClasses__95__test = this;
  this.definitionModule = "objectsMethodsClasses_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_objectsMethodsClasses__95__test_0");
  this.outer_objectsMethodsClasses__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv, var_aa) {     // accessor method d(1)
    return var_aa;
  };    // end of method d(_)
  func0.paramTypes = [];
  func0.paramTypes.push([type_Number, "aa"]);
  this.methods["d(1)"] = func0;
  func0.paramCounts = [1];
  func0.paramNames = ["aa"];
  func0.typeParamNames = [];
  func0.definitionLine = 3;
  func0.definitionModule = "objectsMethodsClasses_test";
  var func1 = function(argcv) {    // method c, line 25
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("c", "objectsMethodsClasses_test", 25);
    var ouc_init = this.methods["c$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(31);    // typecheck
    assertTypeOrMsg(ouc, var_A, "object returned from c", "A");
    return ouc;
  };    // end of method c
  this.methods["c"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 25;
  func1.definitionModule = "objectsMethodsClasses_test";
  var func2 = function(argcv, inheritingObject, aliases, exclusions) {    // method c$build(_,_,_), line 25
    var returnTarget = invocationCount;
    invocationCount++;
    var obj3_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_objectsMethodsClasses__95__test_26");
      this.outer_objectsMethodsClasses__95__test_26 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      this.data.sf = undefined;
      var reader4_sf = function() {  // reader method sf
          if (this.data.sf === undefined) raiseUninitializedVariable("sf");
          return this.data.sf;
      };
      reader4_sf.isVar = true;
      this.methods["sf"] = reader4_sf;
      var writer5_sf = function(argcv, n) {   // writer method sf:=(_)
        assertTypeOrMsg(n, var_Number, "argument to sf:=(_)", "Number");
        this.data.sf = n;
        return GraceDone;
      };
      this.methods["sf:=(1)"] = writer5_sf;
      var func6 = function(argcv, var_n) {    // method p(_), line 28
        var returnTarget = invocationCount;
        invocationCount++;
        assertTypeOrMsg(var_n, var_Number, "argument to request of `p(_)`", "Number");
        setModuleName("objectsMethodsClasses_test");
        setLineNumber(28);    // compilenode num
        var sum7 = request(var_n, "+(1)", [1], new GraceNum(1));
        assertTypeOrMsg(sum7, var_Number, "result of method p(_)", "Number");
        return sum7;
      };    // end of method p(_)
      func6.paramTypes = [];
      func6.paramTypes.push([type_Number, "n"]);
      this.methods["p(1)"] = func6;
      func6.paramCounts = [1];
      func6.paramNames = ["n"];
      func6.typeParamNames = [];
      func6.definitionLine = 28;
      func6.definitionModule = "objectsMethodsClasses_test";
      var func8 = function(argcv) {    // method q, line 29
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("objectsMethodsClasses_test");
        setLineNumber(29);    // compilenode string
        var string9 = new GraceString("d");
        assertTypeOrMsg(string9, var_String, "result of method q", "String");
        return string9;
      };    // end of method q
      this.methods["q"] = func8;
      func8.paramCounts = [0];
      func8.paramNames = [];
      func8.typeParamNames = [];
      func8.definitionLine = 29;
      func8.definitionModule = "objectsMethodsClasses_test";
      this.mutable = true;
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj3_init = function() {    // init of object on line 26
        setModuleName("objectsMethodsClasses_test");
        setLineNumber(27);    // typecheck
        assertTypeOrMsg(new GraceNum(12), var_Number, "value assigned to sf", "Number");
        this.data.sf = new GraceNum(12);
      };
      return obj3_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj3_init = obj3_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj3_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method c$build(_,_,_)
  this.methods["c$build(3)"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 25;
  func2.definitionModule = "objectsMethodsClasses_test";
  var func10 = function(argcv) {    // method cc, line 33
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("cc", "objectsMethodsClasses_test", 33);
    var ouc_init = this.methods["cc$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(42);    // typecheck
    assertTypeOrMsg(ouc, var_A, "object returned from cc", "A");
    return ouc;
  };    // end of method cc
  this.methods["cc"] = func10;
  func10.paramCounts = [0];
  func10.paramNames = [];
  func10.typeParamNames = [];
  func10.definitionLine = 33;
  func10.definitionModule = "objectsMethodsClasses_test";
  var func11 = function(argcv, inheritingObject, aliases, exclusions) {    // method cc$build(_,_,_), line 33
    var returnTarget = invocationCount;
    invocationCount++;
    var obj12_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_objectsMethodsClasses__95__test_33");
      this.outer_objectsMethodsClasses__95__test_33 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      this.data.sf = undefined;
      var reader13_sf = function() {  // reader method sf
          if (this.data.sf === undefined) raiseUninitializedVariable("sf");
          return this.data.sf;
      };
      reader13_sf.isVar = true;
      this.methods["sf"] = reader13_sf;
      var writer14_sf = function(argcv, n) {   // writer method sf:=(_)
        assertTypeOrMsg(n, var_Number, "argument to sf:=(_)", "Number");
        this.data.sf = n;
        return GraceDone;
      };
      this.methods["sf:=(1)"] = writer14_sf;
      var func15 = function(argcv, var_n) {    // method p(_), line 35
        var returnTarget = invocationCount;
        invocationCount++;
        assertTypeOrMsg(var_n, var_Number, "argument to request of `p(_)`", "Number");
        setModuleName("objectsMethodsClasses_test");
        setLineNumber(35);    // compilenode num
        var sum16 = request(var_n, "+(1)", [1], new GraceNum(1));
        assertTypeOrMsg(sum16, var_Number, "result of method p(_)", "Number");
        return sum16;
      };    // end of method p(_)
      func15.paramTypes = [];
      func15.paramTypes.push([type_Number, "n"]);
      this.methods["p(1)"] = func15;
      func15.paramCounts = [1];
      func15.paramNames = ["n"];
      func15.typeParamNames = [];
      func15.definitionLine = 35;
      func15.definitionModule = "objectsMethodsClasses_test";
      var func17 = function(argcv) {    // method q, line 36
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("objectsMethodsClasses_test");
        setLineNumber(36);    // compilenode string
        var string18 = new GraceString("d");
        assertTypeOrMsg(string18, var_String, "result of method q", "String");
        return string18;
      };    // end of method q
      this.methods["q"] = func17;
      func17.paramCounts = [0];
      func17.paramNames = [];
      func17.typeParamNames = [];
      func17.definitionLine = 36;
      func17.definitionModule = "objectsMethodsClasses_test";
      this.mutable = true;
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj12_init = function() {    // init of object on line 33
        setModuleName("objectsMethodsClasses_test");
        setLineNumber(34);    // typecheck
        assertTypeOrMsg(new GraceNum(12), var_Number, "value assigned to sf", "Number");
        this.data.sf = new GraceNum(12);
      };
      return obj12_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj12_init = obj12_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj12_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method cc$build(_,_,_)
  this.methods["cc$build(3)"] = func11;
  func11.paramCounts = [0];
  func11.paramNames = [];
  func11.typeParamNames = [];
  func11.definitionLine = 33;
  func11.definitionModule = "objectsMethodsClasses_test";
  setLineNumber(5);    // compilenode num
  // call case 2: outer request
  var call19 = selfRequest(importedModules["objectsMethodsClasses_test"], "d(1)", [1], new GraceNum(5));
  Grace_print(call19);
  setLineNumber(6);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit21 = new GraceType("A");
  typeLit21.typeMethods.push("p(1)");
  typeLit21.typeMethods.push("q");
  typeLit21.typeMethods.push("sf");
  typeLit21.typeMethods.push("sf:=(1)");
  var var_A = typeLit21;
  var type20 = typeLit21;
  var func22 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func22;
  func22.paramCounts = [0];
  func22.paramNames = [];
  func22.typeParamNames = [];
  func22.definitionLine = 1;
  func22.definitionModule = "objectsMethodsClasses_test";
  setLineNumber(13);    // typecheck
  assertTypeOrMsg(new GraceNum(16), var_Number, "initial value of var y", "Number");
  var var_y = new GraceNum(16);
  var reader23_y = function() {  // reader method y
      if (var_y === undefined) raiseUninitializedVariable("y");
      return var_y;
  };
  reader23_y.isVar = true;
  this.methods["y"] = reader23_y;
  var writer24_y = function(argcv, n) {   // writer method y:=(_)
    assertTypeOrMsg(n, var_Number, "argument to y:=(_)", "Number");
    var_y = n;
    return GraceDone;
  };
  this.methods["y:=(1)"] = writer24_y;
  setLineNumber(15);    // compilenode object
  var obj25_build = function(ignore, outerObj, aliases, exclusions) {
    this.closureKeys = this.closureKeys || [];
    this.closureKeys.push("outer_objectsMethodsClasses__95__test_15");
    this.outer_objectsMethodsClasses__95__test_15 = outerObj;
    var inheritedExclusions = { };
    for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
        var exMeth = exclusions[eix];
        inheritedExclusions[exMeth] = this.methods[exMeth];
    }
    this.data.sf = undefined;
    var reader26_sf = function() {  // reader method sf
        if (this.data.sf === undefined) raiseUninitializedVariable("sf");
        return this.data.sf;
    };
    reader26_sf.isVar = true;
    this.methods["sf"] = reader26_sf;
    var writer27_sf = function(argcv, n) {   // writer method sf:=(_)
      assertTypeOrMsg(n, var_Number, "argument to sf:=(_)", "Number");
      this.data.sf = n;
      return GraceDone;
    };
    this.methods["sf:=(1)"] = writer27_sf;
    var func28 = function(argcv, var_m) {     // accessor method p(1)
      return var_m;
    };    // end of method p(_)
    func28.paramTypes = [];
    func28.paramTypes.push([type_Number, "m"]);
    this.methods["p(1)"] = func28;
    func28.paramCounts = [1];
    func28.paramNames = ["m"];
    func28.typeParamNames = [];
    func28.definitionLine = 17;
    func28.definitionModule = "objectsMethodsClasses_test";
    var func29 = function(argcv) {    // method q, line 18
      var returnTarget = invocationCount;
      invocationCount++;
      setModuleName("objectsMethodsClasses_test");
      setLineNumber(18);    // compilenode string
      var string30 = new GraceString("d");
      assertTypeOrMsg(string30, var_String, "result of method q", "String");
      return string30;
    };    // end of method q
    this.methods["q"] = func29;
    func29.paramCounts = [0];
    func29.paramNames = [];
    func29.typeParamNames = [];
    func29.definitionLine = 18;
    func29.definitionModule = "objectsMethodsClasses_test";
    this.mutable = true;
    for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
        var oneAlias = aliases[aix];
        this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
    }
    for (var exName in inheritedExclusions) {
        if (inheritedExclusions.hasOwnProperty(exName)) {
            if (inheritedExclusions[exName]) {
                this.methods[exName] = inheritedExclusions[exName];
            } else {
                delete this.methods[exName];
            }
        }
    }
    var obj25_init = function() {    // init of object on line 15
      setModuleName("objectsMethodsClasses_test");
      setLineNumber(16);    // typecheck
      assertTypeOrMsg(new GraceNum(12), var_Number, "value assigned to sf", "Number");
      this.data.sf = new GraceNum(12);
    };
    return obj25_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
  };
  var obj25 = emptyGraceObject("obj", "objectsMethodsClasses_test", 15);
  var obj25_init = obj25_build.call(obj25, null, this, [], []);
  obj25_init.call(obj25);  // end of compileobject
  var var_obj = obj25;
  var reader31_obj = function() {  // reader method obj
      if (var_obj === undefined) raiseUninitializedVariable("obj");
      return var_obj;
  };
  reader31_obj.isDef = true;
  reader31_obj.confidential = true;
  this.methods["obj"] = reader31_obj;
  setLineNumber(15);    // typecheck
  assertTypeOrMsg(var_obj, var_A, "value of def obj", "A");
  setLineNumber(21);    // compilenode member
  // call case 6: other requests
  if (var_obj === undefined) raiseUninitializedVariable("obj");
  var call32 = request(var_obj, "sf", [0]);
  setLineNumber(23);    // compilenode num
  // call case 6: other requests
  if (var_obj === undefined) raiseUninitializedVariable("obj");
  var call33 = request(var_obj, "p(1)", [1], new GraceNum(23));
  setLineNumber(39);    // compilenode member
  // call case 4: self request
  var call34 = selfRequest(this, "cc", [0]);
  var var_co = call34;
  var reader35_co = function() {  // reader method co
      if (var_co === undefined) raiseUninitializedVariable("co");
      return var_co;
  };
  reader35_co.isDef = true;
  reader35_co.confidential = true;
  this.methods["co"] = reader35_co;
  assertTypeOrMsg(var_co, var_A, "value of def co", "A");
  setLineNumber(40);    // compilenode member
  // call case 6: other requests
  if (var_co === undefined) raiseUninitializedVariable("co");
  var call36 = request(var_co, "sf", [0]);
  setLineNumber(41);    // compilenode num
  // call case 6: other requests
  if (var_co === undefined) raiseUninitializedVariable("co");
  var call37 = request(var_co, "sf:=(1)", [1], new GraceNum(5));
  setLineNumber(42);    // compilenode string
  var string38 = new GraceString("co.sf = ");
  // call case 6: other requests
  if (var_co === undefined) raiseUninitializedVariable("co");
  var call39 = request(var_co, "sf", [0]);
  var opresult40 = request(string38, "++(1)", [1], call39);
  var string41 = new GraceString("");
  var opresult42 = request(opresult40, "++(1)", [1], string41);
  Grace_print(opresult42);
  setLineNumber(44);    // compilenode string
  var string43 = new GraceString("");
  // call case 6: other requests
  // call case 4: self request
  var call45 = selfRequest(this, "c", [0]);
  var call44 = request(call45, "q", [0]);
  var opresult46 = request(string43, "++(1)", [1], call44);
  var string47 = new GraceString("");
  var opresult48 = request(opresult46, "++(1)", [1], string47);
  Grace_print(opresult48);
  setLineNumber(46);    // compilenode num
  // call case 6: other requests
  // call case 4: self request
  var call50 = selfRequest(this, "c", [0]);
  var call49 = request(call50, "p(1)", [1], new GraceNum(17));
  Grace_print(call49);
  setLineNumber(48);    // compilenode member
  // call case 4: self request
  var call51 = selfRequest(this, "c", [0]);
  var var_d = call51;
  var reader52_d = function() {  // reader method d
      if (var_d === undefined) raiseUninitializedVariable("d");
      return var_d;
  };
  reader52_d.isDef = true;
  reader52_d.confidential = true;
  this.methods["d"] = reader52_d;
  assertTypeOrMsg(var_d, var_A, "value of def d", "A");
  setLineNumber(49);    // compilenode member
  // call case 6: other requests
  if (var_d === undefined) raiseUninitializedVariable("d");
  var call53 = request(var_d, "sf", [0]);
  Grace_print(call53);
  setLineNumber(50);    // compilenode num
  // call case 6: other requests
  if (var_d === undefined) raiseUninitializedVariable("d");
  var call54 = request(var_d, "sf:=(1)", [1], new GraceNum(12));
  setLineNumber(51);    // compilenode member
  // call case 6: other requests
  if (var_d === undefined) raiseUninitializedVariable("d");
  var call55 = request(var_d, "sf", [0]);
  var diff56 = request(call55, "-(1)", [1], new GraceNum(47));
  var var_xy = diff56;
  var reader57_xy = function() {  // reader method xy
      if (var_xy === undefined) raiseUninitializedVariable("xy");
      return var_xy;
  };
  reader57_xy.isDef = true;
  reader57_xy.confidential = true;
  this.methods["xy"] = reader57_xy;
  assertTypeOrMsg(var_xy, var_Number, "value of def xy", "Number");
  setLineNumber(52);    // compilenode call
  if (var_xy === undefined) raiseUninitializedVariable("xy");
  Grace_print(var_xy);
  setLineNumber(54);    // compilenode num
  // call case 6: other requests
  // call case 4: self request
  var call59 = selfRequest(this, "c", [0]);
  var call58 = request(call59, "p(1)", [1], new GraceNum(11));
  var sum60 = request(new GraceNum(1), "+(1)", [1], call58);
  Grace_print(sum60);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_objectsMethodsClasses__95__test = gracecode_objectsMethodsClasses__95__test;
if (typeof window !== "undefined")
  window.gracecode_objectsMethodsClasses__95__test = gracecode_objectsMethodsClasses__95__test;
gracecode_objectsMethodsClasses__95__test.imports = ["StaticTyping"];
