;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["recursiveTypeDebugging"] = "classes:\nconfidential:\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/recursiveTypeDebugging.grace\npublic:\n A\n B\npublicMethodTypes:\ntypedec-of:A:\n type A = interface {\n            m \u2192 B}\ntypedec-of:B:\n type B = interface {\n            n \u2192 Number}\ntypes:\n A\n B\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["recursiveTypeDebugging"] = [
    "dialect \"StaticTyping\"",
    "",
    "type B = {",
    "    n -> Number",
    "}",
    "",
    "type A = {",
    "    m -> B",
    "}" ];
}
function gracecode_recursiveTypeDebugging() {
  setModuleName("recursiveTypeDebugging");
  importedModules["recursiveTypeDebugging"] = this;
  var module$recursiveTypeDebugging = this;
  this.definitionModule = "recursiveTypeDebugging";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_recursiveTypeDebugging_0");
  this.outer_recursiveTypeDebugging_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(3);    // compilenode typedec
  // Type decl B
  //   Type literal 
  var typeLit1 = new GraceType("B");
  typeLit1.typeMethods.push("n");
  var var_B = typeLit1;
  var type0 = typeLit1;
  var func2 = function(argcv) {     // accessor method B
    return var_B;
  };    // end of method B
  this.methods["B"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 1;
  func2.definitionModule = "recursiveTypeDebugging";
  setLineNumber(7);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit4 = new GraceType("A");
  typeLit4.typeMethods.push("m");
  var var_A = typeLit4;
  var type3 = typeLit4;
  var func5 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func5;
  func5.paramCounts = [0];
  func5.paramNames = [];
  func5.typeParamNames = [];
  func5.definitionLine = 1;
  func5.definitionModule = "recursiveTypeDebugging";
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_recursiveTypeDebugging = gracecode_recursiveTypeDebugging;
if (typeof window !== "undefined")
  window.gracecode_recursiveTypeDebugging = gracecode_recursiveTypeDebugging;
gracecode_recursiveTypeDebugging.imports = ["StaticTyping"];
