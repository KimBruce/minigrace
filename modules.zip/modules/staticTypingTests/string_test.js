;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["string_test"] = "classes:\nconfidential:\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/string_test.grace\npublic:\n test_compareGreaterThan_concat_second\n test_compareGreaterThan_concat_shorter\n test_compareGreaterThan_flat\n test_compareLessThan_concat_second\n test_compareLessThan_concat_shorter\n test_compareLessThan_flat\n test_compare_identity_concat\n test_compare_identity_flat\n test_compare_same_concat\n test_comparegreaterThan_concat_first\n test_comparelessThan_concat_first\n test_concat\n test_equal_equal_flat\n test_greaterThanOrEqual_concat_first\n test_greaterThanOrEqual_concat_second\n test_greaterThanOrEqual_concat_shorter\n test_greaterThanOrEqual_equal_flat\n test_greaterThanOrEqual_flat\n test_greaterThan_concat_first\n test_greaterThan_concat_second\n test_greaterThan_concat_shorter\n test_greaterThan_flat\n test_lessThanOrEqual_concat_first\n test_lessThanOrEqual_concat_second\n test_lessThanOrEqual_concat_shorter\n test_lessThanOrEqual_equal_flat\n test_lessThanOrEqual_flat\n test_lessThan_concat_first\n test_lessThan_concat_second\n test_lessThan_concat_shorter\n test_lessThan_flat\npublicMethod:test_compareGreaterThan_concat_second:\n test_compareGreaterThan_concat_second \u2192 Boolean\npublicMethod:test_compareGreaterThan_concat_shorter:\n test_compareGreaterThan_concat_shorter \u2192 Boolean\npublicMethod:test_compareGreaterThan_flat:\n test_compareGreaterThan_flat \u2192 Boolean\npublicMethod:test_compareLessThan_concat_second:\n test_compareLessThan_concat_second \u2192 Boolean\npublicMethod:test_compareLessThan_concat_shorter:\n test_compareLessThan_concat_shorter \u2192 Boolean\npublicMethod:test_compareLessThan_flat:\n test_compareLessThan_flat \u2192 Boolean\npublicMethod:test_compare_identity_concat:\n test_compare_identity_concat \u2192 Boolean\npublicMethod:test_compare_identity_flat:\n test_compare_identity_flat \u2192 Boolean\npublicMethod:test_compare_same_concat:\n test_compare_same_concat \u2192 Boolean\npublicMethod:test_comparegreaterThan_concat_first:\n test_comparegreaterThan_concat_first \u2192 Boolean\npublicMethod:test_comparelessThan_concat_first:\n test_comparelessThan_concat_first \u2192 Boolean\npublicMethod:test_concat:\n test_concat \u2192 String\npublicMethod:test_equal_equal_flat:\n test_equal_equal_flat \u2192 Boolean\npublicMethod:test_greaterThanOrEqual_concat_first:\n test_greaterThanOrEqual_concat_first \u2192 Boolean\npublicMethod:test_greaterThanOrEqual_concat_second:\n test_greaterThanOrEqual_concat_second \u2192 Boolean\npublicMethod:test_greaterThanOrEqual_concat_shorter:\n test_greaterThanOrEqual_concat_shorter \u2192 Boolean\npublicMethod:test_greaterThanOrEqual_equal_flat:\n test_greaterThanOrEqual_equal_flat \u2192 Boolean\npublicMethod:test_greaterThanOrEqual_flat:\n test_greaterThanOrEqual_flat \u2192 Boolean\npublicMethod:test_greaterThan_concat_first:\n test_greaterThan_concat_first \u2192 Boolean\npublicMethod:test_greaterThan_concat_second:\n test_greaterThan_concat_second \u2192 Boolean\npublicMethod:test_greaterThan_concat_shorter:\n test_greaterThan_concat_shorter \u2192 Boolean\npublicMethod:test_greaterThan_flat:\n test_greaterThan_flat \u2192 Boolean\npublicMethod:test_lessThanOrEqual_concat_first:\n test_lessThanOrEqual_concat_first \u2192 Boolean\npublicMethod:test_lessThanOrEqual_concat_second:\n test_lessThanOrEqual_concat_second \u2192 Boolean\npublicMethod:test_lessThanOrEqual_concat_shorter:\n test_lessThanOrEqual_concat_shorter \u2192 Boolean\npublicMethod:test_lessThanOrEqual_equal_flat:\n test_lessThanOrEqual_equal_flat \u2192 Boolean\npublicMethod:test_lessThanOrEqual_flat:\n test_lessThanOrEqual_flat \u2192 Boolean\npublicMethod:test_lessThan_concat_first:\n test_lessThan_concat_first \u2192 Boolean\npublicMethod:test_lessThan_concat_second:\n test_lessThan_concat_second \u2192 Boolean\npublicMethod:test_lessThan_concat_shorter:\n test_lessThan_concat_shorter \u2192 Boolean\npublicMethod:test_lessThan_flat:\n test_lessThan_flat \u2192 Boolean\npublicMethodTypes:\n test_compareGreaterThan_concat_second \u2192 Boolean\n test_compareGreaterThan_concat_shorter \u2192 Boolean\n test_compareGreaterThan_flat \u2192 Boolean\n test_compareLessThan_concat_second \u2192 Boolean\n test_compareLessThan_concat_shorter \u2192 Boolean\n test_compareLessThan_flat \u2192 Boolean\n test_compare_identity_concat \u2192 Boolean\n test_compare_identity_flat \u2192 Boolean\n test_compare_same_concat \u2192 Boolean\n test_comparegreaterThan_concat_first \u2192 Boolean\n test_comparelessThan_concat_first \u2192 Boolean\n test_concat \u2192 String\n test_equal_equal_flat \u2192 Boolean\n test_greaterThanOrEqual_concat_first \u2192 Boolean\n test_greaterThanOrEqual_concat_second \u2192 Boolean\n test_greaterThanOrEqual_concat_shorter \u2192 Boolean\n test_greaterThanOrEqual_equal_flat \u2192 Boolean\n test_greaterThanOrEqual_flat \u2192 Boolean\n test_greaterThan_concat_first \u2192 Boolean\n test_greaterThan_concat_second \u2192 Boolean\n test_greaterThan_concat_shorter \u2192 Boolean\n test_greaterThan_flat \u2192 Boolean\n test_lessThanOrEqual_concat_first \u2192 Boolean\n test_lessThanOrEqual_concat_second \u2192 Boolean\n test_lessThanOrEqual_concat_shorter \u2192 Boolean\n test_lessThanOrEqual_equal_flat \u2192 Boolean\n test_lessThanOrEqual_flat \u2192 Boolean\n test_lessThan_concat_first \u2192 Boolean\n test_lessThan_concat_second \u2192 Boolean\n test_lessThan_concat_shorter \u2192 Boolean\n test_lessThan_flat \u2192 Boolean\ntypes:\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["string_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "method test_concat → String  {",
    "",
    "    (\"abc\" ++ \"def\")",
    "}",
    "",
    "method test_compare_identity_concat  → Boolean  {",
    "    def s: String = \"abcd\" ++ \"ef\"",
    "    (s.compare(s) == 0)",
    "}",
    "",
    "method test_compare_same_concat  → Boolean{",
    "    def s: String = \"abcd\" ++ \"ef\"",
    "    def t: String = \"abcdef\"",
    "    (s.compare(t) == 0)",
    "}",
    "",
    "method test_compare_identity_flat  → Boolean  {",
    "    def s: String = \"rstuvwxyz\"",
    "    (s.compare(s) == 0)",
    "}",
    "",
    "method test_comparelessThan_concat_first  → Boolean  {",
    "    def s: String = \"abcd\" ++ \"ef\"",
    "    def t: String =\"bcdef\"",
    "    (s.compare(t) == -1)",
    "}",
    "",
    "method test_compareLessThan_concat_second  → Boolean {",
    "    def s: String =\"abcd\" ++ \"ea\"",
    "    def t: String =\"abcd\" ++  \"ef\"",
    "    (s.compare(t) == -1)",
    "}",
    "",
    "method test_compareLessThan_concat_shorter  → Boolean {",
    "    def s: String =\"abcd\" ++ \"e\"",
    "    def t: String =\"abcd\" ++ \"ef\"",
    "    (s.compare(t) == -1)",
    "}",
    "",
    "method test_compareLessThan_flat  → Boolean {",
    "    def s: String =\"abcdea\"",
    "    def t: String =\"abcdef\"",
    "    (s.compare(t) == -1)",
    "}",
    "",
    "method test_comparegreaterThan_concat_first  → Boolean {",
    "    def s: String =\"abcd\" ++ \"ef\"",
    "    def t: String =\"aacd\"",
    "    (s.compare(t) == 1)",
    "}",
    "",
    "method test_compareGreaterThan_concat_second  → Boolean {",
    "    def s: String =\"abcd\" ++ \"ef\"",
    "    def t: String =\"abcd\" ++ \"ea\"",
    "    (s.compare(t) == 1)",
    "}",
    "",
    "method test_compareGreaterThan_concat_shorter  → Boolean {",
    "    def s: String =\"abcd\" ++ \"x\"",
    "    def t: String =\"abcd\" ++ \"ef\"",
    "    (s.compare(t) == 1)",
    "}",
    "",
    "method test_compareGreaterThan_flat  → Boolean {",
    "    def s: String =\"abcdef\"",
    "    def t: String =\"abcdea\"",
    "    (s.compare(t) == 1)",
    "}",
    "",
    "method test_lessThan_concat_first  → Boolean {",
    "    def s: String =\"abcd\" ++ \"ef\"",
    "    def t: String =\"bcdef\"",
    "    (s < t)",
    "}",
    "",
    "method test_lessThan_concat_second  → Boolean {",
    "    def s: String =\"abcd\" ++ \"ea\"",
    "    def t: String =\"abcd\" ++ \"ef\"",
    "    (s < t)",
    "}",
    "",
    "method test_lessThan_concat_shorter  → Boolean {",
    "    def s: String =\"abcd\" ++ \"e\"",
    "    def t: String =\"abcd\" ++ \"ef\"",
    "    (s < t)",
    "}",
    "",
    "method test_lessThan_flat  → Boolean {",
    "    def s: String =\"abcdea\"",
    "    def t: String =\"abcdef\"",
    "    (s < t)",
    "}",
    "",
    "method test_greaterThan_concat_first  → Boolean {",
    "    def s: String =\"abcd\" ++ \"ef\"",
    "    def t: String =\"aacd\"",
    "    (s > t)",
    "}",
    "",
    "method test_greaterThan_concat_second  → Boolean {",
    "    def s: String =\"abcd\" ++ \"ef\"",
    "    def t: String =\"abcd\" ++ \"ea\"",
    "    (s > t)",
    "}",
    "",
    "method test_greaterThan_concat_shorter  → Boolean {",
    "    def s: String =\"abcd\" ++ \"x\"",
    "    def t: String =\"abcd\" ++ \"ef\"",
    "    (s > t)",
    "}",
    "",
    "method test_greaterThan_flat  → Boolean {",
    "    def s: String =\"abcdef\"",
    "    def t: String =\"abcdea\"",
    "    (s > t)",
    "}",
    "",
    "method test_lessThanOrEqual_concat_first  → Boolean {",
    "    def s: String =\"abcd\" ++ \"ef\"",
    "    def t: String =\"bcdef\"",
    "    (s ≤ t) &&(s <= t)",
    "}",
    "",
    "method test_lessThanOrEqual_concat_second  → Boolean {",
    "    def s: String =\"abcd\" ++ \"ea\"",
    "    def t: String =\"abcd\" ++ \"ef\"",
    "    (s ≤ t) &&(s <= t)",
    "}",
    "",
    "method test_lessThanOrEqual_concat_shorter  → Boolean {",
    "    def s: String =\"abcd\" ++ \"e\"",
    "    def t: String =\"abcd\" ++ \"ef\"",
    "    (s ≤ t) &&(s <= t)",
    "}",
    "",
    "method test_lessThanOrEqual_flat  → Boolean {",
    "    def s: String =\"abcdea\"",
    "    def t: String =\"abcdef\"",
    "    (s ≤ t) &&(s <= t)",
    "}",
    "",
    "method test_lessThanOrEqual_equal_flat  → Boolean {",
    "    def s: String =\"abcdef\"",
    "    def t: String =\"abcdef\"",
    "    (s ≤ t) && (s <= t)",
    "}",
    "",
    "method test_greaterThanOrEqual_concat_first  → Boolean {",
    "    def s: String =\"abcd\" ++ \"ef\"",
    "    def t: String =\"aacd\"",
    "    (s >= t) && (s ≥ t)",
    "}",
    "",
    "method test_greaterThanOrEqual_concat_second  → Boolean {",
    "    def s: String =\"abcd\" ++ \"ef\"",
    "    def t: String =\"abcd\" ++ \"ea\"",
    "    (s >= t) && (s ≥ t)",
    "}",
    "",
    "method test_greaterThanOrEqual_concat_shorter  → Boolean {",
    "    def s: String =\"abcd\" ++ \"x\"",
    "    def t: String =\"abcd\" ++ \"ef\"",
    "    (s >= t) && (s ≥ t)",
    "}",
    "",
    "method test_greaterThanOrEqual_flat  → Boolean {",
    "    def s: String =\"abcdef\"",
    "    def t: String =\"abcdea\"",
    "    (s >= t) &&  (s ≥ t)",
    "}",
    "",
    "method test_greaterThanOrEqual_equal_flat  → Boolean {",
    "    def s: String =\"abcdef\"",
    "    def t: String =\"abcdef\"",
    "    (s >= t) &&(s ≥ t)",
    "}",
    "",
    "method test_equal_equal_flat  → Boolean {",
    "    def s: String =\"abcdef\"",
    "    def t: String =\"abcdef\"",
    "    (s == t) &&((s ≥ t) &&(s ≤ t))",
    "}",
    "",
    "test_greaterThan_concat_first",
    "",
    "print \"test succeeded\"" ];
}
function gracecode_string__95__test() {
  setModuleName("string_test");
  importedModules["string_test"] = this;
  var module$string__95__test = this;
  this.definitionModule = "string_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_string__95__test_0");
  this.outer_string__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method test_concat, line 3
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(5);    // compilenode string
    var string1 = new GraceString("abc");
    var string2 = new GraceString("def");
    var opresult3 = request(string1, "++(1)", [1], string2);
    assertTypeOrMsg(opresult3, var_String, "result of method test_concat", "String");
    return opresult3;
  };    // end of method test_concat
  this.methods["test_concat"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 3;
  func0.definitionModule = "string_test";
  var func4 = function(argcv) {    // method test_compare_identity_concat, line 8
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(9);    // compilenode string
    var string5 = new GraceString("abcd");
    var string6 = new GraceString("ef");
    var opresult7 = request(string5, "++(1)", [1], string6);
    var var_s = opresult7;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(10);    // compilenode call
    // call case 6: other requests
    var call8 = request(var_s, "compare(1)", [1], var_s);
    var opresult9 = request(call8, "==(1)", [1], new GraceNum(0));
    assertTypeOrMsg(opresult9, var_Boolean, "result of method test_compare_identity_concat", "Boolean");
    return opresult9;
  };    // end of method test_compare_identity_concat
  this.methods["test_compare_identity_concat"] = func4;
  func4.paramCounts = [0];
  func4.paramNames = [];
  func4.typeParamNames = [];
  func4.definitionLine = 8;
  func4.definitionModule = "string_test";
  var func10 = function(argcv) {    // method test_compare_same_concat, line 13
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(14);    // compilenode string
    var string11 = new GraceString("abcd");
    var string12 = new GraceString("ef");
    var opresult13 = request(string11, "++(1)", [1], string12);
    var var_s = opresult13;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(15);    // compilenode string
    var string14 = new GraceString("abcdef");
    var var_t = string14;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(16);    // compilenode call
    // call case 6: other requests
    var call15 = request(var_s, "compare(1)", [1], var_t);
    var opresult16 = request(call15, "==(1)", [1], new GraceNum(0));
    assertTypeOrMsg(opresult16, var_Boolean, "result of method test_compare_same_concat", "Boolean");
    return opresult16;
  };    // end of method test_compare_same_concat
  this.methods["test_compare_same_concat"] = func10;
  func10.paramCounts = [0];
  func10.paramNames = [];
  func10.typeParamNames = [];
  func10.definitionLine = 13;
  func10.definitionModule = "string_test";
  var func17 = function(argcv) {    // method test_compare_identity_flat, line 19
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(20);    // compilenode string
    var string18 = new GraceString("rstuvwxyz");
    var var_s = string18;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(21);    // compilenode call
    // call case 6: other requests
    var call19 = request(var_s, "compare(1)", [1], var_s);
    var opresult20 = request(call19, "==(1)", [1], new GraceNum(0));
    assertTypeOrMsg(opresult20, var_Boolean, "result of method test_compare_identity_flat", "Boolean");
    return opresult20;
  };    // end of method test_compare_identity_flat
  this.methods["test_compare_identity_flat"] = func17;
  func17.paramCounts = [0];
  func17.paramNames = [];
  func17.typeParamNames = [];
  func17.definitionLine = 19;
  func17.definitionModule = "string_test";
  var func21 = function(argcv) {    // method test_comparelessThan_concat_first, line 24
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(25);    // compilenode string
    var string22 = new GraceString("abcd");
    var string23 = new GraceString("ef");
    var opresult24 = request(string22, "++(1)", [1], string23);
    var var_s = opresult24;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(26);    // compilenode string
    var string25 = new GraceString("bcdef");
    var var_t = string25;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(27);    // compilenode call
    // call case 6: other requests
    var call26 = request(var_s, "compare(1)", [1], var_t);
    // call case 6: other requests
    var call27 = request(new GraceNum(1), "prefix-", [0]);
    var opresult28 = request(call26, "==(1)", [1], call27);
    assertTypeOrMsg(opresult28, var_Boolean, "result of method test_comparelessThan_concat_first", "Boolean");
    return opresult28;
  };    // end of method test_comparelessThan_concat_first
  this.methods["test_comparelessThan_concat_first"] = func21;
  func21.paramCounts = [0];
  func21.paramNames = [];
  func21.typeParamNames = [];
  func21.definitionLine = 24;
  func21.definitionModule = "string_test";
  var func29 = function(argcv) {    // method test_compareLessThan_concat_second, line 30
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(31);    // compilenode string
    var string30 = new GraceString("abcd");
    var string31 = new GraceString("ea");
    var opresult32 = request(string30, "++(1)", [1], string31);
    var var_s = opresult32;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(32);    // compilenode string
    var string33 = new GraceString("abcd");
    var string34 = new GraceString("ef");
    var opresult35 = request(string33, "++(1)", [1], string34);
    var var_t = opresult35;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(33);    // compilenode call
    // call case 6: other requests
    var call36 = request(var_s, "compare(1)", [1], var_t);
    // call case 6: other requests
    var call37 = request(new GraceNum(1), "prefix-", [0]);
    var opresult38 = request(call36, "==(1)", [1], call37);
    assertTypeOrMsg(opresult38, var_Boolean, "result of method test_compareLessThan_concat_second", "Boolean");
    return opresult38;
  };    // end of method test_compareLessThan_concat_second
  this.methods["test_compareLessThan_concat_second"] = func29;
  func29.paramCounts = [0];
  func29.paramNames = [];
  func29.typeParamNames = [];
  func29.definitionLine = 30;
  func29.definitionModule = "string_test";
  var func39 = function(argcv) {    // method test_compareLessThan_concat_shorter, line 36
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(37);    // compilenode string
    var string40 = new GraceString("abcd");
    var string41 = new GraceString("e");
    var opresult42 = request(string40, "++(1)", [1], string41);
    var var_s = opresult42;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(38);    // compilenode string
    var string43 = new GraceString("abcd");
    var string44 = new GraceString("ef");
    var opresult45 = request(string43, "++(1)", [1], string44);
    var var_t = opresult45;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(39);    // compilenode call
    // call case 6: other requests
    var call46 = request(var_s, "compare(1)", [1], var_t);
    // call case 6: other requests
    var call47 = request(new GraceNum(1), "prefix-", [0]);
    var opresult48 = request(call46, "==(1)", [1], call47);
    assertTypeOrMsg(opresult48, var_Boolean, "result of method test_compareLessThan_concat_shorter", "Boolean");
    return opresult48;
  };    // end of method test_compareLessThan_concat_shorter
  this.methods["test_compareLessThan_concat_shorter"] = func39;
  func39.paramCounts = [0];
  func39.paramNames = [];
  func39.typeParamNames = [];
  func39.definitionLine = 36;
  func39.definitionModule = "string_test";
  var func49 = function(argcv) {    // method test_compareLessThan_flat, line 42
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(43);    // compilenode string
    var string50 = new GraceString("abcdea");
    var var_s = string50;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(44);    // compilenode string
    var string51 = new GraceString("abcdef");
    var var_t = string51;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(45);    // compilenode call
    // call case 6: other requests
    var call52 = request(var_s, "compare(1)", [1], var_t);
    // call case 6: other requests
    var call53 = request(new GraceNum(1), "prefix-", [0]);
    var opresult54 = request(call52, "==(1)", [1], call53);
    assertTypeOrMsg(opresult54, var_Boolean, "result of method test_compareLessThan_flat", "Boolean");
    return opresult54;
  };    // end of method test_compareLessThan_flat
  this.methods["test_compareLessThan_flat"] = func49;
  func49.paramCounts = [0];
  func49.paramNames = [];
  func49.typeParamNames = [];
  func49.definitionLine = 42;
  func49.definitionModule = "string_test";
  var func55 = function(argcv) {    // method test_comparegreaterThan_concat_first, line 48
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(49);    // compilenode string
    var string56 = new GraceString("abcd");
    var string57 = new GraceString("ef");
    var opresult58 = request(string56, "++(1)", [1], string57);
    var var_s = opresult58;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(50);    // compilenode string
    var string59 = new GraceString("aacd");
    var var_t = string59;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(51);    // compilenode call
    // call case 6: other requests
    var call60 = request(var_s, "compare(1)", [1], var_t);
    var opresult61 = request(call60, "==(1)", [1], new GraceNum(1));
    assertTypeOrMsg(opresult61, var_Boolean, "result of method test_comparegreaterThan_concat_first", "Boolean");
    return opresult61;
  };    // end of method test_comparegreaterThan_concat_first
  this.methods["test_comparegreaterThan_concat_first"] = func55;
  func55.paramCounts = [0];
  func55.paramNames = [];
  func55.typeParamNames = [];
  func55.definitionLine = 48;
  func55.definitionModule = "string_test";
  var func62 = function(argcv) {    // method test_compareGreaterThan_concat_second, line 54
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(55);    // compilenode string
    var string63 = new GraceString("abcd");
    var string64 = new GraceString("ef");
    var opresult65 = request(string63, "++(1)", [1], string64);
    var var_s = opresult65;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(56);    // compilenode string
    var string66 = new GraceString("abcd");
    var string67 = new GraceString("ea");
    var opresult68 = request(string66, "++(1)", [1], string67);
    var var_t = opresult68;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(57);    // compilenode call
    // call case 6: other requests
    var call69 = request(var_s, "compare(1)", [1], var_t);
    var opresult70 = request(call69, "==(1)", [1], new GraceNum(1));
    assertTypeOrMsg(opresult70, var_Boolean, "result of method test_compareGreaterThan_concat_second", "Boolean");
    return opresult70;
  };    // end of method test_compareGreaterThan_concat_second
  this.methods["test_compareGreaterThan_concat_second"] = func62;
  func62.paramCounts = [0];
  func62.paramNames = [];
  func62.typeParamNames = [];
  func62.definitionLine = 54;
  func62.definitionModule = "string_test";
  var func71 = function(argcv) {    // method test_compareGreaterThan_concat_shorter, line 60
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(61);    // compilenode string
    var string72 = new GraceString("abcd");
    var string73 = new GraceString("x");
    var opresult74 = request(string72, "++(1)", [1], string73);
    var var_s = opresult74;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(62);    // compilenode string
    var string75 = new GraceString("abcd");
    var string76 = new GraceString("ef");
    var opresult77 = request(string75, "++(1)", [1], string76);
    var var_t = opresult77;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(63);    // compilenode call
    // call case 6: other requests
    var call78 = request(var_s, "compare(1)", [1], var_t);
    var opresult79 = request(call78, "==(1)", [1], new GraceNum(1));
    assertTypeOrMsg(opresult79, var_Boolean, "result of method test_compareGreaterThan_concat_shorter", "Boolean");
    return opresult79;
  };    // end of method test_compareGreaterThan_concat_shorter
  this.methods["test_compareGreaterThan_concat_shorter"] = func71;
  func71.paramCounts = [0];
  func71.paramNames = [];
  func71.typeParamNames = [];
  func71.definitionLine = 60;
  func71.definitionModule = "string_test";
  var func80 = function(argcv) {    // method test_compareGreaterThan_flat, line 66
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(67);    // compilenode string
    var string81 = new GraceString("abcdef");
    var var_s = string81;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(68);    // compilenode string
    var string82 = new GraceString("abcdea");
    var var_t = string82;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(69);    // compilenode call
    // call case 6: other requests
    var call83 = request(var_s, "compare(1)", [1], var_t);
    var opresult84 = request(call83, "==(1)", [1], new GraceNum(1));
    assertTypeOrMsg(opresult84, var_Boolean, "result of method test_compareGreaterThan_flat", "Boolean");
    return opresult84;
  };    // end of method test_compareGreaterThan_flat
  this.methods["test_compareGreaterThan_flat"] = func80;
  func80.paramCounts = [0];
  func80.paramNames = [];
  func80.typeParamNames = [];
  func80.definitionLine = 66;
  func80.definitionModule = "string_test";
  var func85 = function(argcv) {    // method test_lessThan_concat_first, line 72
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(73);    // compilenode string
    var string86 = new GraceString("abcd");
    var string87 = new GraceString("ef");
    var opresult88 = request(string86, "++(1)", [1], string87);
    var var_s = opresult88;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(74);    // compilenode string
    var string89 = new GraceString("bcdef");
    var var_t = string89;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(75);    // compilenode op
    var opresult90 = request(var_s, "<(1)", [1], var_t);
    assertTypeOrMsg(opresult90, var_Boolean, "result of method test_lessThan_concat_first", "Boolean");
    return opresult90;
  };    // end of method test_lessThan_concat_first
  this.methods["test_lessThan_concat_first"] = func85;
  func85.paramCounts = [0];
  func85.paramNames = [];
  func85.typeParamNames = [];
  func85.definitionLine = 72;
  func85.definitionModule = "string_test";
  var func91 = function(argcv) {    // method test_lessThan_concat_second, line 78
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(79);    // compilenode string
    var string92 = new GraceString("abcd");
    var string93 = new GraceString("ea");
    var opresult94 = request(string92, "++(1)", [1], string93);
    var var_s = opresult94;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(80);    // compilenode string
    var string95 = new GraceString("abcd");
    var string96 = new GraceString("ef");
    var opresult97 = request(string95, "++(1)", [1], string96);
    var var_t = opresult97;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(81);    // compilenode op
    var opresult98 = request(var_s, "<(1)", [1], var_t);
    assertTypeOrMsg(opresult98, var_Boolean, "result of method test_lessThan_concat_second", "Boolean");
    return opresult98;
  };    // end of method test_lessThan_concat_second
  this.methods["test_lessThan_concat_second"] = func91;
  func91.paramCounts = [0];
  func91.paramNames = [];
  func91.typeParamNames = [];
  func91.definitionLine = 78;
  func91.definitionModule = "string_test";
  var func99 = function(argcv) {    // method test_lessThan_concat_shorter, line 84
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(85);    // compilenode string
    var string100 = new GraceString("abcd");
    var string101 = new GraceString("e");
    var opresult102 = request(string100, "++(1)", [1], string101);
    var var_s = opresult102;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(86);    // compilenode string
    var string103 = new GraceString("abcd");
    var string104 = new GraceString("ef");
    var opresult105 = request(string103, "++(1)", [1], string104);
    var var_t = opresult105;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(87);    // compilenode op
    var opresult106 = request(var_s, "<(1)", [1], var_t);
    assertTypeOrMsg(opresult106, var_Boolean, "result of method test_lessThan_concat_shorter", "Boolean");
    return opresult106;
  };    // end of method test_lessThan_concat_shorter
  this.methods["test_lessThan_concat_shorter"] = func99;
  func99.paramCounts = [0];
  func99.paramNames = [];
  func99.typeParamNames = [];
  func99.definitionLine = 84;
  func99.definitionModule = "string_test";
  var func107 = function(argcv) {    // method test_lessThan_flat, line 90
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(91);    // compilenode string
    var string108 = new GraceString("abcdea");
    var var_s = string108;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(92);    // compilenode string
    var string109 = new GraceString("abcdef");
    var var_t = string109;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(93);    // compilenode op
    var opresult110 = request(var_s, "<(1)", [1], var_t);
    assertTypeOrMsg(opresult110, var_Boolean, "result of method test_lessThan_flat", "Boolean");
    return opresult110;
  };    // end of method test_lessThan_flat
  this.methods["test_lessThan_flat"] = func107;
  func107.paramCounts = [0];
  func107.paramNames = [];
  func107.typeParamNames = [];
  func107.definitionLine = 90;
  func107.definitionModule = "string_test";
  var func111 = function(argcv) {    // method test_greaterThan_concat_first, line 96
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(97);    // compilenode string
    var string112 = new GraceString("abcd");
    var string113 = new GraceString("ef");
    var opresult114 = request(string112, "++(1)", [1], string113);
    var var_s = opresult114;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(98);    // compilenode string
    var string115 = new GraceString("aacd");
    var var_t = string115;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(99);    // compilenode op
    var opresult116 = request(var_s, ">(1)", [1], var_t);
    assertTypeOrMsg(opresult116, var_Boolean, "result of method test_greaterThan_concat_first", "Boolean");
    return opresult116;
  };    // end of method test_greaterThan_concat_first
  this.methods["test_greaterThan_concat_first"] = func111;
  func111.paramCounts = [0];
  func111.paramNames = [];
  func111.typeParamNames = [];
  func111.definitionLine = 96;
  func111.definitionModule = "string_test";
  var func117 = function(argcv) {    // method test_greaterThan_concat_second, line 102
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(103);    // compilenode string
    var string118 = new GraceString("abcd");
    var string119 = new GraceString("ef");
    var opresult120 = request(string118, "++(1)", [1], string119);
    var var_s = opresult120;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(104);    // compilenode string
    var string121 = new GraceString("abcd");
    var string122 = new GraceString("ea");
    var opresult123 = request(string121, "++(1)", [1], string122);
    var var_t = opresult123;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(105);    // compilenode op
    var opresult124 = request(var_s, ">(1)", [1], var_t);
    assertTypeOrMsg(opresult124, var_Boolean, "result of method test_greaterThan_concat_second", "Boolean");
    return opresult124;
  };    // end of method test_greaterThan_concat_second
  this.methods["test_greaterThan_concat_second"] = func117;
  func117.paramCounts = [0];
  func117.paramNames = [];
  func117.typeParamNames = [];
  func117.definitionLine = 102;
  func117.definitionModule = "string_test";
  var func125 = function(argcv) {    // method test_greaterThan_concat_shorter, line 108
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(109);    // compilenode string
    var string126 = new GraceString("abcd");
    var string127 = new GraceString("x");
    var opresult128 = request(string126, "++(1)", [1], string127);
    var var_s = opresult128;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(110);    // compilenode string
    var string129 = new GraceString("abcd");
    var string130 = new GraceString("ef");
    var opresult131 = request(string129, "++(1)", [1], string130);
    var var_t = opresult131;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(111);    // compilenode op
    var opresult132 = request(var_s, ">(1)", [1], var_t);
    assertTypeOrMsg(opresult132, var_Boolean, "result of method test_greaterThan_concat_shorter", "Boolean");
    return opresult132;
  };    // end of method test_greaterThan_concat_shorter
  this.methods["test_greaterThan_concat_shorter"] = func125;
  func125.paramCounts = [0];
  func125.paramNames = [];
  func125.typeParamNames = [];
  func125.definitionLine = 108;
  func125.definitionModule = "string_test";
  var func133 = function(argcv) {    // method test_greaterThan_flat, line 114
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(115);    // compilenode string
    var string134 = new GraceString("abcdef");
    var var_s = string134;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(116);    // compilenode string
    var string135 = new GraceString("abcdea");
    var var_t = string135;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(117);    // compilenode op
    var opresult136 = request(var_s, ">(1)", [1], var_t);
    assertTypeOrMsg(opresult136, var_Boolean, "result of method test_greaterThan_flat", "Boolean");
    return opresult136;
  };    // end of method test_greaterThan_flat
  this.methods["test_greaterThan_flat"] = func133;
  func133.paramCounts = [0];
  func133.paramNames = [];
  func133.typeParamNames = [];
  func133.definitionLine = 114;
  func133.definitionModule = "string_test";
  var func137 = function(argcv) {    // method test_lessThanOrEqual_concat_first, line 120
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(121);    // compilenode string
    var string138 = new GraceString("abcd");
    var string139 = new GraceString("ef");
    var opresult140 = request(string138, "++(1)", [1], string139);
    var var_s = opresult140;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(122);    // compilenode string
    var string141 = new GraceString("bcdef");
    var var_t = string141;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(123);    // compilenode op
    var opresult142 = request(var_s, "\u2264(1)", [1], var_t);
    var opresult143 = request(var_s, "\u2264(1)", [1], var_t);
    var opresult144 = request(opresult142, "&&(1)", [1], opresult143);
    assertTypeOrMsg(opresult144, var_Boolean, "result of method test_lessThanOrEqual_concat_first", "Boolean");
    return opresult144;
  };    // end of method test_lessThanOrEqual_concat_first
  this.methods["test_lessThanOrEqual_concat_first"] = func137;
  func137.paramCounts = [0];
  func137.paramNames = [];
  func137.typeParamNames = [];
  func137.definitionLine = 120;
  func137.definitionModule = "string_test";
  var func145 = function(argcv) {    // method test_lessThanOrEqual_concat_second, line 126
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(127);    // compilenode string
    var string146 = new GraceString("abcd");
    var string147 = new GraceString("ea");
    var opresult148 = request(string146, "++(1)", [1], string147);
    var var_s = opresult148;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(128);    // compilenode string
    var string149 = new GraceString("abcd");
    var string150 = new GraceString("ef");
    var opresult151 = request(string149, "++(1)", [1], string150);
    var var_t = opresult151;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(129);    // compilenode op
    var opresult152 = request(var_s, "\u2264(1)", [1], var_t);
    var opresult153 = request(var_s, "\u2264(1)", [1], var_t);
    var opresult154 = request(opresult152, "&&(1)", [1], opresult153);
    assertTypeOrMsg(opresult154, var_Boolean, "result of method test_lessThanOrEqual_concat_second", "Boolean");
    return opresult154;
  };    // end of method test_lessThanOrEqual_concat_second
  this.methods["test_lessThanOrEqual_concat_second"] = func145;
  func145.paramCounts = [0];
  func145.paramNames = [];
  func145.typeParamNames = [];
  func145.definitionLine = 126;
  func145.definitionModule = "string_test";
  var func155 = function(argcv) {    // method test_lessThanOrEqual_concat_shorter, line 132
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(133);    // compilenode string
    var string156 = new GraceString("abcd");
    var string157 = new GraceString("e");
    var opresult158 = request(string156, "++(1)", [1], string157);
    var var_s = opresult158;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(134);    // compilenode string
    var string159 = new GraceString("abcd");
    var string160 = new GraceString("ef");
    var opresult161 = request(string159, "++(1)", [1], string160);
    var var_t = opresult161;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(135);    // compilenode op
    var opresult162 = request(var_s, "\u2264(1)", [1], var_t);
    var opresult163 = request(var_s, "\u2264(1)", [1], var_t);
    var opresult164 = request(opresult162, "&&(1)", [1], opresult163);
    assertTypeOrMsg(opresult164, var_Boolean, "result of method test_lessThanOrEqual_concat_shorter", "Boolean");
    return opresult164;
  };    // end of method test_lessThanOrEqual_concat_shorter
  this.methods["test_lessThanOrEqual_concat_shorter"] = func155;
  func155.paramCounts = [0];
  func155.paramNames = [];
  func155.typeParamNames = [];
  func155.definitionLine = 132;
  func155.definitionModule = "string_test";
  var func165 = function(argcv) {    // method test_lessThanOrEqual_flat, line 138
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(139);    // compilenode string
    var string166 = new GraceString("abcdea");
    var var_s = string166;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(140);    // compilenode string
    var string167 = new GraceString("abcdef");
    var var_t = string167;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(141);    // compilenode op
    var opresult168 = request(var_s, "\u2264(1)", [1], var_t);
    var opresult169 = request(var_s, "\u2264(1)", [1], var_t);
    var opresult170 = request(opresult168, "&&(1)", [1], opresult169);
    assertTypeOrMsg(opresult170, var_Boolean, "result of method test_lessThanOrEqual_flat", "Boolean");
    return opresult170;
  };    // end of method test_lessThanOrEqual_flat
  this.methods["test_lessThanOrEqual_flat"] = func165;
  func165.paramCounts = [0];
  func165.paramNames = [];
  func165.typeParamNames = [];
  func165.definitionLine = 138;
  func165.definitionModule = "string_test";
  var func171 = function(argcv) {    // method test_lessThanOrEqual_equal_flat, line 144
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(145);    // compilenode string
    var string172 = new GraceString("abcdef");
    var var_s = string172;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(146);    // compilenode string
    var string173 = new GraceString("abcdef");
    var var_t = string173;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(147);    // compilenode op
    var opresult174 = request(var_s, "\u2264(1)", [1], var_t);
    var opresult175 = request(var_s, "\u2264(1)", [1], var_t);
    var opresult176 = request(opresult174, "&&(1)", [1], opresult175);
    assertTypeOrMsg(opresult176, var_Boolean, "result of method test_lessThanOrEqual_equal_flat", "Boolean");
    return opresult176;
  };    // end of method test_lessThanOrEqual_equal_flat
  this.methods["test_lessThanOrEqual_equal_flat"] = func171;
  func171.paramCounts = [0];
  func171.paramNames = [];
  func171.typeParamNames = [];
  func171.definitionLine = 144;
  func171.definitionModule = "string_test";
  var func177 = function(argcv) {    // method test_greaterThanOrEqual_concat_first, line 150
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(151);    // compilenode string
    var string178 = new GraceString("abcd");
    var string179 = new GraceString("ef");
    var opresult180 = request(string178, "++(1)", [1], string179);
    var var_s = opresult180;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(152);    // compilenode string
    var string181 = new GraceString("aacd");
    var var_t = string181;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(153);    // compilenode op
    var opresult182 = request(var_s, "\u2265(1)", [1], var_t);
    var opresult183 = request(var_s, "\u2265(1)", [1], var_t);
    var opresult184 = request(opresult182, "&&(1)", [1], opresult183);
    assertTypeOrMsg(opresult184, var_Boolean, "result of method test_greaterThanOrEqual_concat_first", "Boolean");
    return opresult184;
  };    // end of method test_greaterThanOrEqual_concat_first
  this.methods["test_greaterThanOrEqual_concat_first"] = func177;
  func177.paramCounts = [0];
  func177.paramNames = [];
  func177.typeParamNames = [];
  func177.definitionLine = 150;
  func177.definitionModule = "string_test";
  var func185 = function(argcv) {    // method test_greaterThanOrEqual_concat_second, line 156
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(157);    // compilenode string
    var string186 = new GraceString("abcd");
    var string187 = new GraceString("ef");
    var opresult188 = request(string186, "++(1)", [1], string187);
    var var_s = opresult188;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(158);    // compilenode string
    var string189 = new GraceString("abcd");
    var string190 = new GraceString("ea");
    var opresult191 = request(string189, "++(1)", [1], string190);
    var var_t = opresult191;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(159);    // compilenode op
    var opresult192 = request(var_s, "\u2265(1)", [1], var_t);
    var opresult193 = request(var_s, "\u2265(1)", [1], var_t);
    var opresult194 = request(opresult192, "&&(1)", [1], opresult193);
    assertTypeOrMsg(opresult194, var_Boolean, "result of method test_greaterThanOrEqual_concat_second", "Boolean");
    return opresult194;
  };    // end of method test_greaterThanOrEqual_concat_second
  this.methods["test_greaterThanOrEqual_concat_second"] = func185;
  func185.paramCounts = [0];
  func185.paramNames = [];
  func185.typeParamNames = [];
  func185.definitionLine = 156;
  func185.definitionModule = "string_test";
  var func195 = function(argcv) {    // method test_greaterThanOrEqual_concat_shorter, line 162
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(163);    // compilenode string
    var string196 = new GraceString("abcd");
    var string197 = new GraceString("x");
    var opresult198 = request(string196, "++(1)", [1], string197);
    var var_s = opresult198;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(164);    // compilenode string
    var string199 = new GraceString("abcd");
    var string200 = new GraceString("ef");
    var opresult201 = request(string199, "++(1)", [1], string200);
    var var_t = opresult201;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(165);    // compilenode op
    var opresult202 = request(var_s, "\u2265(1)", [1], var_t);
    var opresult203 = request(var_s, "\u2265(1)", [1], var_t);
    var opresult204 = request(opresult202, "&&(1)", [1], opresult203);
    assertTypeOrMsg(opresult204, var_Boolean, "result of method test_greaterThanOrEqual_concat_shorter", "Boolean");
    return opresult204;
  };    // end of method test_greaterThanOrEqual_concat_shorter
  this.methods["test_greaterThanOrEqual_concat_shorter"] = func195;
  func195.paramCounts = [0];
  func195.paramNames = [];
  func195.typeParamNames = [];
  func195.definitionLine = 162;
  func195.definitionModule = "string_test";
  var func205 = function(argcv) {    // method test_greaterThanOrEqual_flat, line 168
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(169);    // compilenode string
    var string206 = new GraceString("abcdef");
    var var_s = string206;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(170);    // compilenode string
    var string207 = new GraceString("abcdea");
    var var_t = string207;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(171);    // compilenode op
    var opresult208 = request(var_s, "\u2265(1)", [1], var_t);
    var opresult209 = request(var_s, "\u2265(1)", [1], var_t);
    var opresult210 = request(opresult208, "&&(1)", [1], opresult209);
    assertTypeOrMsg(opresult210, var_Boolean, "result of method test_greaterThanOrEqual_flat", "Boolean");
    return opresult210;
  };    // end of method test_greaterThanOrEqual_flat
  this.methods["test_greaterThanOrEqual_flat"] = func205;
  func205.paramCounts = [0];
  func205.paramNames = [];
  func205.typeParamNames = [];
  func205.definitionLine = 168;
  func205.definitionModule = "string_test";
  var func211 = function(argcv) {    // method test_greaterThanOrEqual_equal_flat, line 174
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(175);    // compilenode string
    var string212 = new GraceString("abcdef");
    var var_s = string212;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(176);    // compilenode string
    var string213 = new GraceString("abcdef");
    var var_t = string213;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(177);    // compilenode op
    var opresult214 = request(var_s, "\u2265(1)", [1], var_t);
    var opresult215 = request(var_s, "\u2265(1)", [1], var_t);
    var opresult216 = request(opresult214, "&&(1)", [1], opresult215);
    assertTypeOrMsg(opresult216, var_Boolean, "result of method test_greaterThanOrEqual_equal_flat", "Boolean");
    return opresult216;
  };    // end of method test_greaterThanOrEqual_equal_flat
  this.methods["test_greaterThanOrEqual_equal_flat"] = func211;
  func211.paramCounts = [0];
  func211.paramNames = [];
  func211.typeParamNames = [];
  func211.definitionLine = 174;
  func211.definitionModule = "string_test";
  var func217 = function(argcv) {    // method test_equal_equal_flat, line 180
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("string_test");
    setLineNumber(181);    // compilenode string
    var string218 = new GraceString("abcdef");
    var var_s = string218;
    assertTypeOrMsg(var_s, var_String, "value of def s", "String");
    setLineNumber(182);    // compilenode string
    var string219 = new GraceString("abcdef");
    var var_t = string219;
    assertTypeOrMsg(var_t, var_String, "value of def t", "String");
    setLineNumber(183);    // compilenode op
    var opresult220 = request(var_s, "==(1)", [1], var_t);
    var opresult221 = request(var_s, "\u2265(1)", [1], var_t);
    var opresult222 = request(var_s, "\u2264(1)", [1], var_t);
    var opresult223 = request(opresult221, "&&(1)", [1], opresult222);
    var opresult224 = request(opresult220, "&&(1)", [1], opresult223);
    assertTypeOrMsg(opresult224, var_Boolean, "result of method test_equal_equal_flat", "Boolean");
    return opresult224;
  };    // end of method test_equal_equal_flat
  this.methods["test_equal_equal_flat"] = func217;
  func217.paramCounts = [0];
  func217.paramNames = [];
  func217.typeParamNames = [];
  func217.definitionLine = 180;
  func217.definitionModule = "string_test";
  setLineNumber(186);    // compilenode member
  // call case 4: self request
  var call225 = selfRequest(this, "test_greaterThan_concat_first", [0]);
  setLineNumber(188);    // compilenode string
  var string226 = new GraceString("test succeeded");
  Grace_print(string226);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_string__95__test = gracecode_string__95__test;
if (typeof window !== "undefined")
  window.gracecode_string__95__test = gracecode_string__95__test;
gracecode_string__95__test.imports = ["StaticTyping"];
