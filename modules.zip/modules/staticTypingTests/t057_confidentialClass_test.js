;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t057_confidentialClass_test"] = "classes:\nconfidential:\n b\ndialect:\n StaticTyping\nfresh-methods:\n a(1)\nfresh:a(1):\n id(1)\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t057_confidentialClass_test.grace\npublic:\n A\n a(1)\npublicMethod:a(1):\n a(m:Number) \u2192 A\npublicMethodTypes:\n a(m:Number) \u2192 A\ntypedec-of:A:\n type A = interface {\n            id(n:Number) \u2192 Number}\ntypes:\n A\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t057_confidentialClass_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "",
    "type A = {",
    "    id(n: Number) → Number",
    "}",
    "",
    "class a(m: Number) → A {",
    "    method id(n: Number) → Number {n + m}",
    "}",
    "def b: A = object  {",
    "    inherit a(3)",
    "}",
    "print(b.id(12))" ];
}
function gracecode_t057__95__confidentialClass__95__test() {
  setModuleName("t057_confidentialClass_test");
  importedModules["t057_confidentialClass_test"] = this;
  var module$t057__95__confidentialClass__95__test = this;
  this.definitionModule = "t057_confidentialClass_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t057__95__confidentialClass__95__test_0");
  this.outer_t057__95__confidentialClass__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv, var_m) {    // method a(_), line 8
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_m, var_Number, "argument to request of `a(_)`", "Number");
    var ouc = emptyGraceObject("a(_)", "t057_confidentialClass_test", 8);
    var ouc_init = this.methods["a(1)$build(3)"].call(this, null, var_m, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(13);    // typecheck
    assertTypeOrMsg(ouc, var_A, "object returned from a(_)", "A");
    return ouc;
  };    // end of method a(_)
  func0.paramTypes = [];
  func0.paramTypes.push([type_Number, "m"]);
  this.methods["a(1)"] = func0;
  func0.paramCounts = [1];
  func0.paramNames = ["m"];
  func0.typeParamNames = [];
  func0.definitionLine = 8;
  func0.definitionModule = "t057_confidentialClass_test";
  var func1 = function(argcv, var_m, inheritingObject, aliases, exclusions) {    // method a(_)$build(_,_,_), line 8
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_m, var_Number, "argument to request of `a(_)`", "Number");
    var obj2_build = function(ignore, var_m, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t057__95__confidentialClass__95__test_8");
      this.outer_t057__95__confidentialClass__95__test_8 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv, var_n) {    // method id(_), line 9
        var returnTarget = invocationCount;
        invocationCount++;
        assertTypeOrMsg(var_n, var_Number, "argument to request of `id(_)`", "Number");
        setModuleName("t057_confidentialClass_test");
        setLineNumber(9);    // compilenode op
        var sum4 = request(var_n, "+(1)", [1], var_m);
        assertTypeOrMsg(sum4, var_Number, "result of method id(_)", "Number");
        return sum4;
      };    // end of method id(_)
      func3.paramTypes = [];
      func3.paramTypes.push([type_Number, "n"]);
      this.methods["id(1)"] = func3;
      func3.paramCounts = [1];
      func3.paramNames = ["n"];
      func3.typeParamNames = [];
      func3.definitionLine = 9;
      func3.definitionModule = "t057_confidentialClass_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 8
        setModuleName("t057_confidentialClass_test");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, var_m, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method a(_)$build(_,_,_)
  func1.paramTypes = [];
  func1.paramTypes.push([type_Number, "m"]);
  this.methods["a(1)$build(3)"] = func1;
  func1.paramCounts = [1];
  func1.paramNames = ["m"];
  func1.typeParamNames = [];
  func1.definitionLine = 8;
  func1.definitionModule = "t057_confidentialClass_test";
  setLineNumber(4);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit6 = new GraceType("A");
  typeLit6.typeMethods.push("id(1)");
  var var_A = typeLit6;
  var type5 = typeLit6;
  var func7 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func7;
  func7.paramCounts = [0];
  func7.paramNames = [];
  func7.typeParamNames = [];
  func7.definitionLine = 1;
  func7.definitionModule = "t057_confidentialClass_test";
  setLineNumber(11);    // compilenode object
  var obj8_build = function(ignore, outerObj, aliases, exclusions) {
    this.closureKeys = this.closureKeys || [];
    this.closureKeys.push("outer_t057__95__confidentialClass__95__test_11");
    this.outer_t057__95__confidentialClass__95__test_11 = outerObj;
    var inheritedExclusions = { };
    for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
        var exMeth = exclusions[eix];
        inheritedExclusions[exMeth] = this.methods[exMeth];
    }
    setLineNumber(12);    // compilenode num
    var initFun9 = selfRequest(importedModules["t057_confidentialClass_test"], "a(1)$build(3)", [null], new GraceNum(3), this, [], []);  // compileReuseCall
    for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
        var oneAlias = aliases[aix];
        this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
    }
    for (var exName in inheritedExclusions) {
        if (inheritedExclusions.hasOwnProperty(exName)) {
            if (inheritedExclusions[exName]) {
                this.methods[exName] = inheritedExclusions[exName];
            } else {
                delete this.methods[exName];
            }
        }
    }
    var obj8_init = function() {    // init of object on line 11
      initFun9.call(this);
      setModuleName("t057_confidentialClass_test");
    };
    return obj8_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
  };
  var obj8 = emptyGraceObject("b", "t057_confidentialClass_test", 11);
  var obj8_init = obj8_build.call(obj8, null, this, [], []);
  obj8_init.call(obj8);  // end of compileobject
  var var_b = obj8;
  var reader10_b = function() {  // reader method b
      if (var_b === undefined) raiseUninitializedVariable("b");
      return var_b;
  };
  reader10_b.isDef = true;
  reader10_b.confidential = true;
  this.methods["b"] = reader10_b;
  setLineNumber(11);    // typecheck
  assertTypeOrMsg(var_b, var_A, "value of def b", "A");
  setLineNumber(14);    // compilenode num
  // call case 6: other requests
  if (var_b === undefined) raiseUninitializedVariable("b");
  var call11 = request(var_b, "id(1)", [1], new GraceNum(12));
  Grace_print(call11);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t057__95__confidentialClass__95__test = gracecode_t057__95__confidentialClass__95__test;
if (typeof window !== "undefined")
  window.gracecode_t057__95__confidentialClass__95__test = gracecode_t057__95__confidentialClass__95__test;
gracecode_t057__95__confidentialClass__95__test.imports = ["StaticTyping"];
