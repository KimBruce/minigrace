;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t303_SelfReferentialSubtype_test"] = "classes:\nconfidential:\n test\ndialect:\n StaticTyping\nfresh-methods:\n bar\nfresh:bar:\n a\n b\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t303_SelfReferentialSubtype_test.grace\npublic:\n Bar\n Foo\n bar\npublicMethod:bar:\n bar \u2192 Bar\npublicMethodTypes:\n bar \u2192 Bar\ntypedec-of:Bar:\n type Bar = interface {\n            a \u2192 Bar\n            b \u2192 Number}\ntypedec-of:Foo:\n type Foo = interface {\n            a \u2192 Foo}\ntypes:\n Bar\n Foo\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t303_SelfReferentialSubtype_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "type Foo = { a -> Foo}",
    "type Bar = {",
    "    a -> Bar",
    "    b -> Number",
    "}",
    "",
    "class bar -> Bar {",
    "    method a -> Bar {self}",
    "    method b -> Number {0}",
    "}",
    "",
    "def test : Foo = bar",
    "",
    "print \"test succeeded\"" ];
}
function gracecode_t303__95__SelfReferentialSubtype__95__test() {
  setModuleName("t303_SelfReferentialSubtype_test");
  importedModules["t303_SelfReferentialSubtype_test"] = this;
  var module$t303__95__SelfReferentialSubtype__95__test = this;
  this.definitionModule = "t303_SelfReferentialSubtype_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t303__95__SelfReferentialSubtype__95__test_0");
  this.outer_t303__95__SelfReferentialSubtype__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method bar, line 9
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("bar", "t303_SelfReferentialSubtype_test", 9);
    var ouc_init = this.methods["bar$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_Bar, "object returned from bar", "Bar");
    return ouc;
  };    // end of method bar
  this.methods["bar"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 9;
  func0.definitionModule = "t303_SelfReferentialSubtype_test";
  var func1 = function(argcv, inheritingObject, aliases, exclusions) {    // method bar$build(_,_,_), line 9
    var returnTarget = invocationCount;
    invocationCount++;
    var obj2_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t303__95__SelfReferentialSubtype__95__test_9");
      this.outer_t303__95__SelfReferentialSubtype__95__test_9 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv) {     // accessor method a
        return this;
      };    // end of method a
      this.methods["a"] = func3;
      func3.paramCounts = [0];
      func3.paramNames = [];
      func3.typeParamNames = [];
      func3.definitionLine = 10;
      func3.definitionModule = "t303_SelfReferentialSubtype_test";
      var func4 = function(argcv) {    // method b, line 11
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t303_SelfReferentialSubtype_test");
        setLineNumber(11);    // typecheck
        assertTypeOrMsg(new GraceNum(0), var_Number, "result of method b", "Number");
        return new GraceNum(0);
      };    // end of method b
      this.methods["b"] = func4;
      func4.paramCounts = [0];
      func4.paramNames = [];
      func4.typeParamNames = [];
      func4.definitionLine = 11;
      func4.definitionModule = "t303_SelfReferentialSubtype_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 9
        setModuleName("t303_SelfReferentialSubtype_test");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method bar$build(_,_,_)
  this.methods["bar$build(3)"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 9;
  func1.definitionModule = "t303_SelfReferentialSubtype_test";
  setLineNumber(3);    // compilenode typedec
  // Type decl Foo
  //   Type literal 
  var typeLit6 = new GraceType("Foo");
  typeLit6.typeMethods.push("a");
  var var_Foo = typeLit6;
  var type5 = typeLit6;
  var func7 = function(argcv) {     // accessor method Foo
    return var_Foo;
  };    // end of method Foo
  this.methods["Foo"] = func7;
  func7.paramCounts = [0];
  func7.paramNames = [];
  func7.typeParamNames = [];
  func7.definitionLine = 1;
  func7.definitionModule = "t303_SelfReferentialSubtype_test";
  setLineNumber(4);    // compilenode typedec
  // Type decl Bar
  //   Type literal 
  var typeLit9 = new GraceType("Bar");
  typeLit9.typeMethods.push("a");
  typeLit9.typeMethods.push("b");
  var var_Bar = typeLit9;
  var type8 = typeLit9;
  var func10 = function(argcv) {     // accessor method Bar
    return var_Bar;
  };    // end of method Bar
  this.methods["Bar"] = func10;
  func10.paramCounts = [0];
  func10.paramNames = [];
  func10.typeParamNames = [];
  func10.definitionLine = 1;
  func10.definitionModule = "t303_SelfReferentialSubtype_test";
  setLineNumber(14);    // compilenode member
  // call case 4: self request
  var call11 = selfRequest(this, "bar", [0]);
  var var_test = call11;
  var reader12_test = function() {  // reader method test
      if (var_test === undefined) raiseUninitializedVariable("test");
      return var_test;
  };
  reader12_test.isDef = true;
  reader12_test.confidential = true;
  this.methods["test"] = reader12_test;
  assertTypeOrMsg(var_test, var_Foo, "value of def test", "Foo");
  setLineNumber(16);    // compilenode string
  var string13 = new GraceString("test succeeded");
  Grace_print(string13);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t303__95__SelfReferentialSubtype__95__test = gracecode_t303__95__SelfReferentialSubtype__95__test;
if (typeof window !== "undefined")
  window.gracecode_t303__95__SelfReferentialSubtype__95__test = gracecode_t303__95__SelfReferentialSubtype__95__test;
gracecode_t303__95__SelfReferentialSubtype__95__test.imports = ["StaticTyping"];
