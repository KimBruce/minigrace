;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t308_complicatedImportee_test"] = "classes:\nconfidential:\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t308_complicatedImportee_test.grace\npublic:\n A\n B\n C\n ComplicatedType\n D\npublicMethodTypes:\ntypedec-of:A:\n type A = interface {\n            m \u2192 Number}\ntypedec-of:B:\n type B = interface {\n            p \u2192 String}\ntypedec-of:C:\n type C = interface {\n            n \u2192 Boolean}\ntypedec-of:ComplicatedType:\n type ComplicatedType = (A & (C | B)) | D\ntypedec-of:D:\n type D = A & B\ntypes:\n A\n B\n C\n ComplicatedType\n D\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t308_complicatedImportee_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "type A = {",
    "    m -> Number",
    "}",
    "",
    "type B = {",
    "    p -> String",
    "}",
    "",
    "type C = {",
    "    n->Boolean",
    "}",
    "",
    "",
    "type D = A & B",
    "",
    "type ComplicatedType = (A  & (C | B)) |  D" ];
}
function gracecode_t308__95__complicatedImportee__95__test() {
  setModuleName("t308_complicatedImportee_test");
  importedModules["t308_complicatedImportee_test"] = this;
  var module$t308__95__complicatedImportee__95__test = this;
  this.definitionModule = "t308_complicatedImportee_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t308__95__complicatedImportee__95__test_0");
  this.outer_t308__95__complicatedImportee__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(3);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit1 = new GraceType("A");
  typeLit1.typeMethods.push("m");
  var var_A = typeLit1;
  var type0 = typeLit1;
  var func2 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 1;
  func2.definitionModule = "t308_complicatedImportee_test";
  setLineNumber(7);    // compilenode typedec
  // Type decl B
  //   Type literal 
  var typeLit4 = new GraceType("B");
  typeLit4.typeMethods.push("p");
  var var_B = typeLit4;
  var type3 = typeLit4;
  var func5 = function(argcv) {     // accessor method B
    return var_B;
  };    // end of method B
  this.methods["B"] = func5;
  func5.paramCounts = [0];
  func5.paramNames = [];
  func5.typeParamNames = [];
  func5.definitionLine = 1;
  func5.definitionModule = "t308_complicatedImportee_test";
  setLineNumber(11);    // compilenode typedec
  // Type decl C
  //   Type literal 
  var typeLit7 = new GraceType("C");
  typeLit7.typeMethods.push("n");
  var var_C = typeLit7;
  var type6 = typeLit7;
  var func8 = function(argcv) {     // accessor method C
    return var_C;
  };    // end of method C
  this.methods["C"] = func8;
  func8.paramCounts = [0];
  func8.paramNames = [];
  func8.typeParamNames = [];
  func8.definitionLine = 1;
  func8.definitionModule = "t308_complicatedImportee_test";
  setLineNumber(16);    // compilenode typedec
  // Type decl D
  var opresult10 = request(var_A, "&(1)", [1], var_B);
  var var_D = opresult10;
  var type9 = opresult10;
  var func11 = function(argcv) {     // accessor method D
    return var_D;
  };    // end of method D
  this.methods["D"] = func11;
  func11.paramCounts = [0];
  func11.paramNames = [];
  func11.typeParamNames = [];
  func11.definitionLine = 1;
  func11.definitionModule = "t308_complicatedImportee_test";
  setLineNumber(18);    // compilenode typedec
  // Type decl ComplicatedType
  var opresult13 = request(var_C, "|(1)", [1], var_B);
  var opresult14 = request(var_A, "&(1)", [1], opresult13);
  var opresult15 = request(opresult14, "|(1)", [1], var_D);
  var var_ComplicatedType = opresult15;
  var type12 = opresult15;
  var func16 = function(argcv) {     // accessor method ComplicatedType
    return var_ComplicatedType;
  };    // end of method ComplicatedType
  this.methods["ComplicatedType"] = func16;
  func16.paramCounts = [0];
  func16.paramNames = [];
  func16.typeParamNames = [];
  func16.definitionLine = 1;
  func16.definitionModule = "t308_complicatedImportee_test";
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t308__95__complicatedImportee__95__test = gracecode_t308__95__complicatedImportee__95__test;
if (typeof window !== "undefined")
  window.gracecode_t308__95__complicatedImportee__95__test = gracecode_t308__95__complicatedImportee__95__test;
gracecode_t308__95__complicatedImportee__95__test.imports = ["StaticTyping"];
