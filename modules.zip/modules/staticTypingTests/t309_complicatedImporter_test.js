;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t309_complicatedImporter_test"] = "classes:\nconfidential:\n im\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n t308_complicatedImportee_test\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t309_complicatedImporter_test.grace\npublic:\n Test\n Test2\n im.A\n im.B\n im.C\n im.ComplicatedType\n im.D\npublicMethodTypes:\ntypedec-of:Test:\n type Test = im.ComplicatedType\ntypedec-of:Test2:\n type Test2 = im.ComplicatedType | Number | im.A\ntypedec-of:im.A:\n type A = interface {\n            m \u2192 Number}\ntypedec-of:im.B:\n type B = interface {\n            p \u2192 String}\ntypedec-of:im.C:\n type C = interface {\n            n \u2192 Boolean}\ntypedec-of:im.ComplicatedType:\n type ComplicatedType = (A & (C | B)) | D\ntypedec-of:im.D:\n type D = A & B\ntypes:\n Test\n Test2\n im.A\n im.B\n im.C\n im.ComplicatedType\n im.D\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t309_complicatedImporter_test"] = [
    "dialect \"StaticTyping\"",
    "import \"t308_complicatedImportee_test\" as im",
    "",
    "type Test = im.ComplicatedType",
    "type Test2 = im.ComplicatedType | Number | im.A",
    "print \"test succeeded\"" ];
}
function gracecode_t309__95__complicatedImporter__95__test() {
  setModuleName("t309_complicatedImporter_test");
  importedModules["t309_complicatedImporter_test"] = this;
  var module$t309__95__complicatedImporter__95__test = this;
  this.definitionModule = "t309_complicatedImporter_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t309__95__complicatedImporter__95__test_0");
  this.outer_t309__95__complicatedImporter__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(2);    // compilenode import
  // Import of "t308_complicatedImportee_test" as im
  if (typeof gracecode_t308__95__complicatedImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module t308_complicatedImportee_test"));
  var var_im = do_import("t308_complicatedImportee_test", gracecode_t308__95__complicatedImportee__95__test);
  var func0 = function(argcv) {     // accessor method im
    if (var_im === undefined) raiseUninitializedVariable("im");
    return var_im;
  };    // end of method im
  this.methods["im"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 2;
  func0.definitionModule = "t309_complicatedImporter_test";
  func0.debug = "import";
  func0.confidential = true;
  setModuleName("t309_complicatedImporter_test");
  setLineNumber(4);    // compilenode typedec
  // Type decl Test
  // call case 6: other requests
  var call2 = request(var_im, "ComplicatedType", [0]);
  var var_Test = call2;
  var type1 = call2;
  var func3 = function(argcv) {     // accessor method Test
    return var_Test;
  };    // end of method Test
  this.methods["Test"] = func3;
  func3.paramCounts = [0];
  func3.paramNames = [];
  func3.typeParamNames = [];
  func3.definitionLine = 1;
  func3.definitionModule = "t309_complicatedImporter_test";
  setLineNumber(5);    // compilenode typedec
  // Type decl Test2
  // call case 6: other requests
  var call5 = request(var_im, "ComplicatedType", [0]);
  var opresult6 = request(call5, "|(1)", [1], var_Number);
  // call case 6: other requests
  var call7 = request(var_im, "A", [0]);
  var opresult8 = request(opresult6, "|(1)", [1], call7);
  var var_Test2 = opresult8;
  var type4 = opresult8;
  var func9 = function(argcv) {     // accessor method Test2
    return var_Test2;
  };    // end of method Test2
  this.methods["Test2"] = func9;
  func9.paramCounts = [0];
  func9.paramNames = [];
  func9.typeParamNames = [];
  func9.definitionLine = 1;
  func9.definitionModule = "t309_complicatedImporter_test";
  setLineNumber(6);    // compilenode string
  var string10 = new GraceString("test succeeded");
  Grace_print(string10);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t309__95__complicatedImporter__95__test = gracecode_t309__95__complicatedImporter__95__test;
if (typeof window !== "undefined")
  window.gracecode_t309__95__complicatedImporter__95__test = gracecode_t309__95__complicatedImporter__95__test;
gracecode_t309__95__complicatedImporter__95__test.imports = ["StaticTyping", "t308_complicatedImportee_test"];
