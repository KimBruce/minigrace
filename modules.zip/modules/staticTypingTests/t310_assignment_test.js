;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t310_assignment_test"] = "classes:\nconfidential:\n x\n x:=(x': Number) \u2192 Done\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t310_assignment_test.grace\npublic:\npublicMethodTypes:\ntypes:\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t310_assignment_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "var x: Number := 0",
    "x := x + 1",
    "print(x)" ];
}
function gracecode_t310__95__assignment__95__test() {
  setModuleName("t310_assignment_test");
  importedModules["t310_assignment_test"] = this;
  var module$t310__95__assignment__95__test = this;
  this.definitionModule = "t310_assignment_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t310__95__assignment__95__test_0");
  this.outer_t310__95__assignment__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(3);    // typecheck
  assertTypeOrMsg(new GraceNum(0), var_Number, "initial value of var x", "Number");
  var var_x = new GraceNum(0);
  var reader0_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader0_x.isVar = true;
  reader0_x.confidential = true;
  this.methods["x"] = reader0_x;
  var writer1_x = function(argcv, n) {   // writer method x:=(_)
    assertTypeOrMsg(n, var_Number, "argument to x:=(_)", "Number");
    var_x = n;
    return GraceDone;
  };
  writer1_x.confidential = true;
  this.methods["x:=(1)"] = writer1_x;
  setLineNumber(4);    // compilenode num
  var sum2 = request(var_x, "+(1)", [1], new GraceNum(1));
  var_x = sum2;
  setLineNumber(5);    // compilenode call
  Grace_print(var_x);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t310__95__assignment__95__test = gracecode_t310__95__assignment__95__test;
if (typeof window !== "undefined")
  window.gracecode_t310__95__assignment__95__test = gracecode_t310__95__assignment__95__test;
gracecode_t310__95__assignment__95__test.imports = ["StaticTyping"];
