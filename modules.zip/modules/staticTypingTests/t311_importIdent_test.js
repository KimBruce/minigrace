;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t311_importIdent_test"] = "classes:\nconfidential:\n im\n x\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identImportee_test\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t311_importIdent_test.grace\npublic:\n im.T\n im.U\npublicMethodTypes:\ntypedec-of:im.T:\n type T = Number\ntypedec-of:im.U:\n type U = T\ntypes:\n im.T\n im.U\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t311_importIdent_test"] = [
    "dialect \"StaticTyping\"",
    "import \"identImportee_test\" as im",
    "def x : im.U = 47",
    "print (x)" ];
}
function gracecode_t311__95__importIdent__95__test() {
  setModuleName("t311_importIdent_test");
  importedModules["t311_importIdent_test"] = this;
  var module$t311__95__importIdent__95__test = this;
  this.definitionModule = "t311_importIdent_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t311__95__importIdent__95__test_0");
  this.outer_t311__95__importIdent__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(2);    // compilenode import
  // Import of "identImportee_test" as im
  if (typeof gracecode_identImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module identImportee_test"));
  var var_im = do_import("identImportee_test", gracecode_identImportee__95__test);
  var func0 = function(argcv) {     // accessor method im
    if (var_im === undefined) raiseUninitializedVariable("im");
    return var_im;
  };    // end of method im
  this.methods["im"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 2;
  func0.definitionModule = "t311_importIdent_test";
  func0.debug = "import";
  func0.confidential = true;
  setModuleName("t311_importIdent_test");
  setLineNumber(3);    // compilenode num
  var var_x = new GraceNum(47);
  var reader1_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader1_x.isDef = true;
  reader1_x.confidential = true;
  this.methods["x"] = reader1_x;
  // call case 6: other requests
  var call2 = request(var_im, "U", [0]);
  assertTypeOrMsg(var_x, call2, "value of def x", "im.U");
  setLineNumber(4);    // compilenode call
  if (var_x === undefined) raiseUninitializedVariable("x");
  Grace_print(var_x);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t311__95__importIdent__95__test = gracecode_t311__95__importIdent__95__test;
if (typeof window !== "undefined")
  window.gracecode_t311__95__importIdent__95__test = gracecode_t311__95__importIdent__95__test;
gracecode_t311__95__importIdent__95__test.imports = ["StaticTyping", "identImportee_test"];
