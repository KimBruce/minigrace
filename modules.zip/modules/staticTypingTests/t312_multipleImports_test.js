;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t312_multipleImports_test"] = "classes:\nconfidential:\n im1\n im2\n im3\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identImportee_test\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n t308_complicatedImportee_test\n t335A_basicImportee_test\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t312_multipleImports_test.grace\npublic:\n MyType\n im1.T\n im1.U\n im2.AmpersandType\n im2.FirstHalf\n im2.MyType\n im2.NumberCopy\n im2.SecondHalf\n im2.VariantType\n im3.A\n im3.B\n im3.C\n im3.ComplicatedType\n im3.D\npublicMethodTypes:\ntypedec-of:MyType:\n type MyType = im2.MyType & (im1.U | im3.A)\ntypedec-of:im1.T:\n type T = Number\ntypedec-of:im1.U:\n type U = T\ntypedec-of:im2.AmpersandType:\n type AmpersandType = FirstHalf & SecondHalf\ntypedec-of:im2.FirstHalf:\n type FirstHalf = interface {\n            firstMeth \u2192 Number}\ntypedec-of:im2.MyType:\n type MyType = interface {\n            a \u2192 Number}\ntypedec-of:im2.NumberCopy:\n type NumberCopy = Number\ntypedec-of:im2.SecondHalf:\n type SecondHalf = interface {\n            secondMeth \u2192 Number}\ntypedec-of:im2.VariantType:\n type VariantType = FirstHalf | SecondHalf\ntypedec-of:im3.A:\n type A = interface {\n            m \u2192 Number}\ntypedec-of:im3.B:\n type B = interface {\n            p \u2192 String}\ntypedec-of:im3.C:\n type C = interface {\n            n \u2192 Boolean}\ntypedec-of:im3.ComplicatedType:\n type ComplicatedType = (A & (C | B)) | D\ntypedec-of:im3.D:\n type D = A & B\ntypes:\n MyType\n im1.T\n im1.U\n im2.AmpersandType\n im2.FirstHalf\n im2.MyType\n im2.NumberCopy\n im2.SecondHalf\n im2.VariantType\n im3.A\n im3.B\n im3.C\n im3.ComplicatedType\n im3.D\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t312_multipleImports_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "import \"identImportee_test\" as im1",
    "import \"t335A_basicImportee_test\" as im2",
    "import \"t308_complicatedImportee_test\" as im3",
    "",
    "type MyType = im2.MyType & (im1.U | im3.A)",
    "print \"test succeeded\"" ];
}
function gracecode_t312__95__multipleImports__95__test() {
  setModuleName("t312_multipleImports_test");
  importedModules["t312_multipleImports_test"] = this;
  var module$t312__95__multipleImports__95__test = this;
  this.definitionModule = "t312_multipleImports_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t312__95__multipleImports__95__test_0");
  this.outer_t312__95__multipleImports__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(3);    // compilenode import
  // Import of "identImportee_test" as im1
  if (typeof gracecode_identImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module identImportee_test"));
  var var_im1 = do_import("identImportee_test", gracecode_identImportee__95__test);
  var func0 = function(argcv) {     // accessor method im1
    if (var_im1 === undefined) raiseUninitializedVariable("im1");
    return var_im1;
  };    // end of method im1
  this.methods["im1"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 3;
  func0.definitionModule = "t312_multipleImports_test";
  func0.debug = "import";
  func0.confidential = true;
  setModuleName("t312_multipleImports_test");
  setLineNumber(4);    // compilenode import
  // Import of "t335A_basicImportee_test" as im2
  if (typeof gracecode_t335A__95__basicImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module t335A_basicImportee_test"));
  var var_im2 = do_import("t335A_basicImportee_test", gracecode_t335A__95__basicImportee__95__test);
  var func1 = function(argcv) {     // accessor method im2
    if (var_im2 === undefined) raiseUninitializedVariable("im2");
    return var_im2;
  };    // end of method im2
  this.methods["im2"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 4;
  func1.definitionModule = "t312_multipleImports_test";
  func1.debug = "import";
  func1.confidential = true;
  setModuleName("t312_multipleImports_test");
  setLineNumber(5);    // compilenode import
  // Import of "t308_complicatedImportee_test" as im3
  if (typeof gracecode_t308__95__complicatedImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module t308_complicatedImportee_test"));
  var var_im3 = do_import("t308_complicatedImportee_test", gracecode_t308__95__complicatedImportee__95__test);
  var func2 = function(argcv) {     // accessor method im3
    if (var_im3 === undefined) raiseUninitializedVariable("im3");
    return var_im3;
  };    // end of method im3
  this.methods["im3"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 5;
  func2.definitionModule = "t312_multipleImports_test";
  func2.debug = "import";
  func2.confidential = true;
  setModuleName("t312_multipleImports_test");
  setLineNumber(7);    // compilenode typedec
  // Type decl MyType
  // call case 6: other requests
  var call4 = request(var_im2, "MyType", [0]);
  // call case 6: other requests
  var call5 = request(var_im1, "U", [0]);
  // call case 6: other requests
  var call6 = request(var_im3, "A", [0]);
  var opresult7 = request(call5, "|(1)", [1], call6);
  var opresult8 = request(call4, "&(1)", [1], opresult7);
  var var_MyType = opresult8;
  var type3 = opresult8;
  var func9 = function(argcv) {     // accessor method MyType
    return var_MyType;
  };    // end of method MyType
  this.methods["MyType"] = func9;
  func9.paramCounts = [0];
  func9.paramNames = [];
  func9.typeParamNames = [];
  func9.definitionLine = 1;
  func9.definitionModule = "t312_multipleImports_test";
  setLineNumber(8);    // compilenode string
  var string10 = new GraceString("test succeeded");
  Grace_print(string10);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t312__95__multipleImports__95__test = gracecode_t312__95__multipleImports__95__test;
if (typeof window !== "undefined")
  window.gracecode_t312__95__multipleImports__95__test = gracecode_t312__95__multipleImports__95__test;
gracecode_t312__95__multipleImports__95__test.imports = ["StaticTyping", "identImportee_test", "t308_complicatedImportee_test", "t335A_basicImportee_test"];
