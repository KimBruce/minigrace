;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t313_chainImportee_test"] = "classes:\nconfidential:\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n t308_complicatedImportee_test\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t313_chainImportee_test.grace\npublic:\n AB\n im\n im.A\n im.B\n im.C\n im.ComplicatedType\n im.D\npublicMethodTypes:\n im \u2192 im\ntypedec-of:$im:\n type im = {\n }\ntypedec-of:AB:\n type AB = im.A & im.B\ntypedec-of:im.A:\n type A = interface {\n            m \u2192 Number}\ntypedec-of:im.B:\n type B = interface {\n            p \u2192 String}\ntypedec-of:im.C:\n type C = interface {\n            n \u2192 Boolean}\ntypedec-of:im.ComplicatedType:\n type ComplicatedType = (A & (C | B)) | D\ntypedec-of:im.D:\n type D = A & B\ntypes:\n AB\n im\n im.A\n im.B\n im.C\n im.ComplicatedType\n im.D\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t313_chainImportee_test"] = [
    "dialect \"StaticTyping\"",
    "import \"t308_complicatedImportee_test\" as im is public",
    "",
    "type AB = im.A & im.B" ];
}
function gracecode_t313__95__chainImportee__95__test() {
  setModuleName("t313_chainImportee_test");
  importedModules["t313_chainImportee_test"] = this;
  var module$t313__95__chainImportee__95__test = this;
  this.definitionModule = "t313_chainImportee_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t313__95__chainImportee__95__test_0");
  this.outer_t313__95__chainImportee__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(2);    // compilenode import
  // Import of "t308_complicatedImportee_test" as im
  if (typeof gracecode_t308__95__complicatedImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module t308_complicatedImportee_test"));
  var var_im = do_import("t308_complicatedImportee_test", gracecode_t308__95__complicatedImportee__95__test);
  var func0 = function(argcv) {     // accessor method im
    if (var_im === undefined) raiseUninitializedVariable("im");
    return var_im;
  };    // end of method im
  this.methods["im"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 2;
  func0.definitionModule = "t313_chainImportee_test";
  func0.debug = "import";
  setModuleName("t313_chainImportee_test");
  setLineNumber(4);    // compilenode typedec
  // Type decl AB
  // call case 6: other requests
  var call2 = request(var_im, "A", [0]);
  // call case 6: other requests
  var call3 = request(var_im, "B", [0]);
  var opresult4 = request(call2, "&(1)", [1], call3);
  var var_AB = opresult4;
  var type1 = opresult4;
  var func5 = function(argcv) {     // accessor method AB
    return var_AB;
  };    // end of method AB
  this.methods["AB"] = func5;
  func5.paramCounts = [0];
  func5.paramNames = [];
  func5.typeParamNames = [];
  func5.definitionLine = 1;
  func5.definitionModule = "t313_chainImportee_test";
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t313__95__chainImportee__95__test = gracecode_t313__95__chainImportee__95__test;
if (typeof window !== "undefined")
  window.gracecode_t313__95__chainImportee__95__test = gracecode_t313__95__chainImportee__95__test;
gracecode_t313__95__chainImportee__95__test.imports = ["StaticTyping", "t308_complicatedImportee_test"];
