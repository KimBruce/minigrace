;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t314_chainImporter_test"] = "classes:\nconfidential:\n im1\n im2\n x\n y\ndialect:\n StaticTyping\nfresh-methods:\n t\n u\nfresh:t:\n m\n p\nfresh:u:\n m\n p\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n t308_complicatedImportee_test\n t313_chainImportee_test\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t314_chainImporter_test.grace\npublic:\n T\n U\n im1.A\n im1.B\n im1.C\n im1.ComplicatedType\n im1.D\n im2.$im\n im2.AB\n im2.im.A\n im2.im.B\n im2.im.C\n im2.im.ComplicatedType\n im2.im.D\n t\n u\npublicMethod:t:\n t \u2192 T\npublicMethod:u:\n u \u2192 U\npublicMethodTypes:\n t \u2192 T\n u \u2192 U\ntypedec-of:T:\n type T = im1.A & im1.B\ntypedec-of:U:\n type U = im2.AB\ntypedec-of:im1.A:\n type A = interface {\n            m \u2192 Number}\ntypedec-of:im1.B:\n type B = interface {\n            p \u2192 String}\ntypedec-of:im1.C:\n type C = interface {\n            n \u2192 Boolean}\ntypedec-of:im1.ComplicatedType:\n type ComplicatedType = (A & (C | B)) | D\ntypedec-of:im1.D:\n type D = A & B\ntypedec-of:im2.$im:\n type im = {\n }\ntypedec-of:im2.AB:\n type AB = im.A & im.B\ntypedec-of:im2.im.A:\n type A = interface {\n            m \u2192 Number}\ntypedec-of:im2.im.B:\n type B = interface {\n            p \u2192 String}\ntypedec-of:im2.im.C:\n type C = interface {\n            n \u2192 Boolean}\ntypedec-of:im2.im.ComplicatedType:\n type ComplicatedType = (A & (C | B)) | D\ntypedec-of:im2.im.D:\n type D = A & B\ntypes:\n T\n U\n im1.A\n im1.B\n im1.C\n im1.ComplicatedType\n im1.D\n im2.$im\n im2.AB\n im2.im.A\n im2.im.B\n im2.im.C\n im2.im.ComplicatedType\n im2.im.D\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t314_chainImporter_test"] = [
    "dialect \"StaticTyping\"",
    "import \"t308_complicatedImportee_test\" as im1",
    "import \"t313_chainImportee_test\" as im2",
    "//im2 imports im1, so we can test whether chained imports are passed correctly",
    "",
    "//These 2 types should be equivalent",
    "type T = im1.A & im1.B",
    "type U = im2.AB",
    "",
    "class t -> T {",
    "    method m -> Number { 47 }",
    "    method p -> String { \"Hello\" }",
    "}",
    "class u -> U {",
    "    method m -> Number { 48 }",
    "    method p -> String { \"World\" }",
    "}",
    "",
    "//If both of these defdecs pass type-checking, then T is a subtype of U and",
    "//U is a subtype of T, so they are equal and imports pass their types correctly.",
    "def x : U = t",
    "def y : T = u",
    "print (\"{x.p} {y.p}\")" ];
}
function gracecode_t314__95__chainImporter__95__test() {
  setModuleName("t314_chainImporter_test");
  importedModules["t314_chainImporter_test"] = this;
  var module$t314__95__chainImporter__95__test = this;
  this.definitionModule = "t314_chainImporter_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t314__95__chainImporter__95__test_0");
  this.outer_t314__95__chainImporter__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(2);    // compilenode import
  // Import of "t308_complicatedImportee_test" as im1
  if (typeof gracecode_t308__95__complicatedImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module t308_complicatedImportee_test"));
  var var_im1 = do_import("t308_complicatedImportee_test", gracecode_t308__95__complicatedImportee__95__test);
  var func0 = function(argcv) {     // accessor method im1
    if (var_im1 === undefined) raiseUninitializedVariable("im1");
    return var_im1;
  };    // end of method im1
  this.methods["im1"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 2;
  func0.definitionModule = "t314_chainImporter_test";
  func0.debug = "import";
  func0.confidential = true;
  setModuleName("t314_chainImporter_test");
  setLineNumber(3);    // compilenode import
  // Import of "t313_chainImportee_test" as im2
  if (typeof gracecode_t313__95__chainImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module t313_chainImportee_test"));
  var var_im2 = do_import("t313_chainImportee_test", gracecode_t313__95__chainImportee__95__test);
  var func1 = function(argcv) {     // accessor method im2
    if (var_im2 === undefined) raiseUninitializedVariable("im2");
    return var_im2;
  };    // end of method im2
  this.methods["im2"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 3;
  func1.definitionModule = "t314_chainImporter_test";
  func1.debug = "import";
  func1.confidential = true;
  setModuleName("t314_chainImporter_test");
  var func2 = function(argcv) {    // method t, line 10
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("t", "t314_chainImporter_test", 10);
    var ouc_init = this.methods["t$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(15);    // typecheck
    assertTypeOrMsg(ouc, var_T, "object returned from t", "T");
    return ouc;
  };    // end of method t
  this.methods["t"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 10;
  func2.definitionModule = "t314_chainImporter_test";
  var func3 = function(argcv, inheritingObject, aliases, exclusions) {    // method t$build(_,_,_), line 10
    var returnTarget = invocationCount;
    invocationCount++;
    var obj4_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t314__95__chainImporter__95__test_10");
      this.outer_t314__95__chainImporter__95__test_10 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func5 = function(argcv) {    // method m, line 11
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t314_chainImporter_test");
        setLineNumber(11);    // typecheck
        assertTypeOrMsg(new GraceNum(47), var_Number, "result of method m", "Number");
        return new GraceNum(47);
      };    // end of method m
      this.methods["m"] = func5;
      func5.paramCounts = [0];
      func5.paramNames = [];
      func5.typeParamNames = [];
      func5.definitionLine = 11;
      func5.definitionModule = "t314_chainImporter_test";
      var func6 = function(argcv) {    // method p, line 12
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t314_chainImporter_test");
        setLineNumber(12);    // compilenode string
        var string7 = new GraceString("Hello");
        assertTypeOrMsg(string7, var_String, "result of method p", "String");
        return string7;
      };    // end of method p
      this.methods["p"] = func6;
      func6.paramCounts = [0];
      func6.paramNames = [];
      func6.typeParamNames = [];
      func6.definitionLine = 12;
      func6.definitionModule = "t314_chainImporter_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj4_init = function() {    // init of object on line 10
        setModuleName("t314_chainImporter_test");
      };
      return obj4_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj4_init = obj4_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj4_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method t$build(_,_,_)
  this.methods["t$build(3)"] = func3;
  func3.paramCounts = [0];
  func3.paramNames = [];
  func3.typeParamNames = [];
  func3.definitionLine = 10;
  func3.definitionModule = "t314_chainImporter_test";
  var func8 = function(argcv) {    // method u, line 14
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("u", "t314_chainImporter_test", 14);
    var ouc_init = this.methods["u$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(23);    // typecheck
    assertTypeOrMsg(ouc, var_U, "object returned from u", "U");
    return ouc;
  };    // end of method u
  this.methods["u"] = func8;
  func8.paramCounts = [0];
  func8.paramNames = [];
  func8.typeParamNames = [];
  func8.definitionLine = 14;
  func8.definitionModule = "t314_chainImporter_test";
  var func9 = function(argcv, inheritingObject, aliases, exclusions) {    // method u$build(_,_,_), line 14
    var returnTarget = invocationCount;
    invocationCount++;
    var obj10_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t314__95__chainImporter__95__test_14");
      this.outer_t314__95__chainImporter__95__test_14 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func11 = function(argcv) {    // method m, line 15
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t314_chainImporter_test");
        setLineNumber(15);    // typecheck
        assertTypeOrMsg(new GraceNum(48), var_Number, "result of method m", "Number");
        return new GraceNum(48);
      };    // end of method m
      this.methods["m"] = func11;
      func11.paramCounts = [0];
      func11.paramNames = [];
      func11.typeParamNames = [];
      func11.definitionLine = 15;
      func11.definitionModule = "t314_chainImporter_test";
      var func12 = function(argcv) {    // method p, line 16
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t314_chainImporter_test");
        setLineNumber(16);    // compilenode string
        var string13 = new GraceString("World");
        assertTypeOrMsg(string13, var_String, "result of method p", "String");
        return string13;
      };    // end of method p
      this.methods["p"] = func12;
      func12.paramCounts = [0];
      func12.paramNames = [];
      func12.typeParamNames = [];
      func12.definitionLine = 16;
      func12.definitionModule = "t314_chainImporter_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj10_init = function() {    // init of object on line 14
        setModuleName("t314_chainImporter_test");
      };
      return obj10_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj10_init = obj10_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj10_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method u$build(_,_,_)
  this.methods["u$build(3)"] = func9;
  func9.paramCounts = [0];
  func9.paramNames = [];
  func9.typeParamNames = [];
  func9.definitionLine = 14;
  func9.definitionModule = "t314_chainImporter_test";
  setLineNumber(7);    // compilenode typedec
  // Type decl T
  // call case 6: other requests
  var call15 = request(var_im1, "A", [0]);
  // call case 6: other requests
  var call16 = request(var_im1, "B", [0]);
  var opresult17 = request(call15, "&(1)", [1], call16);
  var var_T = opresult17;
  var type14 = opresult17;
  var func18 = function(argcv) {     // accessor method T
    return var_T;
  };    // end of method T
  this.methods["T"] = func18;
  func18.paramCounts = [0];
  func18.paramNames = [];
  func18.typeParamNames = [];
  func18.definitionLine = 1;
  func18.definitionModule = "t314_chainImporter_test";
  setLineNumber(8);    // compilenode typedec
  // Type decl U
  // call case 6: other requests
  var call20 = request(var_im2, "AB", [0]);
  var var_U = call20;
  var type19 = call20;
  var func21 = function(argcv) {     // accessor method U
    return var_U;
  };    // end of method U
  this.methods["U"] = func21;
  func21.paramCounts = [0];
  func21.paramNames = [];
  func21.typeParamNames = [];
  func21.definitionLine = 1;
  func21.definitionModule = "t314_chainImporter_test";
  setLineNumber(21);    // compilenode member
  // call case 4: self request
  var call22 = selfRequest(this, "t", [0]);
  var var_x = call22;
  var reader23_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader23_x.isDef = true;
  reader23_x.confidential = true;
  this.methods["x"] = reader23_x;
  assertTypeOrMsg(var_x, var_U, "value of def x", "U");
  setLineNumber(22);    // compilenode member
  // call case 4: self request
  var call24 = selfRequest(this, "u", [0]);
  var var_y = call24;
  var reader25_y = function() {  // reader method y
      if (var_y === undefined) raiseUninitializedVariable("y");
      return var_y;
  };
  reader25_y.isDef = true;
  reader25_y.confidential = true;
  this.methods["y"] = reader25_y;
  assertTypeOrMsg(var_y, var_T, "value of def y", "T");
  setLineNumber(23);    // compilenode string
  var string26 = new GraceString("");
  // call case 6: other requests
  if (var_x === undefined) raiseUninitializedVariable("x");
  var call27 = request(var_x, "p", [0]);
  var opresult28 = request(string26, "++(1)", [1], call27);
  var string29 = new GraceString(" ");
  var opresult30 = request(opresult28, "++(1)", [1], string29);
  // call case 6: other requests
  if (var_y === undefined) raiseUninitializedVariable("y");
  var call31 = request(var_y, "p", [0]);
  var opresult32 = request(opresult30, "++(1)", [1], call31);
  var string33 = new GraceString("");
  var opresult34 = request(opresult32, "++(1)", [1], string33);
  Grace_print(opresult34);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t314__95__chainImporter__95__test = gracecode_t314__95__chainImporter__95__test;
if (typeof window !== "undefined")
  window.gracecode_t314__95__chainImporter__95__test = gracecode_t314__95__chainImporter__95__test;
gracecode_t314__95__chainImporter__95__test.imports = ["StaticTyping", "t308_complicatedImportee_test", "t313_chainImportee_test"];
