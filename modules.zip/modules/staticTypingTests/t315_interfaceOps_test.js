;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t315_interfaceOps_test"] = "classes:\nconfidential:\n x\ndialect:\n StaticTyping\nfresh-methods:\n b\nfresh:b:\n m\n q(1)\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t315_interfaceOps_test.grace\npublic:\n A\n B\n b\n r\npublicMethod:b:\n b \u2192 B\npublicMethod:r:\n r \u2192 A & interface {\n    q(_:Number) \u2192 String}\npublicMethodTypes:\n b \u2192 B\n r \u2192 A & interface {\n    q(_:Number) \u2192 String}\ntypedec-of:A:\n type A = interface {\n            m \u2192 String}\ntypedec-of:B:\n type B = A & interface {\n    q(_:Number) \u2192 String}\ntypes:\n A\n B\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t315_interfaceOps_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "type A = interface { m -> String }",
    "type B = A & interface { q(_:Number)→String }",
    "",
    "class b → B {",
    "    method m → String { \"Hello \" }",
    "    method q(_:Number) → String { \"World\" }",
    "}",
    "",
    "method r -> A & interface { q(_:Number)→String } { b }",
    "",
    "def x : B = r",
    "print (x.m ++ x.q(47))" ];
}
function gracecode_t315__95__interfaceOps__95__test() {
  setModuleName("t315_interfaceOps_test");
  importedModules["t315_interfaceOps_test"] = this;
  var module$t315__95__interfaceOps__95__test = this;
  this.definitionModule = "t315_interfaceOps_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t315__95__interfaceOps__95__test_0");
  this.outer_t315__95__interfaceOps__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method b, line 6
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("b", "t315_interfaceOps_test", 6);
    var ouc_init = this.methods["b$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(11);    // typecheck
    assertTypeOrMsg(ouc, var_B, "object returned from b", "B");
    return ouc;
  };    // end of method b
  this.methods["b"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 6;
  func0.definitionModule = "t315_interfaceOps_test";
  var func1 = function(argcv, inheritingObject, aliases, exclusions) {    // method b$build(_,_,_), line 6
    var returnTarget = invocationCount;
    invocationCount++;
    var obj2_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t315__95__interfaceOps__95__test_6");
      this.outer_t315__95__interfaceOps__95__test_6 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv) {    // method m, line 7
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t315_interfaceOps_test");
        setLineNumber(7);    // compilenode string
        var string4 = new GraceString("Hello ");
        assertTypeOrMsg(string4, var_String, "result of method m", "String");
        return string4;
      };    // end of method m
      this.methods["m"] = func3;
      func3.paramCounts = [0];
      func3.paramNames = [];
      func3.typeParamNames = [];
      func3.definitionLine = 7;
      func3.definitionModule = "t315_interfaceOps_test";
      var func5 = function(argcv, var___95____95__2) {    // method q(_), line 8
        var returnTarget = invocationCount;
        invocationCount++;
        assertTypeOrMsg(var___95____95__2, var_Number, "argument to request of `q(_)`", "Number");
        setModuleName("t315_interfaceOps_test");
        setLineNumber(8);    // compilenode string
        var string6 = new GraceString("World");
        assertTypeOrMsg(string6, var_String, "result of method q(_)", "String");
        return string6;
      };    // end of method q(_)
      func5.paramTypes = [];
      func5.paramTypes.push([type_Number, "__2"]);
      this.methods["q(1)"] = func5;
      func5.paramCounts = [1];
      func5.paramNames = ["__2"];
      func5.typeParamNames = [];
      func5.definitionLine = 8;
      func5.definitionModule = "t315_interfaceOps_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 6
        setModuleName("t315_interfaceOps_test");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method b$build(_,_,_)
  this.methods["b$build(3)"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 6;
  func1.definitionModule = "t315_interfaceOps_test";
  var func7 = function(argcv) {    // method r, line 11
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("t315_interfaceOps_test");
    setLineNumber(11);    // compilenode member
    // call case 4: self request
    var call8 = selfRequest(this, "b", [0]);
    //   Type literal 
    var typeLit9 = new GraceType("\u2039anon\u203a");
    typeLit9.typeMethods.push("q(1)");
    var opresult10 = request(var_A, "&(1)", [1], typeLit9);
    assertTypeOrMsg(call8, opresult10, "result of method r", "A & interface {\n    q(_:Number) → String}");
    return call8;
  };    // end of method r
  this.methods["r"] = func7;
  func7.paramCounts = [0];
  func7.paramNames = [];
  func7.typeParamNames = [];
  func7.definitionLine = 11;
  func7.definitionModule = "t315_interfaceOps_test";
  setLineNumber(3);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit12 = new GraceType("A");
  typeLit12.typeMethods.push("m");
  var var_A = typeLit12;
  var type11 = typeLit12;
  var func13 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func13;
  func13.paramCounts = [0];
  func13.paramNames = [];
  func13.typeParamNames = [];
  func13.definitionLine = 1;
  func13.definitionModule = "t315_interfaceOps_test";
  setLineNumber(4);    // compilenode typedec
  // Type decl B
  //   Type literal 
  var typeLit15 = new GraceType("\u2039anon\u203a");
  typeLit15.typeMethods.push("q(1)");
  var opresult16 = request(var_A, "&(1)", [1], typeLit15);
  var var_B = opresult16;
  var type14 = opresult16;
  var func17 = function(argcv) {     // accessor method B
    return var_B;
  };    // end of method B
  this.methods["B"] = func17;
  func17.paramCounts = [0];
  func17.paramNames = [];
  func17.typeParamNames = [];
  func17.definitionLine = 1;
  func17.definitionModule = "t315_interfaceOps_test";
  setLineNumber(13);    // compilenode member
  // call case 4: self request
  var call18 = selfRequest(this, "r", [0]);
  var var_x = call18;
  var reader19_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader19_x.isDef = true;
  reader19_x.confidential = true;
  this.methods["x"] = reader19_x;
  assertTypeOrMsg(var_x, var_B, "value of def x", "B");
  setLineNumber(14);    // compilenode member
  // call case 6: other requests
  if (var_x === undefined) raiseUninitializedVariable("x");
  var call20 = request(var_x, "m", [0]);
  // call case 6: other requests
  if (var_x === undefined) raiseUninitializedVariable("x");
  var call21 = request(var_x, "q(1)", [1], new GraceNum(47));
  var opresult22 = request(call20, "++(1)", [1], call21);
  Grace_print(opresult22);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t315__95__interfaceOps__95__test = gracecode_t315__95__interfaceOps__95__test;
if (typeof window !== "undefined")
  window.gracecode_t315__95__interfaceOps__95__test = gracecode_t315__95__interfaceOps__95__test;
gracecode_t315__95__interfaceOps__95__test.imports = ["StaticTyping"];
