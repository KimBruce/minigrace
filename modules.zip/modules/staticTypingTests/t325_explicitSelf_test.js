;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t325_explicitSelf_test"] = "classes:\nconfidential:\n x\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t325_explicitSelf_test.grace\npublic:\n T\npublicMethodTypes:\ntypedec-of:T:\n type T = Number\ntypes:\n T\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t325_explicitSelf_test"] = [
    "dialect \"StaticTyping\"",
    "type T = Number",
    "",
    "def x: self.T = 47",
    "print \"{x}\"",
    "print \"Test Succeeded\"" ];
}
function gracecode_t325__95__explicitSelf__95__test() {
  setModuleName("t325_explicitSelf_test");
  importedModules["t325_explicitSelf_test"] = this;
  var module$t325__95__explicitSelf__95__test = this;
  this.definitionModule = "t325_explicitSelf_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t325__95__explicitSelf__95__test_0");
  this.outer_t325__95__explicitSelf__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(2);    // compilenode typedec
  // Type decl T
  var var_T = var_Number;
  var type0 = var_Number;
  var func1 = function(argcv) {     // accessor method T
    return var_T;
  };    // end of method T
  this.methods["T"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 1;
  func1.definitionModule = "t325_explicitSelf_test";
  setLineNumber(4);    // compilenode num
  var var_x = new GraceNum(47);
  var reader2_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader2_x.isDef = true;
  reader2_x.confidential = true;
  this.methods["x"] = reader2_x;
  // call case 4: self request
  var call3 = selfRequest(this, "T", [0]);
  assertTypeOrMsg(var_x, call3, "value of def x", "T");
  setLineNumber(5);    // compilenode string
  var string4 = new GraceString("");
  if (var_x === undefined) raiseUninitializedVariable("x");
  var opresult5 = request(string4, "++(1)", [1], var_x);
  var string6 = new GraceString("");
  var opresult7 = request(opresult5, "++(1)", [1], string6);
  Grace_print(opresult7);
  setLineNumber(6);    // compilenode string
  var string8 = new GraceString("Test Succeeded");
  Grace_print(string8);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t325__95__explicitSelf__95__test = gracecode_t325__95__explicitSelf__95__test;
if (typeof window !== "undefined")
  window.gracecode_t325__95__explicitSelf__95__test = gracecode_t325__95__explicitSelf__95__test;
gracecode_t325__95__explicitSelf__95__test.imports = ["StaticTyping"];
