;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t335A_basicImportee_test"] = "classes:\nconfidential:\n myConfidentialMeth\ndialect:\n StaticTyping\nfresh-methods:\n myClass\nfresh:myClass:\n a\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t335A_basicImportee_test.grace\npublic:\n AmpersandType\n FirstHalf\n MyType\n NumberCopy\n SecondHalf\n VariantType\n myClass\n myDef\n myMeth\n myMethWithParam(1)\n myVar\n myVar:=(1)\npublicMethod:myClass:\n myClass \u2192 MyType\npublicMethod:myDef:\n myDef \u2192 String\npublicMethod:myMeth:\n myMeth \u2192 Number\npublicMethod:myMethWithParam(1):\n myMethWithParam(myParam:interface {\n                    m(param:MyType) \u2192 Number\n                    n \u2192 String}) \u2192 String\npublicMethod:myVar:\n myVar \u2192 String\npublicMethod:myVar:=(1):\n myVar:=(myVar': String) \u2192 Done\npublicMethodTypes:\n myClass \u2192 MyType\n myDef \u2192 String\n myMeth \u2192 Number\n myMethWithParam(myParam:interface {\n            m(param:MyType) \u2192 Number\n            n \u2192 String}) \u2192 String\n myVar \u2192 String\n myVar:=(myVar': String) \u2192 Done\ntypedec-of:AmpersandType:\n type AmpersandType = FirstHalf & SecondHalf\ntypedec-of:FirstHalf:\n type FirstHalf = interface {\n            firstMeth \u2192 Number}\ntypedec-of:MyType:\n type MyType = interface {\n            a \u2192 Number}\ntypedec-of:NumberCopy:\n type NumberCopy = Number\ntypedec-of:SecondHalf:\n type SecondHalf = interface {\n            secondMeth \u2192 Number}\ntypedec-of:VariantType:\n type VariantType = FirstHalf | SecondHalf\ntypes:\n AmpersandType\n FirstHalf\n MyType\n NumberCopy\n SecondHalf\n VariantType\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t335A_basicImportee_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "",
    "type NumberCopy = Number",
    "type MyType = { a -> Number }",
    "",
    "class myClass -> MyType {",
    "    method a -> Number { 47 }",
    "}",
    "",
    "def myDef : String is public = \"Mini\"",
    "",
    "var myVar : String is public := \"Grace\"",
    "",
    "method myMeth -> Number { 47 }",
    "",
    "method myMethWithParam(myParam : interface{",
    "    m(param : MyType) -> Number",
    "    n -> String",
    "}) -> String { myParam.n }",
    "",
    "method myConfidentialMeth -> Number is confidential { 47 }",
    "",
    "// ********* ampersand and variant",
    "",
    "type FirstHalf  = { firstMeth -> Number }",
    "type SecondHalf = { secondMeth -> Number }",
    "",
    "type AmpersandType = FirstHalf & SecondHalf",
    "type VariantType   = FirstHalf | SecondHalf" ];
}
function gracecode_t335A__95__basicImportee__95__test() {
  setModuleName("t335A_basicImportee_test");
  importedModules["t335A_basicImportee_test"] = this;
  var module$t335A__95__basicImportee__95__test = this;
  this.definitionModule = "t335A_basicImportee_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t335A__95__basicImportee__95__test_0");
  this.outer_t335A__95__basicImportee__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method myClass, line 7
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("myClass", "t335A_basicImportee_test", 7);
    var ouc_init = this.methods["myClass$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(15);    // typecheck
    assertTypeOrMsg(ouc, var_MyType, "object returned from myClass", "MyType");
    return ouc;
  };    // end of method myClass
  this.methods["myClass"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 7;
  func0.definitionModule = "t335A_basicImportee_test";
  var func1 = function(argcv, inheritingObject, aliases, exclusions) {    // method myClass$build(_,_,_), line 7
    var returnTarget = invocationCount;
    invocationCount++;
    var obj2_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t335A__95__basicImportee__95__test_7");
      this.outer_t335A__95__basicImportee__95__test_7 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv) {    // method a, line 8
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t335A_basicImportee_test");
        setLineNumber(8);    // typecheck
        assertTypeOrMsg(new GraceNum(47), var_Number, "result of method a", "Number");
        return new GraceNum(47);
      };    // end of method a
      this.methods["a"] = func3;
      func3.paramCounts = [0];
      func3.paramNames = [];
      func3.typeParamNames = [];
      func3.definitionLine = 8;
      func3.definitionModule = "t335A_basicImportee_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 7
        setModuleName("t335A_basicImportee_test");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method myClass$build(_,_,_)
  this.methods["myClass$build(3)"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 7;
  func1.definitionModule = "t335A_basicImportee_test";
  var func4 = function(argcv) {    // method myMeth, line 15
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("t335A_basicImportee_test");
    setLineNumber(15);    // typecheck
    assertTypeOrMsg(new GraceNum(47), var_Number, "result of method myMeth", "Number");
    return new GraceNum(47);
  };    // end of method myMeth
  this.methods["myMeth"] = func4;
  func4.paramCounts = [0];
  func4.paramNames = [];
  func4.typeParamNames = [];
  func4.definitionLine = 15;
  func4.definitionModule = "t335A_basicImportee_test";
  var func5 = function(argcv, var_myParam) {    // method myMethWithParam(_), line 17
    var returnTarget = invocationCount;
    invocationCount++;
    setLineNumber(17);    // compilenode typeliteral
    //   Type literal 
    var typeLit6 = new GraceType("\u2039anon\u203a");
    typeLit6.typeMethods.push("m(1)");
    typeLit6.typeMethods.push("n");
    assertTypeOrMsg(var_myParam, typeLit6, "argument to request of `myMethWithParam(_)`", "interface {\n    m(param:MyType) → Number\n    n → String}");
    setModuleName("t335A_basicImportee_test");
    setLineNumber(20);    // compilenode member
    // call case 6: other requests
    var call7 = request(var_myParam, "n", [0]);
    assertTypeOrMsg(call7, var_String, "result of method myMethWithParam(_)", "String");
    return call7;
  };    // end of method myMethWithParam(_)
  func5.paramTypes = [];
  func5.paramTypes.push([]);
  this.methods["myMethWithParam(1)"] = func5;
  func5.paramCounts = [1];
  func5.paramNames = ["myParam"];
  func5.typeParamNames = [];
  func5.definitionLine = 17;
  func5.definitionModule = "t335A_basicImportee_test";
  var func8 = function(argcv) {    // method myConfidentialMeth, line 22
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("t335A_basicImportee_test");
    setLineNumber(22);    // typecheck
    assertTypeOrMsg(new GraceNum(47), var_Number, "result of method myConfidentialMeth", "Number");
    return new GraceNum(47);
  };    // end of method myConfidentialMeth
  func8.confidential = true;
  this.methods["myConfidentialMeth"] = func8;
  func8.paramCounts = [0];
  func8.paramNames = [];
  func8.typeParamNames = [];
  func8.definitionLine = 22;
  func8.definitionModule = "t335A_basicImportee_test";
  setLineNumber(4);    // compilenode typedec
  // Type decl NumberCopy
  var var_NumberCopy = var_Number;
  var type9 = var_Number;
  var func10 = function(argcv) {     // accessor method NumberCopy
    return var_NumberCopy;
  };    // end of method NumberCopy
  this.methods["NumberCopy"] = func10;
  func10.paramCounts = [0];
  func10.paramNames = [];
  func10.typeParamNames = [];
  func10.definitionLine = 1;
  func10.definitionModule = "t335A_basicImportee_test";
  setLineNumber(5);    // compilenode typedec
  // Type decl MyType
  //   Type literal 
  var typeLit12 = new GraceType("MyType");
  typeLit12.typeMethods.push("a");
  var var_MyType = typeLit12;
  var type11 = typeLit12;
  var func13 = function(argcv) {     // accessor method MyType
    return var_MyType;
  };    // end of method MyType
  this.methods["MyType"] = func13;
  func13.paramCounts = [0];
  func13.paramNames = [];
  func13.typeParamNames = [];
  func13.definitionLine = 1;
  func13.definitionModule = "t335A_basicImportee_test";
  setLineNumber(11);    // compilenode string
  var string14 = new GraceString("Mini");
  var var_myDef = string14;
  var reader15_myDef = function() {  // reader method myDef
      if (var_myDef === undefined) raiseUninitializedVariable("myDef");
      return var_myDef;
  };
  reader15_myDef.isDef = true;
  this.methods["myDef"] = reader15_myDef;
  assertTypeOrMsg(var_myDef, var_String, "value of def myDef", "String");
  setLineNumber(13);    // compilenode string
  var string16 = new GraceString("Grace");
  assertTypeOrMsg(string16, var_String, "initial value of var myVar", "String");
  var var_myVar = string16;
  var reader17_myVar = function() {  // reader method myVar
      if (var_myVar === undefined) raiseUninitializedVariable("myVar");
      return var_myVar;
  };
  reader17_myVar.isVar = true;
  this.methods["myVar"] = reader17_myVar;
  var writer18_myVar = function(argcv, n) {   // writer method myVar:=(_)
    assertTypeOrMsg(n, var_String, "argument to myVar:=(_)", "String");
    var_myVar = n;
    return GraceDone;
  };
  this.methods["myVar:=(1)"] = writer18_myVar;
  setLineNumber(26);    // compilenode typedec
  // Type decl FirstHalf
  //   Type literal 
  var typeLit20 = new GraceType("FirstHalf");
  typeLit20.typeMethods.push("firstMeth");
  var var_FirstHalf = typeLit20;
  var type19 = typeLit20;
  var func21 = function(argcv) {     // accessor method FirstHalf
    return var_FirstHalf;
  };    // end of method FirstHalf
  this.methods["FirstHalf"] = func21;
  func21.paramCounts = [0];
  func21.paramNames = [];
  func21.typeParamNames = [];
  func21.definitionLine = 1;
  func21.definitionModule = "t335A_basicImportee_test";
  setLineNumber(27);    // compilenode typedec
  // Type decl SecondHalf
  //   Type literal 
  var typeLit23 = new GraceType("SecondHalf");
  typeLit23.typeMethods.push("secondMeth");
  var var_SecondHalf = typeLit23;
  var type22 = typeLit23;
  var func24 = function(argcv) {     // accessor method SecondHalf
    return var_SecondHalf;
  };    // end of method SecondHalf
  this.methods["SecondHalf"] = func24;
  func24.paramCounts = [0];
  func24.paramNames = [];
  func24.typeParamNames = [];
  func24.definitionLine = 1;
  func24.definitionModule = "t335A_basicImportee_test";
  setLineNumber(29);    // compilenode typedec
  // Type decl AmpersandType
  var opresult26 = request(var_FirstHalf, "&(1)", [1], var_SecondHalf);
  var var_AmpersandType = opresult26;
  var type25 = opresult26;
  var func27 = function(argcv) {     // accessor method AmpersandType
    return var_AmpersandType;
  };    // end of method AmpersandType
  this.methods["AmpersandType"] = func27;
  func27.paramCounts = [0];
  func27.paramNames = [];
  func27.typeParamNames = [];
  func27.definitionLine = 1;
  func27.definitionModule = "t335A_basicImportee_test";
  setLineNumber(30);    // compilenode typedec
  // Type decl VariantType
  var opresult29 = request(var_FirstHalf, "|(1)", [1], var_SecondHalf);
  var var_VariantType = opresult29;
  var type28 = opresult29;
  var func30 = function(argcv) {     // accessor method VariantType
    return var_VariantType;
  };    // end of method VariantType
  this.methods["VariantType"] = func30;
  func30.paramCounts = [0];
  func30.paramNames = [];
  func30.typeParamNames = [];
  func30.definitionLine = 1;
  func30.definitionModule = "t335A_basicImportee_test";
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t335A__95__basicImportee__95__test = gracecode_t335A__95__basicImportee__95__test;
if (typeof window !== "undefined")
  window.gracecode_t335A__95__basicImportee__95__test = gracecode_t335A__95__basicImportee__95__test;
gracecode_t335A__95__basicImportee__95__test.imports = ["StaticTyping"];
