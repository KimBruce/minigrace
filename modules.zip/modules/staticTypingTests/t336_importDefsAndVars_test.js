;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t336_importDefsAndVars_test"] = "classes:\nconfidential:\n im\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n t335A_basicImportee_test\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t336_importDefsAndVars_test.grace\npublic:\n im.AmpersandType\n im.FirstHalf\n im.MyType\n im.NumberCopy\n im.SecondHalf\n im.VariantType\npublicMethodTypes:\ntypedec-of:im.AmpersandType:\n type AmpersandType = FirstHalf & SecondHalf\ntypedec-of:im.FirstHalf:\n type FirstHalf = interface {\n            firstMeth \u2192 Number}\ntypedec-of:im.MyType:\n type MyType = interface {\n            a \u2192 Number}\ntypedec-of:im.NumberCopy:\n type NumberCopy = Number\ntypedec-of:im.SecondHalf:\n type SecondHalf = interface {\n            secondMeth \u2192 Number}\ntypedec-of:im.VariantType:\n type VariantType = FirstHalf | SecondHalf\ntypes:\n im.AmpersandType\n im.FirstHalf\n im.MyType\n im.NumberCopy\n im.SecondHalf\n im.VariantType\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t336_importDefsAndVars_test"] = [
    "dialect \"StaticTyping\"",
    "import \"t335A_basicImportee_test\" as im",
    "",
    "if((im.myDef ++ im.myVar) == \"MiniGrace\") then {",
    "    print \"test succeeded\"",
    "} else {",
    "    print \"test failed\"",
    "}" ];
}
function gracecode_t336__95__importDefsAndVars__95__test() {
  setModuleName("t336_importDefsAndVars_test");
  importedModules["t336_importDefsAndVars_test"] = this;
  var module$t336__95__importDefsAndVars__95__test = this;
  this.definitionModule = "t336_importDefsAndVars_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t336__95__importDefsAndVars__95__test_0");
  this.outer_t336__95__importDefsAndVars__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(2);    // compilenode import
  // Import of "t335A_basicImportee_test" as im
  if (typeof gracecode_t335A__95__basicImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module t335A_basicImportee_test"));
  var var_im = do_import("t335A_basicImportee_test", gracecode_t335A__95__basicImportee__95__test);
  var func0 = function(argcv) {     // accessor method im
    if (var_im === undefined) raiseUninitializedVariable("im");
    return var_im;
  };    // end of method im
  this.methods["im"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 2;
  func0.definitionModule = "t336_importDefsAndVars_test";
  func0.debug = "import";
  func0.confidential = true;
  setModuleName("t336_importDefsAndVars_test");
  var if1 = GraceDone;
  setLineNumber(4);    // compilenode member
  // call case 6: other requests
  var call2 = request(var_im, "myDef", [0]);
  // call case 6: other requests
  var call3 = request(var_im, "myVar", [0]);
  var opresult4 = request(call2, "++(1)", [1], call3);
  var string5 = new GraceString("MiniGrace");
  var opresult6 = request(opresult4, "==(1)", [1], string5);
  if (Grace_isTrue(opresult6)) {
    setLineNumber(5);    // compilenode string
    var string7 = new GraceString("test succeeded");
    Grace_print(string7);
    if1 = GraceDone;
  } else {
    setLineNumber(7);    // compilenode string
    var string8 = new GraceString("test failed");
    Grace_print(string8);
    if1 = GraceDone;
  }
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t336__95__importDefsAndVars__95__test = gracecode_t336__95__importDefsAndVars__95__test;
if (typeof window !== "undefined")
  window.gracecode_t336__95__importDefsAndVars__95__test = gracecode_t336__95__importDefsAndVars__95__test;
gracecode_t336__95__importDefsAndVars__95__test.imports = ["StaticTyping", "t335A_basicImportee_test"];
