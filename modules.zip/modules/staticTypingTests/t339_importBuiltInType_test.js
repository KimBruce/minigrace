;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t339_importBuiltInType_test"] = "classes:\nconfidential:\n im\n x\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n t335A_basicImportee_test\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t339_importBuiltInType_test.grace\npublic:\n im.AmpersandType\n im.FirstHalf\n im.MyType\n im.NumberCopy\n im.SecondHalf\n im.VariantType\npublicMethodTypes:\ntypedec-of:im.AmpersandType:\n type AmpersandType = FirstHalf & SecondHalf\ntypedec-of:im.FirstHalf:\n type FirstHalf = interface {\n            firstMeth \u2192 Number}\ntypedec-of:im.MyType:\n type MyType = interface {\n            a \u2192 Number}\ntypedec-of:im.NumberCopy:\n type NumberCopy = Number\ntypedec-of:im.SecondHalf:\n type SecondHalf = interface {\n            secondMeth \u2192 Number}\ntypedec-of:im.VariantType:\n type VariantType = FirstHalf | SecondHalf\ntypes:\n im.AmpersandType\n im.FirstHalf\n im.MyType\n im.NumberCopy\n im.SecondHalf\n im.VariantType\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t339_importBuiltInType_test"] = [
    "dialect \"StaticTyping\"",
    "import \"t335A_basicImportee_test\" as im",
    "",
    "//This test currently fails, as we cannot import types that are not",
    "//strictly type literals.",
    "",
    "def x : im.NumberCopy = 47",
    "print \"test succeeded\"" ];
}
function gracecode_t339__95__importBuiltInType__95__test() {
  setModuleName("t339_importBuiltInType_test");
  importedModules["t339_importBuiltInType_test"] = this;
  var module$t339__95__importBuiltInType__95__test = this;
  this.definitionModule = "t339_importBuiltInType_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t339__95__importBuiltInType__95__test_0");
  this.outer_t339__95__importBuiltInType__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(2);    // compilenode import
  // Import of "t335A_basicImportee_test" as im
  if (typeof gracecode_t335A__95__basicImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module t335A_basicImportee_test"));
  var var_im = do_import("t335A_basicImportee_test", gracecode_t335A__95__basicImportee__95__test);
  var func0 = function(argcv) {     // accessor method im
    if (var_im === undefined) raiseUninitializedVariable("im");
    return var_im;
  };    // end of method im
  this.methods["im"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 2;
  func0.definitionModule = "t339_importBuiltInType_test";
  func0.debug = "import";
  func0.confidential = true;
  setModuleName("t339_importBuiltInType_test");
  setLineNumber(7);    // compilenode num
  var var_x = new GraceNum(47);
  var reader1_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader1_x.isDef = true;
  reader1_x.confidential = true;
  this.methods["x"] = reader1_x;
  // call case 6: other requests
  var call2 = request(var_im, "NumberCopy", [0]);
  assertTypeOrMsg(var_x, call2, "value of def x", "im.NumberCopy");
  setLineNumber(8);    // compilenode string
  var string3 = new GraceString("test succeeded");
  Grace_print(string3);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t339__95__importBuiltInType__95__test = gracecode_t339__95__importBuiltInType__95__test;
if (typeof window !== "undefined")
  window.gracecode_t339__95__importBuiltInType__95__test = gracecode_t339__95__importBuiltInType__95__test;
gracecode_t339__95__importBuiltInType__95__test.imports = ["StaticTyping", "t335A_basicImportee_test"];
