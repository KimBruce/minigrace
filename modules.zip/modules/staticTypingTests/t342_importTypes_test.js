;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t342_importTypes_test"] = "classes:\nconfidential:\n im\n x\n x:=(x': Number) \u2192 Done\ndialect:\n StaticTyping\nfresh-methods:\n m\nfresh:m:\n a\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n t335A_basicImportee_test\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t342_importTypes_test.grace\npublic:\n im.AmpersandType\n im.FirstHalf\n im.MyType\n im.NumberCopy\n im.SecondHalf\n im.VariantType\n m\npublicMethod:m:\n m \u2192 im.MyType\npublicMethodTypes:\n m \u2192 im.MyType\ntypedec-of:im.AmpersandType:\n type AmpersandType = FirstHalf & SecondHalf\ntypedec-of:im.FirstHalf:\n type FirstHalf = interface {\n            firstMeth \u2192 Number}\ntypedec-of:im.MyType:\n type MyType = interface {\n            a \u2192 Number}\ntypedec-of:im.NumberCopy:\n type NumberCopy = Number\ntypedec-of:im.SecondHalf:\n type SecondHalf = interface {\n            secondMeth \u2192 Number}\ntypedec-of:im.VariantType:\n type VariantType = FirstHalf | SecondHalf\ntypes:\n im.AmpersandType\n im.FirstHalf\n im.MyType\n im.NumberCopy\n im.SecondHalf\n im.VariantType\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t342_importTypes_test"] = [
    "dialect \"StaticTyping\"",
    "import \"t335A_basicImportee_test\" as im",
    "",
    "class m -> im.MyType {",
    "    method a -> Number{47}",
    "}",
    "",
    "var x : Number := m.a",
    "print \"test succeeded\"" ];
}
function gracecode_t342__95__importTypes__95__test() {
  setModuleName("t342_importTypes_test");
  importedModules["t342_importTypes_test"] = this;
  var module$t342__95__importTypes__95__test = this;
  this.definitionModule = "t342_importTypes_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t342__95__importTypes__95__test_0");
  this.outer_t342__95__importTypes__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(2);    // compilenode import
  // Import of "t335A_basicImportee_test" as im
  if (typeof gracecode_t335A__95__basicImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module t335A_basicImportee_test"));
  var var_im = do_import("t335A_basicImportee_test", gracecode_t335A__95__basicImportee__95__test);
  var func0 = function(argcv) {     // accessor method im
    if (var_im === undefined) raiseUninitializedVariable("im");
    return var_im;
  };    // end of method im
  this.methods["im"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 2;
  func0.definitionModule = "t342_importTypes_test";
  func0.debug = "import";
  func0.confidential = true;
  setModuleName("t342_importTypes_test");
  var func1 = function(argcv) {    // method m, line 4
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("m", "t342_importTypes_test", 4);
    var ouc_init = this.methods["m$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(4);    // compilenode member
    // call case 6: other requests
    if (var_im === undefined) raiseUninitializedVariable("im");
    var call2 = request(var_im, "MyType", [0]);
    assertTypeOrMsg(ouc, call2, "object returned from m", "im.MyType");
    return ouc;
  };    // end of method m
  this.methods["m"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 4;
  func1.definitionModule = "t342_importTypes_test";
  var func3 = function(argcv, inheritingObject, aliases, exclusions) {    // method m$build(_,_,_), line 4
    var returnTarget = invocationCount;
    invocationCount++;
    var obj4_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t342__95__importTypes__95__test_4");
      this.outer_t342__95__importTypes__95__test_4 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func5 = function(argcv) {    // method a, line 5
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t342_importTypes_test");
        setLineNumber(5);    // typecheck
        assertTypeOrMsg(new GraceNum(47), var_Number, "result of method a", "Number");
        return new GraceNum(47);
      };    // end of method a
      this.methods["a"] = func5;
      func5.paramCounts = [0];
      func5.paramNames = [];
      func5.typeParamNames = [];
      func5.definitionLine = 5;
      func5.definitionModule = "t342_importTypes_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj4_init = function() {    // init of object on line 4
        setModuleName("t342_importTypes_test");
      };
      return obj4_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj4_init = obj4_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj4_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method m$build(_,_,_)
  this.methods["m$build(3)"] = func3;
  func3.paramCounts = [0];
  func3.paramNames = [];
  func3.typeParamNames = [];
  func3.definitionLine = 4;
  func3.definitionModule = "t342_importTypes_test";
  setLineNumber(8);    // compilenode member
  // call case 6: other requests
  // call case 4: self request
  var call7 = selfRequest(this, "m", [0]);
  var call6 = request(call7, "a", [0]);
  assertTypeOrMsg(call6, var_Number, "initial value of var x", "Number");
  var var_x = call6;
  var reader8_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader8_x.isVar = true;
  reader8_x.confidential = true;
  this.methods["x"] = reader8_x;
  var writer9_x = function(argcv, n) {   // writer method x:=(_)
    assertTypeOrMsg(n, var_Number, "argument to x:=(_)", "Number");
    var_x = n;
    return GraceDone;
  };
  writer9_x.confidential = true;
  this.methods["x:=(1)"] = writer9_x;
  setLineNumber(9);    // compilenode string
  var string10 = new GraceString("test succeeded");
  Grace_print(string10);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t342__95__importTypes__95__test = gracecode_t342__95__importTypes__95__test;
if (typeof window !== "undefined")
  window.gracecode_t342__95__importTypes__95__test = gracecode_t342__95__importTypes__95__test;
gracecode_t342__95__importTypes__95__test.imports = ["StaticTyping", "t335A_basicImportee_test"];
