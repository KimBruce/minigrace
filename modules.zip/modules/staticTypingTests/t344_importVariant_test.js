;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t344_importVariant_test"] = "classes:\nconfidential:\n im\n test1\n test2\ndialect:\n StaticTyping\nfresh-methods:\n firstClass\n secondClass\nfresh:firstClass:\n firstMeth\nfresh:secondClass:\n secondMeth\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n t335A_basicImportee_test\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t344_importVariant_test.grace\npublic:\n FirstHalf\n SecondHalf\n firstClass\n im.AmpersandType\n im.FirstHalf\n im.MyType\n im.NumberCopy\n im.SecondHalf\n im.VariantType\n secondClass\npublicMethod:firstClass:\n firstClass \u2192 FirstHalf\npublicMethod:secondClass:\n secondClass \u2192 SecondHalf\npublicMethodTypes:\n firstClass \u2192 FirstHalf\n secondClass \u2192 SecondHalf\ntypedec-of:FirstHalf:\n type FirstHalf = interface {\n            firstMeth \u2192 Number}\ntypedec-of:SecondHalf:\n type SecondHalf = interface {\n            secondMeth \u2192 Number}\ntypedec-of:im.AmpersandType:\n type AmpersandType = FirstHalf & SecondHalf\ntypedec-of:im.FirstHalf:\n type FirstHalf = interface {\n            firstMeth \u2192 Number}\ntypedec-of:im.MyType:\n type MyType = interface {\n            a \u2192 Number}\ntypedec-of:im.NumberCopy:\n type NumberCopy = Number\ntypedec-of:im.SecondHalf:\n type SecondHalf = interface {\n            secondMeth \u2192 Number}\ntypedec-of:im.VariantType:\n type VariantType = FirstHalf | SecondHalf\ntypes:\n FirstHalf\n SecondHalf\n im.AmpersandType\n im.FirstHalf\n im.MyType\n im.NumberCopy\n im.SecondHalf\n im.VariantType\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t344_importVariant_test"] = [
    "dialect \"StaticTyping\"",
    "import \"t335A_basicImportee_test\" as im",
    "",
    "//This test does not currently work because variant types",
    "//are not supported in imports.",
    "",
    "//Recreate the first and second halves of the VariantType",
    "type FirstHalf  = { firstMeth -> Number }",
    "type SecondHalf = { secondMeth -> Number }",
    "",
    "class firstClass  -> FirstHalf {",
    "    method firstMeth  -> Number { 47 }",
    "}",
    "class secondClass -> SecondHalf{",
    "    method secondMeth -> Number{ 48 }",
    "}",
    "",
    "def test1 : im.VariantType = firstClass",
    "def test2 : im.VariantType = secondClass",
    "print \"test succeeded\"" ];
}
function gracecode_t344__95__importVariant__95__test() {
  setModuleName("t344_importVariant_test");
  importedModules["t344_importVariant_test"] = this;
  var module$t344__95__importVariant__95__test = this;
  this.definitionModule = "t344_importVariant_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t344__95__importVariant__95__test_0");
  this.outer_t344__95__importVariant__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(2);    // compilenode import
  // Import of "t335A_basicImportee_test" as im
  if (typeof gracecode_t335A__95__basicImportee__95__test == "undefined")
    throw new GraceExceptionPacket(EnvironmentExceptionObject, 
      new GraceString("could not find module t335A_basicImportee_test"));
  var var_im = do_import("t335A_basicImportee_test", gracecode_t335A__95__basicImportee__95__test);
  var func0 = function(argcv) {     // accessor method im
    if (var_im === undefined) raiseUninitializedVariable("im");
    return var_im;
  };    // end of method im
  this.methods["im"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 2;
  func0.definitionModule = "t344_importVariant_test";
  func0.debug = "import";
  func0.confidential = true;
  setModuleName("t344_importVariant_test");
  var func1 = function(argcv) {    // method firstClass, line 11
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("firstClass", "t344_importVariant_test", 11);
    var ouc_init = this.methods["firstClass$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(15);    // typecheck
    assertTypeOrMsg(ouc, var_FirstHalf, "object returned from firstClass", "FirstHalf");
    return ouc;
  };    // end of method firstClass
  this.methods["firstClass"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 11;
  func1.definitionModule = "t344_importVariant_test";
  var func2 = function(argcv, inheritingObject, aliases, exclusions) {    // method firstClass$build(_,_,_), line 11
    var returnTarget = invocationCount;
    invocationCount++;
    var obj3_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t344__95__importVariant__95__test_11");
      this.outer_t344__95__importVariant__95__test_11 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func4 = function(argcv) {    // method firstMeth, line 12
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t344_importVariant_test");
        setLineNumber(12);    // typecheck
        assertTypeOrMsg(new GraceNum(47), var_Number, "result of method firstMeth", "Number");
        return new GraceNum(47);
      };    // end of method firstMeth
      this.methods["firstMeth"] = func4;
      func4.paramCounts = [0];
      func4.paramNames = [];
      func4.typeParamNames = [];
      func4.definitionLine = 12;
      func4.definitionModule = "t344_importVariant_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj3_init = function() {    // init of object on line 11
        setModuleName("t344_importVariant_test");
      };
      return obj3_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj3_init = obj3_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj3_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method firstClass$build(_,_,_)
  this.methods["firstClass$build(3)"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 11;
  func2.definitionModule = "t344_importVariant_test";
  var func5 = function(argcv) {    // method secondClass, line 14
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("secondClass", "t344_importVariant_test", 14);
    var ouc_init = this.methods["secondClass$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_SecondHalf, "object returned from secondClass", "SecondHalf");
    return ouc;
  };    // end of method secondClass
  this.methods["secondClass"] = func5;
  func5.paramCounts = [0];
  func5.paramNames = [];
  func5.typeParamNames = [];
  func5.definitionLine = 14;
  func5.definitionModule = "t344_importVariant_test";
  var func6 = function(argcv, inheritingObject, aliases, exclusions) {    // method secondClass$build(_,_,_), line 14
    var returnTarget = invocationCount;
    invocationCount++;
    var obj7_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t344__95__importVariant__95__test_14");
      this.outer_t344__95__importVariant__95__test_14 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func8 = function(argcv) {    // method secondMeth, line 15
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t344_importVariant_test");
        setLineNumber(15);    // typecheck
        assertTypeOrMsg(new GraceNum(48), var_Number, "result of method secondMeth", "Number");
        return new GraceNum(48);
      };    // end of method secondMeth
      this.methods["secondMeth"] = func8;
      func8.paramCounts = [0];
      func8.paramNames = [];
      func8.typeParamNames = [];
      func8.definitionLine = 15;
      func8.definitionModule = "t344_importVariant_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj7_init = function() {    // init of object on line 14
        setModuleName("t344_importVariant_test");
      };
      return obj7_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj7_init = obj7_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj7_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method secondClass$build(_,_,_)
  this.methods["secondClass$build(3)"] = func6;
  func6.paramCounts = [0];
  func6.paramNames = [];
  func6.typeParamNames = [];
  func6.definitionLine = 14;
  func6.definitionModule = "t344_importVariant_test";
  setLineNumber(8);    // compilenode typedec
  // Type decl FirstHalf
  //   Type literal 
  var typeLit10 = new GraceType("FirstHalf");
  typeLit10.typeMethods.push("firstMeth");
  var var_FirstHalf = typeLit10;
  var type9 = typeLit10;
  var func11 = function(argcv) {     // accessor method FirstHalf
    return var_FirstHalf;
  };    // end of method FirstHalf
  this.methods["FirstHalf"] = func11;
  func11.paramCounts = [0];
  func11.paramNames = [];
  func11.typeParamNames = [];
  func11.definitionLine = 1;
  func11.definitionModule = "t344_importVariant_test";
  setLineNumber(9);    // compilenode typedec
  // Type decl SecondHalf
  //   Type literal 
  var typeLit13 = new GraceType("SecondHalf");
  typeLit13.typeMethods.push("secondMeth");
  var var_SecondHalf = typeLit13;
  var type12 = typeLit13;
  var func14 = function(argcv) {     // accessor method SecondHalf
    return var_SecondHalf;
  };    // end of method SecondHalf
  this.methods["SecondHalf"] = func14;
  func14.paramCounts = [0];
  func14.paramNames = [];
  func14.typeParamNames = [];
  func14.definitionLine = 1;
  func14.definitionModule = "t344_importVariant_test";
  setLineNumber(18);    // compilenode member
  // call case 4: self request
  var call15 = selfRequest(this, "firstClass", [0]);
  var var_test1 = call15;
  var reader16_test1 = function() {  // reader method test1
      if (var_test1 === undefined) raiseUninitializedVariable("test1");
      return var_test1;
  };
  reader16_test1.isDef = true;
  reader16_test1.confidential = true;
  this.methods["test1"] = reader16_test1;
  // call case 6: other requests
  var call17 = request(var_im, "VariantType", [0]);
  assertTypeOrMsg(var_test1, call17, "value of def test1", "im.VariantType");
  setLineNumber(19);    // compilenode member
  // call case 4: self request
  var call18 = selfRequest(this, "secondClass", [0]);
  var var_test2 = call18;
  var reader19_test2 = function() {  // reader method test2
      if (var_test2 === undefined) raiseUninitializedVariable("test2");
      return var_test2;
  };
  reader19_test2.isDef = true;
  reader19_test2.confidential = true;
  this.methods["test2"] = reader19_test2;
  // call case 6: other requests
  var call20 = request(var_im, "VariantType", [0]);
  assertTypeOrMsg(var_test2, call20, "value of def test2", "im.VariantType");
  setLineNumber(20);    // compilenode string
  var string21 = new GraceString("test succeeded");
  Grace_print(string21);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t344__95__importVariant__95__test = gracecode_t344__95__importVariant__95__test;
if (typeof window !== "undefined")
  window.gracecode_t344__95__importVariant__95__test = gracecode_t344__95__importVariant__95__test;
gracecode_t344__95__importVariant__95__test.imports = ["StaticTyping", "t335A_basicImportee_test"];
