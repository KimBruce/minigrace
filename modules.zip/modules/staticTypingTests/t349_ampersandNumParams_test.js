;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t349_ampersandNumParams_test"] = "classes:\nconfidential:\n x\ndialect:\n StaticTyping\nfresh-methods:\n ampersandA\nfresh:ampersandA:\n a\n a(1)\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t349_ampersandNumParams_test.grace\npublic:\n A\n B\n C\n ampersandA\npublicMethod:ampersandA:\n ampersandA \u2192 C\npublicMethodTypes:\n ampersandA \u2192 C\ntypedec-of:A:\n type A = interface {\n            a \u2192 Boolean}\ntypedec-of:B:\n type B = interface {\n            a(bool:Boolean) \u2192 Boolean}\ntypedec-of:C:\n type C = A & B\ntypes:\n A\n B\n C\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t349_ampersandNumParams_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "type A = {",
    "    a -> Boolean",
    "}",
    "",
    "type B = {",
    "    a(bool: Boolean) -> Boolean",
    "}",
    "",
    "type C = A & B",
    "",
    "class ampersandA -> C {",
    "    method a -> Boolean { true }",
    "    method a(bool : Boolean) -> Boolean { bool }",
    "}",
    "",
    "def x: C = ampersandA",
    "print(x.a)",
    "print(x.a(false))" ];
}
function gracecode_t349__95__ampersandNumParams__95__test() {
  setModuleName("t349_ampersandNumParams_test");
  importedModules["t349_ampersandNumParams_test"] = this;
  var module$t349__95__ampersandNumParams__95__test = this;
  this.definitionModule = "t349_ampersandNumParams_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t349__95__ampersandNumParams__95__test_0");
  this.outer_t349__95__ampersandNumParams__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method ampersandA, line 13
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("ampersandA", "t349_ampersandNumParams_test", 13);
    var ouc_init = this.methods["ampersandA$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_C, "object returned from ampersandA", "C");
    return ouc;
  };    // end of method ampersandA
  this.methods["ampersandA"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 13;
  func0.definitionModule = "t349_ampersandNumParams_test";
  var func1 = function(argcv, inheritingObject, aliases, exclusions) {    // method ampersandA$build(_,_,_), line 13
    var returnTarget = invocationCount;
    invocationCount++;
    var obj2_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t349__95__ampersandNumParams__95__test_13");
      this.outer_t349__95__ampersandNumParams__95__test_13 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv) {     // accessor method a
        return GraceTrue;
      };    // end of method a
      this.methods["a"] = func3;
      func3.paramCounts = [0];
      func3.paramNames = [];
      func3.typeParamNames = [];
      func3.definitionLine = 14;
      func3.definitionModule = "t349_ampersandNumParams_test";
      var func4 = function(argcv, var_bool) {     // accessor method a(1)
        return var_bool;
      };    // end of method a(_)
      func4.paramTypes = [];
      func4.paramTypes.push([type_Boolean, "bool"]);
      this.methods["a(1)"] = func4;
      func4.paramCounts = [1];
      func4.paramNames = ["bool"];
      func4.typeParamNames = [];
      func4.definitionLine = 15;
      func4.definitionModule = "t349_ampersandNumParams_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 13
        setModuleName("t349_ampersandNumParams_test");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method ampersandA$build(_,_,_)
  this.methods["ampersandA$build(3)"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 13;
  func1.definitionModule = "t349_ampersandNumParams_test";
  setLineNumber(3);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit6 = new GraceType("A");
  typeLit6.typeMethods.push("a");
  var var_A = typeLit6;
  var type5 = typeLit6;
  var func7 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func7;
  func7.paramCounts = [0];
  func7.paramNames = [];
  func7.typeParamNames = [];
  func7.definitionLine = 1;
  func7.definitionModule = "t349_ampersandNumParams_test";
  setLineNumber(7);    // compilenode typedec
  // Type decl B
  //   Type literal 
  var typeLit9 = new GraceType("B");
  typeLit9.typeMethods.push("a(1)");
  var var_B = typeLit9;
  var type8 = typeLit9;
  var func10 = function(argcv) {     // accessor method B
    return var_B;
  };    // end of method B
  this.methods["B"] = func10;
  func10.paramCounts = [0];
  func10.paramNames = [];
  func10.typeParamNames = [];
  func10.definitionLine = 1;
  func10.definitionModule = "t349_ampersandNumParams_test";
  setLineNumber(11);    // compilenode typedec
  // Type decl C
  var opresult12 = request(var_A, "&(1)", [1], var_B);
  var var_C = opresult12;
  var type11 = opresult12;
  var func13 = function(argcv) {     // accessor method C
    return var_C;
  };    // end of method C
  this.methods["C"] = func13;
  func13.paramCounts = [0];
  func13.paramNames = [];
  func13.typeParamNames = [];
  func13.definitionLine = 1;
  func13.definitionModule = "t349_ampersandNumParams_test";
  setLineNumber(18);    // compilenode member
  // call case 4: self request
  var call14 = selfRequest(this, "ampersandA", [0]);
  var var_x = call14;
  var reader15_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader15_x.isDef = true;
  reader15_x.confidential = true;
  this.methods["x"] = reader15_x;
  assertTypeOrMsg(var_x, var_C, "value of def x", "C");
  setLineNumber(19);    // compilenode member
  // call case 6: other requests
  if (var_x === undefined) raiseUninitializedVariable("x");
  var call16 = request(var_x, "a", [0]);
  Grace_print(call16);
  setLineNumber(20);    // compilenode call
  // call case 6: other requests
  if (var_x === undefined) raiseUninitializedVariable("x");
  var call17 = request(var_x, "a(1)", [1], GraceFalse);
  Grace_print(call17);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t349__95__ampersandNumParams__95__test = gracecode_t349__95__ampersandNumParams__95__test;
if (typeof window !== "undefined")
  window.gracecode_t349__95__ampersandNumParams__95__test = gracecode_t349__95__ampersandNumParams__95__test;
gracecode_t349__95__ampersandNumParams__95__test.imports = ["StaticTyping"];
