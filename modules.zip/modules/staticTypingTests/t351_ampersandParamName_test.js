;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t351_ampersandParamName_test"] = "classes:\nconfidential:\n x\ndialect:\n StaticTyping\nfresh-methods:\n ampersandA\nfresh:ampersandA:\n a(1)\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t351_ampersandParamName_test.grace\npublic:\n A\n B\n C\n ampersandA\npublicMethod:ampersandA:\n ampersandA \u2192 C\npublicMethodTypes:\n ampersandA \u2192 C\ntypedec-of:A:\n type A = interface {\n            a(name1:String) \u2192 String}\ntypedec-of:B:\n type B = interface {\n            a(name2:String) \u2192 String}\ntypedec-of:C:\n type C = A & B\ntypes:\n A\n B\n C\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t351_ampersandParamName_test"] = [
    "dialect \"StaticTyping\"",
    "//Tests that the names given to parameters in a method do not affect those",
    "//methods' compatibility to be ampersanded together.",
    "",
    "type A = {",
    "    a(name1: String) -> String",
    "}",
    "type B = {",
    "    a(name2: String) -> String",
    "}",
    "type C = A & B",
    "",
    "class ampersandA -> C {",
    "    method a (anyName: String) -> String { anyName }",
    "}",
    "",
    "def x : C = ampersandA",
    "print (x.a(\"test succeeded\"))" ];
}
function gracecode_t351__95__ampersandParamName__95__test() {
  setModuleName("t351_ampersandParamName_test");
  importedModules["t351_ampersandParamName_test"] = this;
  var module$t351__95__ampersandParamName__95__test = this;
  this.definitionModule = "t351_ampersandParamName_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t351__95__ampersandParamName__95__test_0");
  this.outer_t351__95__ampersandParamName__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method ampersandA, line 13
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("ampersandA", "t351_ampersandParamName_test", 13);
    var ouc_init = this.methods["ampersandA$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_C, "object returned from ampersandA", "C");
    return ouc;
  };    // end of method ampersandA
  this.methods["ampersandA"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 13;
  func0.definitionModule = "t351_ampersandParamName_test";
  var func1 = function(argcv, inheritingObject, aliases, exclusions) {    // method ampersandA$build(_,_,_), line 13
    var returnTarget = invocationCount;
    invocationCount++;
    var obj2_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t351__95__ampersandParamName__95__test_13");
      this.outer_t351__95__ampersandParamName__95__test_13 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv, var_anyName) {     // accessor method a(1)
        return var_anyName;
      };    // end of method a(_)
      func3.paramTypes = [];
      func3.paramTypes.push([type_String, "anyName"]);
      this.methods["a(1)"] = func3;
      func3.paramCounts = [1];
      func3.paramNames = ["anyName"];
      func3.typeParamNames = [];
      func3.definitionLine = 14;
      func3.definitionModule = "t351_ampersandParamName_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 13
        setModuleName("t351_ampersandParamName_test");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method ampersandA$build(_,_,_)
  this.methods["ampersandA$build(3)"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 13;
  func1.definitionModule = "t351_ampersandParamName_test";
  setLineNumber(5);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit5 = new GraceType("A");
  typeLit5.typeMethods.push("a(1)");
  var var_A = typeLit5;
  var type4 = typeLit5;
  var func6 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func6;
  func6.paramCounts = [0];
  func6.paramNames = [];
  func6.typeParamNames = [];
  func6.definitionLine = 1;
  func6.definitionModule = "t351_ampersandParamName_test";
  setLineNumber(8);    // compilenode typedec
  // Type decl B
  //   Type literal 
  var typeLit8 = new GraceType("B");
  typeLit8.typeMethods.push("a(1)");
  var var_B = typeLit8;
  var type7 = typeLit8;
  var func9 = function(argcv) {     // accessor method B
    return var_B;
  };    // end of method B
  this.methods["B"] = func9;
  func9.paramCounts = [0];
  func9.paramNames = [];
  func9.typeParamNames = [];
  func9.definitionLine = 1;
  func9.definitionModule = "t351_ampersandParamName_test";
  setLineNumber(11);    // compilenode typedec
  // Type decl C
  var opresult11 = request(var_A, "&(1)", [1], var_B);
  var var_C = opresult11;
  var type10 = opresult11;
  var func12 = function(argcv) {     // accessor method C
    return var_C;
  };    // end of method C
  this.methods["C"] = func12;
  func12.paramCounts = [0];
  func12.paramNames = [];
  func12.typeParamNames = [];
  func12.definitionLine = 1;
  func12.definitionModule = "t351_ampersandParamName_test";
  setLineNumber(17);    // compilenode member
  // call case 4: self request
  var call13 = selfRequest(this, "ampersandA", [0]);
  var var_x = call13;
  var reader14_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader14_x.isDef = true;
  reader14_x.confidential = true;
  this.methods["x"] = reader14_x;
  assertTypeOrMsg(var_x, var_C, "value of def x", "C");
  setLineNumber(18);    // compilenode string
  var string16 = new GraceString("test succeeded");
  // call case 6: other requests
  if (var_x === undefined) raiseUninitializedVariable("x");
  var call15 = request(var_x, "a(1)", [1], string16);
  Grace_print(call15);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t351__95__ampersandParamName__95__test = gracecode_t351__95__ampersandParamName__95__test;
if (typeof window !== "undefined")
  window.gracecode_t351__95__ampersandParamName__95__test = gracecode_t351__95__ampersandParamName__95__test;
gracecode_t351__95__ampersandParamName__95__test.imports = ["StaticTyping"];
