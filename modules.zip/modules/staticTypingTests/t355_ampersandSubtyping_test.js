;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t355_ampersandSubtyping_test"] = "classes:\nconfidential:\ndialect:\n StaticTyping\nfresh-methods:\n st\nfresh:st:\n s\n t\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t355_ampersandSubtyping_test.grace\npublic:\n S\n T\n U\n q(1)\n st\npublicMethod:q(1):\n q(param:S & T) \u2192 U\npublicMethod:st:\n st \u2192 S & T\npublicMethodTypes:\n q(param:S & T) \u2192 U\n st \u2192 S & T\ntypedec-of:S:\n type S = interface {\n            s \u2192 Number}\ntypedec-of:T:\n type T = interface {\n            s \u2192 Number\n            t \u2192 String}\ntypedec-of:U:\n type U = interface {\n            s \u2192 Number\n            t \u2192 String}\ntypes:\n S\n T\n U\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t355_ampersandSubtyping_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "type S = {",
    "    s -> Number",
    "}",
    "",
    "type T = {",
    "    s -> Number",
    "    t -> String",
    "}",
    "",
    "type U = {",
    "    s -> Number",
    "    t -> String",
    "}",
    "",
    "class st -> S & T {",
    "    method s -> Number { 47 }",
    "    method t -> String { \"Hello World\" }",
    "}",
    "",
    "method q(param : S & T) -> U {param}",
    "",
    "print (q(st).t)" ];
}
function gracecode_t355__95__ampersandSubtyping__95__test() {
  setModuleName("t355_ampersandSubtyping_test");
  importedModules["t355_ampersandSubtyping_test"] = this;
  var module$t355__95__ampersandSubtyping__95__test = this;
  this.definitionModule = "t355_ampersandSubtyping_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t355__95__ampersandSubtyping__95__test_0");
  this.outer_t355__95__ampersandSubtyping__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method st, line 17
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("st", "t355_ampersandSubtyping_test", 17);
    var ouc_init = this.methods["st$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(17);    // compilenode op
    var opresult1 = request(var_S, "&(1)", [1], var_T);
    setLineNumber(22);    // typecheck
    assertTypeOrMsg(ouc, opresult1, "object returned from st", "S & T");
    return ouc;
  };    // end of method st
  this.methods["st"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 17;
  func0.definitionModule = "t355_ampersandSubtyping_test";
  var func2 = function(argcv, inheritingObject, aliases, exclusions) {    // method st$build(_,_,_), line 17
    var returnTarget = invocationCount;
    invocationCount++;
    var obj3_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t355__95__ampersandSubtyping__95__test_17");
      this.outer_t355__95__ampersandSubtyping__95__test_17 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func4 = function(argcv) {    // method s, line 18
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t355_ampersandSubtyping_test");
        setLineNumber(18);    // typecheck
        assertTypeOrMsg(new GraceNum(47), var_Number, "result of method s", "Number");
        return new GraceNum(47);
      };    // end of method s
      this.methods["s"] = func4;
      func4.paramCounts = [0];
      func4.paramNames = [];
      func4.typeParamNames = [];
      func4.definitionLine = 18;
      func4.definitionModule = "t355_ampersandSubtyping_test";
      var func5 = function(argcv) {    // method t, line 19
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("t355_ampersandSubtyping_test");
        setLineNumber(19);    // compilenode string
        var string6 = new GraceString("Hello World");
        assertTypeOrMsg(string6, var_String, "result of method t", "String");
        return string6;
      };    // end of method t
      this.methods["t"] = func5;
      func5.paramCounts = [0];
      func5.paramNames = [];
      func5.typeParamNames = [];
      func5.definitionLine = 19;
      func5.definitionModule = "t355_ampersandSubtyping_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj3_init = function() {    // init of object on line 17
        setModuleName("t355_ampersandSubtyping_test");
      };
      return obj3_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj3_init = obj3_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj3_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method st$build(_,_,_)
  this.methods["st$build(3)"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 17;
  func2.definitionModule = "t355_ampersandSubtyping_test";
  var func7 = function(argcv, var_param) {     // accessor method q(1)
    return var_param;
  };    // end of method q(_)
  this.methods["q(1)"] = func7;
  func7.paramCounts = [1];
  func7.paramNames = ["param"];
  func7.typeParamNames = [];
  func7.definitionLine = 22;
  func7.definitionModule = "t355_ampersandSubtyping_test";
  setLineNumber(3);    // compilenode typedec
  // Type decl S
  //   Type literal 
  var typeLit9 = new GraceType("S");
  typeLit9.typeMethods.push("s");
  var var_S = typeLit9;
  var type8 = typeLit9;
  var func10 = function(argcv) {     // accessor method S
    return var_S;
  };    // end of method S
  this.methods["S"] = func10;
  func10.paramCounts = [0];
  func10.paramNames = [];
  func10.typeParamNames = [];
  func10.definitionLine = 1;
  func10.definitionModule = "t355_ampersandSubtyping_test";
  setLineNumber(7);    // compilenode typedec
  // Type decl T
  //   Type literal 
  var typeLit12 = new GraceType("T");
  typeLit12.typeMethods.push("s");
  typeLit12.typeMethods.push("t");
  var var_T = typeLit12;
  var type11 = typeLit12;
  var func13 = function(argcv) {     // accessor method T
    return var_T;
  };    // end of method T
  this.methods["T"] = func13;
  func13.paramCounts = [0];
  func13.paramNames = [];
  func13.typeParamNames = [];
  func13.definitionLine = 1;
  func13.definitionModule = "t355_ampersandSubtyping_test";
  setLineNumber(12);    // compilenode typedec
  // Type decl U
  //   Type literal 
  var typeLit15 = new GraceType("U");
  typeLit15.typeMethods.push("s");
  typeLit15.typeMethods.push("t");
  var var_U = typeLit15;
  var type14 = typeLit15;
  var func16 = function(argcv) {     // accessor method U
    return var_U;
  };    // end of method U
  this.methods["U"] = func16;
  func16.paramCounts = [0];
  func16.paramNames = [];
  func16.typeParamNames = [];
  func16.definitionLine = 1;
  func16.definitionModule = "t355_ampersandSubtyping_test";
  setLineNumber(24);    // compilenode member
  // call case 6: other requests
  // call case 4: self request
  var call19 = selfRequest(this, "st", [0]);
  // call case 2: outer request
  var call18 = selfRequest(importedModules["t355_ampersandSubtyping_test"], "q(1)", [1], call19);
  var call17 = request(call18, "t", [0]);
  Grace_print(call17);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t355__95__ampersandSubtyping__95__test = gracecode_t355__95__ampersandSubtyping__95__test;
if (typeof window !== "undefined")
  window.gracecode_t355__95__ampersandSubtyping__95__test = gracecode_t355__95__ampersandSubtyping__95__test;
gracecode_t355__95__ampersandSubtyping__95__test.imports = ["StaticTyping"];
