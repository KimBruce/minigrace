;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t357_ampersandMultParams_test"] = "classes:\nconfidential:\n x\ndialect:\n StaticTyping\nfresh-methods:\n ampersandA\nfresh:ampersandA:\n a(1)\n a(2)\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t357_ampersandMultParams_test.grace\npublic:\n A\n B\n C\n ampersandA\npublicMethod:ampersandA:\n ampersandA \u2192 C\npublicMethodTypes:\n ampersandA \u2192 C\ntypedec-of:A:\n type A = interface {\n            a(b:Boolean, n:Number) \u2192 Boolean}\ntypedec-of:B:\n type B = interface {\n            a(b:Boolean) \u2192 Boolean}\ntypedec-of:C:\n type C = A & B\ntypes:\n A\n B\n C\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t357_ampersandMultParams_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "type A = {",
    "    a(b : Boolean, n: Number) -> Boolean",
    "}",
    "type B = {",
    "    a(b : Boolean)-> Boolean",
    "}",
    "type C = A & B",
    "",
    "class ampersandA -> C {",
    "    method a(b: Boolean) -> Boolean { b }",
    "    method a(b: Boolean, n: Number) -> Boolean { b.not }",
    "}",
    "",
    "def x : C = ampersandA",
    "",
    "print (x.a(true))",
    "print (x.a(true, 47))" ];
}
function gracecode_t357__95__ampersandMultParams__95__test() {
  setModuleName("t357_ampersandMultParams_test");
  importedModules["t357_ampersandMultParams_test"] = this;
  var module$t357__95__ampersandMultParams__95__test = this;
  this.definitionModule = "t357_ampersandMultParams_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t357__95__ampersandMultParams__95__test_0");
  this.outer_t357__95__ampersandMultParams__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method ampersandA, line 11
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("ampersandA", "t357_ampersandMultParams_test", 11);
    var ouc_init = this.methods["ampersandA$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_C, "object returned from ampersandA", "C");
    return ouc;
  };    // end of method ampersandA
  this.methods["ampersandA"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 11;
  func0.definitionModule = "t357_ampersandMultParams_test";
  var func1 = function(argcv, inheritingObject, aliases, exclusions) {    // method ampersandA$build(_,_,_), line 11
    var returnTarget = invocationCount;
    invocationCount++;
    var obj2_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t357__95__ampersandMultParams__95__test_11");
      this.outer_t357__95__ampersandMultParams__95__test_11 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv, var_b) {     // accessor method a(1)
        return var_b;
      };    // end of method a(_)
      func3.paramTypes = [];
      func3.paramTypes.push([type_Boolean, "b"]);
      this.methods["a(1)"] = func3;
      func3.paramCounts = [1];
      func3.paramNames = ["b"];
      func3.typeParamNames = [];
      func3.definitionLine = 12;
      func3.definitionModule = "t357_ampersandMultParams_test";
      var func4 = function(argcv, var_b, var_n) {    // method a(_,_), line 13
        var returnTarget = invocationCount;
        invocationCount++;
        assertTypeOrMsg(var_b, var_Boolean, "argument 1 in request of `a(_,_)`", "Boolean");
        assertTypeOrMsg(var_n, var_Number, "argument 2 in request of `a(_,_)`", "Number");
        setModuleName("t357_ampersandMultParams_test");
        setLineNumber(13);    // compilenode member
        // call case 6: other requests
        var call5 = request(var_b, "not", [0]);
        assertTypeOrMsg(call5, var_Boolean, "result of method a(_,_)", "Boolean");
        return call5;
      };    // end of method a(_,_)
      func4.paramTypes = [];
      func4.paramTypes.push([type_Boolean, "b"]);
      func4.paramTypes.push([type_Number, "n"]);
      this.methods["a(2)"] = func4;
      func4.paramCounts = [2];
      func4.paramNames = ["b", "n"];
      func4.typeParamNames = [];
      func4.definitionLine = 13;
      func4.definitionModule = "t357_ampersandMultParams_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 11
        setModuleName("t357_ampersandMultParams_test");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method ampersandA$build(_,_,_)
  this.methods["ampersandA$build(3)"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 11;
  func1.definitionModule = "t357_ampersandMultParams_test";
  setLineNumber(3);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit7 = new GraceType("A");
  typeLit7.typeMethods.push("a(2)");
  var var_A = typeLit7;
  var type6 = typeLit7;
  var func8 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func8;
  func8.paramCounts = [0];
  func8.paramNames = [];
  func8.typeParamNames = [];
  func8.definitionLine = 1;
  func8.definitionModule = "t357_ampersandMultParams_test";
  setLineNumber(6);    // compilenode typedec
  // Type decl B
  //   Type literal 
  var typeLit10 = new GraceType("B");
  typeLit10.typeMethods.push("a(1)");
  var var_B = typeLit10;
  var type9 = typeLit10;
  var func11 = function(argcv) {     // accessor method B
    return var_B;
  };    // end of method B
  this.methods["B"] = func11;
  func11.paramCounts = [0];
  func11.paramNames = [];
  func11.typeParamNames = [];
  func11.definitionLine = 1;
  func11.definitionModule = "t357_ampersandMultParams_test";
  setLineNumber(9);    // compilenode typedec
  // Type decl C
  var opresult13 = request(var_A, "&(1)", [1], var_B);
  var var_C = opresult13;
  var type12 = opresult13;
  var func14 = function(argcv) {     // accessor method C
    return var_C;
  };    // end of method C
  this.methods["C"] = func14;
  func14.paramCounts = [0];
  func14.paramNames = [];
  func14.typeParamNames = [];
  func14.definitionLine = 1;
  func14.definitionModule = "t357_ampersandMultParams_test";
  setLineNumber(16);    // compilenode member
  // call case 4: self request
  var call15 = selfRequest(this, "ampersandA", [0]);
  var var_x = call15;
  var reader16_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader16_x.isDef = true;
  reader16_x.confidential = true;
  this.methods["x"] = reader16_x;
  assertTypeOrMsg(var_x, var_C, "value of def x", "C");
  setLineNumber(18);    // compilenode call
  // call case 6: other requests
  if (var_x === undefined) raiseUninitializedVariable("x");
  var call17 = request(var_x, "a(1)", [1], GraceTrue);
  Grace_print(call17);
  setLineNumber(19);    // compilenode num
  // call case 6: other requests
  if (var_x === undefined) raiseUninitializedVariable("x");
  var call18 = request(var_x, "a(2)", [2], GraceTrue, new GraceNum(47));
  Grace_print(call18);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t357__95__ampersandMultParams__95__test = gracecode_t357__95__ampersandMultParams__95__test;
if (typeof window !== "undefined")
  window.gracecode_t357__95__ampersandMultParams__95__test = gracecode_t357__95__ampersandMultParams__95__test;
gracecode_t357__95__ampersandMultParams__95__test.imports = ["StaticTyping"];
