;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["t361a_generics_test"] = "classes:\nconfidential:\n x\ndialect:\n StaticTyping\nfresh-methods:\n d\nfresh:d:\n m(1)\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/t361a_generics_test.grace\npublic:\n D\n d\npublicMethod:d:\n d \u2192 D\u27e6Number\u27e7\npublicMethodTypes:\n d \u2192 D\u27e6Number\u27e7\ntypedec-of:D\u27e6K\u27e7:\n type D\u27e6K\u27e7 = interface {\n            m(k:K) \u2192 K}\ntypes:\n D\u27e6K\u27e7\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["t361a_generics_test"] = [
    "dialect \"StaticTyping\"",
    "type D⟦K⟧ = {",
    "    m(k:K) → K",
    "}",
    "class d → D⟦Number⟧ {",
    "    method m(n:Number) → Number { n + 47 }",
    "}",
    "",
    "def x : D⟦Number⟧ = d",
    "print (x.m(3))" ];
}
function gracecode_t361a__95__generics__95__test() {
  setModuleName("t361a_generics_test");
  importedModules["t361a_generics_test"] = this;
  var module$t361a__95__generics__95__test = this;
  this.definitionModule = "t361a_generics_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_t361a__95__generics__95__test_0");
  this.outer_t361a__95__generics__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method d, line 5
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("d", "t361a_generics_test", 5);
    var ouc_init = this.methods["d$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_D, "object returned from d", "D");
    return ouc;
  };    // end of method d
  this.methods["d"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 5;
  func0.definitionModule = "t361a_generics_test";
  var func1 = function(argcv, inheritingObject, aliases, exclusions) {    // method d$build(_,_,_), line 5
    var returnTarget = invocationCount;
    invocationCount++;
    var obj2_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_t361a__95__generics__95__test_5");
      this.outer_t361a__95__generics__95__test_5 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv, var_n) {    // method m(_), line 6
        var returnTarget = invocationCount;
        invocationCount++;
        assertTypeOrMsg(var_n, var_Number, "argument to request of `m(_)`", "Number");
        setModuleName("t361a_generics_test");
        setLineNumber(6);    // compilenode num
        var sum4 = request(var_n, "+(1)", [1], new GraceNum(47));
        assertTypeOrMsg(sum4, var_Number, "result of method m(_)", "Number");
        return sum4;
      };    // end of method m(_)
      func3.paramTypes = [];
      func3.paramTypes.push([type_Number, "n"]);
      this.methods["m(1)"] = func3;
      func3.paramCounts = [1];
      func3.paramNames = ["n"];
      func3.typeParamNames = [];
      func3.definitionLine = 6;
      func3.definitionModule = "t361a_generics_test";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 5
        setModuleName("t361a_generics_test");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method d$build(_,_,_)
  this.methods["d$build(3)"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 5;
  func1.definitionModule = "t361a_generics_test";
  setLineNumber(2);    // compilenode typedec
  // Type decl D
  //   Type literal 
  var typeLit6 = new GraceType("D");
  typeLit6.typeMethods.push("m(1)");
  var var_D = typeLit6;
  var type5 = typeLit6;
  var func7 = function(argcv) {     // accessor method D
    return var_D;
  };    // end of method D
  this.methods["D"] = func7;
  func7.paramCounts = [0];
  func7.paramNames = [];
  func7.typeParamNames = [];
  func7.definitionLine = 1;
  func7.definitionModule = "t361a_generics_test";
  setLineNumber(9);    // compilenode member
  // call case 4: self request
  var call8 = selfRequest(this, "d", [0]);
  var var_x = call8;
  var reader9_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader9_x.isDef = true;
  reader9_x.confidential = true;
  this.methods["x"] = reader9_x;
  assertTypeOrMsg(var_x, var_D, "value of def x", "D");
  setLineNumber(10);    // compilenode num
  // call case 6: other requests
  if (var_x === undefined) raiseUninitializedVariable("x");
  var call10 = request(var_x, "m(1)", [1], new GraceNum(3));
  Grace_print(call10);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_t361a__95__generics__95__test = gracecode_t361a__95__generics__95__test;
if (typeof window !== "undefined")
  window.gracecode_t361a__95__generics__95__test = gracecode_t361a__95__generics__95__test;
gracecode_t361a__95__generics__95__test.imports = ["StaticTyping"];
