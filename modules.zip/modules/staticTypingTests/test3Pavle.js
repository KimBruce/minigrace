;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["test3Pavle"] = "classes:\nconfidential:\n objectAlpha\n objectBeta\ndialect:\n StaticTyping\nfresh-methods:\n alpha\n beta\nfresh:alpha:\n n\nfresh:beta:\n m\n pavle\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/test3Pavle.grace\npublic:\n A\n B\n alpha\n beta\npublicMethod:alpha:\n alpha \u2192 A\npublicMethod:beta:\n beta \u2192 B\npublicMethodTypes:\n alpha \u2192 A\n beta \u2192 B\ntypedec-of:A:\n type A = interface {\n            n \u2192 Number}\ntypedec-of:B:\n type B = interface {\n            m \u2192 A}\ntypes:\n A\n B\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["test3Pavle"] = [
    "dialect \"StaticTyping\"",
    "",
    "type A = {",
    "    n -> Number",
    "}",
    "",
    "type B = {",
    "    m -> A",
    "}",
    "",
    "",
    "class alpha -> A {",
    "   method n -> Number{",
    "       return 47    ",
    "   }",
    "}",
    "",
    "",
    "class beta -> B {",
    "   def pavle:A = alpha",
    "   method m -> A {",
    "       return pavle",
    "   }",
    "}",
    "",
    "def objectAlpha:A = alpha",
    "def objectBeta:B = beta",
    "",
    "print (\"LOOOOOOOOOOOOOOK HEEEEEEEEEEREEEEEEEEEEEE {objectAlpha.n}\")" ];
}
function gracecode_test3Pavle() {
  setModuleName("test3Pavle");
  importedModules["test3Pavle"] = this;
  var module$test3Pavle = this;
  this.definitionModule = "test3Pavle";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_test3Pavle_0");
  this.outer_test3Pavle_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method alpha, line 12
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("alpha", "test3Pavle", 12);
    var ouc_init = this.methods["alpha$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(23);    // typecheck
    assertTypeOrMsg(ouc, var_A, "object returned from alpha", "A");
    return ouc;
  };    // end of method alpha
  this.methods["alpha"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 12;
  func0.definitionModule = "test3Pavle";
  var func1 = function(argcv, inheritingObject, aliases, exclusions) {    // method alpha$build(_,_,_), line 12
    var returnTarget = invocationCount;
    invocationCount++;
    var obj2_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_test3Pavle_12");
      this.outer_test3Pavle_12 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv) {    // method n, line 13
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("test3Pavle");
        setLineNumber(14);    // typecheck
        assertTypeOrMsg(new GraceNum(47), var_Number, "return value", "Number");
        return new GraceNum(47);
      };    // end of method n
      this.methods["n"] = func3;
      func3.paramCounts = [0];
      func3.paramNames = [];
      func3.typeParamNames = [];
      func3.definitionLine = 13;
      func3.definitionModule = "test3Pavle";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 12
        setModuleName("test3Pavle");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method alpha$build(_,_,_)
  this.methods["alpha$build(3)"] = func1;
  func1.paramCounts = [0];
  func1.paramNames = [];
  func1.typeParamNames = [];
  func1.definitionLine = 12;
  func1.definitionModule = "test3Pavle";
  var func4 = function(argcv) {    // method beta, line 19
    var returnTarget = invocationCount;
    invocationCount++;
    var ouc = emptyGraceObject("beta", "test3Pavle", 19);
    var ouc_init = this.methods["beta$build(3)"].call(this, null, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_B, "object returned from beta", "B");
    return ouc;
  };    // end of method beta
  this.methods["beta"] = func4;
  func4.paramCounts = [0];
  func4.paramNames = [];
  func4.typeParamNames = [];
  func4.definitionLine = 19;
  func4.definitionModule = "test3Pavle";
  var func5 = function(argcv, inheritingObject, aliases, exclusions) {    // method beta$build(_,_,_), line 19
    var returnTarget = invocationCount;
    invocationCount++;
    var obj6_build = function(ignore, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_test3Pavle_19");
      this.outer_test3Pavle_19 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      this.data.pavle = undefined;
      var reader7_pavle = function() {  // reader method pavle
          if (this.data.pavle === undefined) raiseUninitializedVariable("pavle");
          return this.data.pavle;
      };
      reader7_pavle.isDef = true;
      reader7_pavle.confidential = true;
      this.methods["pavle"] = reader7_pavle;
      var func8 = function(argcv) {    // method m, line 21
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("test3Pavle");
        setLineNumber(22);    // compilenode member
        // call case 4: self request
        var call9 = selfRequest(this, "pavle", [0]);
        assertTypeOrMsg(call9, var_A, "return value", "A");
        return call9;
      };    // end of method m
      this.methods["m"] = func8;
      func8.paramCounts = [0];
      func8.paramNames = [];
      func8.typeParamNames = [];
      func8.definitionLine = 21;
      func8.definitionModule = "test3Pavle";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj6_init = function() {    // init of object on line 19
        setModuleName("test3Pavle");
        setLineNumber(20);    // compilenode member
        // call case 2: outer request
        var call10 = selfRequest(importedModules["test3Pavle"], "alpha", [0]);
        assertTypeOrMsg(call10, var_A, "value bound to pavle", "A");
        this.data.pavle = call10;
      };
      return obj6_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj6_init = obj6_build.call(inheritingObject, null, this, aliases, exclusions);
    return obj6_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method beta$build(_,_,_)
  this.methods["beta$build(3)"] = func5;
  func5.paramCounts = [0];
  func5.paramNames = [];
  func5.typeParamNames = [];
  func5.definitionLine = 19;
  func5.definitionModule = "test3Pavle";
  setLineNumber(3);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit12 = new GraceType("A");
  typeLit12.typeMethods.push("n");
  var var_A = typeLit12;
  var type11 = typeLit12;
  var func13 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func13;
  func13.paramCounts = [0];
  func13.paramNames = [];
  func13.typeParamNames = [];
  func13.definitionLine = 1;
  func13.definitionModule = "test3Pavle";
  setLineNumber(7);    // compilenode typedec
  // Type decl B
  //   Type literal 
  var typeLit15 = new GraceType("B");
  typeLit15.typeMethods.push("m");
  var var_B = typeLit15;
  var type14 = typeLit15;
  var func16 = function(argcv) {     // accessor method B
    return var_B;
  };    // end of method B
  this.methods["B"] = func16;
  func16.paramCounts = [0];
  func16.paramNames = [];
  func16.typeParamNames = [];
  func16.definitionLine = 1;
  func16.definitionModule = "test3Pavle";
  setLineNumber(26);    // compilenode member
  // call case 4: self request
  var call17 = selfRequest(this, "alpha", [0]);
  var var_objectAlpha = call17;
  var reader18_objectAlpha = function() {  // reader method objectAlpha
      if (var_objectAlpha === undefined) raiseUninitializedVariable("objectAlpha");
      return var_objectAlpha;
  };
  reader18_objectAlpha.isDef = true;
  reader18_objectAlpha.confidential = true;
  this.methods["objectAlpha"] = reader18_objectAlpha;
  assertTypeOrMsg(var_objectAlpha, var_A, "value of def objectAlpha", "A");
  setLineNumber(27);    // compilenode member
  // call case 4: self request
  var call19 = selfRequest(this, "beta", [0]);
  var var_objectBeta = call19;
  var reader20_objectBeta = function() {  // reader method objectBeta
      if (var_objectBeta === undefined) raiseUninitializedVariable("objectBeta");
      return var_objectBeta;
  };
  reader20_objectBeta.isDef = true;
  reader20_objectBeta.confidential = true;
  this.methods["objectBeta"] = reader20_objectBeta;
  assertTypeOrMsg(var_objectBeta, var_B, "value of def objectBeta", "B");
  setLineNumber(29);    // compilenode string
  var string21 = new GraceString("LOOOOOOOOOOOOOOK HEEEEEEEEEEREEEEEEEEEEEE ");
  // call case 6: other requests
  if (var_objectAlpha === undefined) raiseUninitializedVariable("objectAlpha");
  var call22 = request(var_objectAlpha, "n", [0]);
  var opresult23 = request(string21, "++(1)", [1], call22);
  var string24 = new GraceString("");
  var opresult25 = request(opresult23, "++(1)", [1], string24);
  Grace_print(opresult25);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_test3Pavle = gracecode_test3Pavle;
if (typeof window !== "undefined")
  window.gracecode_test3Pavle = gracecode_test3Pavle;
gracecode_test3Pavle.imports = ["StaticTyping"];
