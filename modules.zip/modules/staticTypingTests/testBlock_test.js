;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["testBlock_test"] = "classes:\nconfidential:\n blk\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/testBlock_test.grace\npublic:\n Block\npublicMethodTypes:\ntypedec-of:Block:\n type Block = interface {\n            apply(x:Number) \u2192 Number}\ntypes:\n Block\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["testBlock_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "type Block = {apply(x: Number) → Number}",
    "",
    "def blk:Block = {x: Number → 2*x}",
    "",
    "print (blk.apply(5))" ];
}
function gracecode_testBlock__95__test() {
  setModuleName("testBlock_test");
  importedModules["testBlock_test"] = this;
  var module$testBlock__95__test = this;
  this.definitionModule = "testBlock_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_testBlock__95__test_0");
  this.outer_testBlock__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(3);    // compilenode typedec
  // Type decl Block
  //   Type literal 
  var typeLit1 = new GraceType("Block");
  typeLit1.typeMethods.push("apply(1)");
  var var_Block = typeLit1;
  var type0 = typeLit1;
  var func2 = function(argcv) {     // accessor method Block
    return var_Block;
  };    // end of method Block
  this.methods["Block"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 1;
  func2.definitionModule = "testBlock_test";
  setLineNumber(5);    // compilenode block
  var block3 = new GraceBlock(this, 5, 1);
  block3.paramTypes = [var_Number];
  var matches4 = function(var_x) {
    setModuleName("testBlock_test");
    if (!Grace_isTrue(request(var_Number, "match(1)", [1], var_x)))
        return false;
    return true;
  };
  block3.guard = matches4;
  block3.real = function(var_x) {
    setModuleName("testBlock_test");
    setLineNumber(5);    // compilenode num
    var prod5 = request(new GraceNum(2), "*(1)", [1], var_x);
    return prod5;
  };
  var var_blk = block3;
  var reader6_blk = function() {  // reader method blk
      if (var_blk === undefined) raiseUninitializedVariable("blk");
      return var_blk;
  };
  reader6_blk.isDef = true;
  reader6_blk.confidential = true;
  this.methods["blk"] = reader6_blk;
  assertTypeOrMsg(var_blk, var_Block, "value of def blk", "Block");
  setLineNumber(7);    // compilenode num
  // call case 6: other requests
  if (var_blk === undefined) raiseUninitializedVariable("blk");
  var call7 = request(var_blk, "apply(1)", [1], new GraceNum(5));
  Grace_print(call7);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_testBlock__95__test = gracecode_testBlock__95__test;
if (typeof window !== "undefined")
  window.gracecode_testBlock__95__test = gracecode_testBlock__95__test;
gracecode_testBlock__95__test.imports = ["StaticTyping"];
