;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["testConfidential_test"] = "classes:\nconfidential:\n a\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/testConfidential_test.grace\npublic:\n A\npublicMethodTypes:\ntypedec-of:A:\n type A = interface {\n            m \u2192 Number}\ntypes:\n A\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["testConfidential_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "// Need to put in a second SelfType (that is not public)",
    "// to provide the type of \"self\".  It will include \"isMe\"",
    "// and all other confidential methods of \"self\"",
    "type A = {",
    "    m → Number",
    "}",
    "",
    "def a: A = object {",
    "    method m → Number {n}",
    "    method n → Number is confidential {",
    "        if (isMe(a)) then {47} else {-20}",
    "    }",
    "}",
    "",
    "// a.isMe(a)  //Properly not recognized",
    "",
    "print (a.m)" ];
}
function gracecode_testConfidential__95__test() {
  setModuleName("testConfidential_test");
  importedModules["testConfidential_test"] = this;
  var module$testConfidential__95__test = this;
  this.definitionModule = "testConfidential_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_testConfidential__95__test_0");
  this.outer_testConfidential__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(6);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit1 = new GraceType("A");
  typeLit1.typeMethods.push("m");
  var var_A = typeLit1;
  var type0 = typeLit1;
  var func2 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func2;
  func2.paramCounts = [0];
  func2.paramNames = [];
  func2.typeParamNames = [];
  func2.definitionLine = 1;
  func2.definitionModule = "testConfidential_test";
  setLineNumber(10);    // compilenode object
  var obj3_build = function(ignore, outerObj, aliases, exclusions) {
    this.closureKeys = this.closureKeys || [];
    this.closureKeys.push("outer_testConfidential__95__test_10");
    this.outer_testConfidential__95__test_10 = outerObj;
    var inheritedExclusions = { };
    for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
        var exMeth = exclusions[eix];
        inheritedExclusions[exMeth] = this.methods[exMeth];
    }
    var func4 = function(argcv) {    // method m, line 11
      var returnTarget = invocationCount;
      invocationCount++;
      setModuleName("testConfidential_test");
      setLineNumber(11);    // compilenode member
      // call case 4: self request
      var call5 = selfRequest(this, "n", [0]);
      assertTypeOrMsg(call5, var_Number, "result of method m", "Number");
      return call5;
    };    // end of method m
    this.methods["m"] = func4;
    func4.paramCounts = [0];
    func4.paramNames = [];
    func4.typeParamNames = [];
    func4.definitionLine = 11;
    func4.definitionModule = "testConfidential_test";
    var func6 = function(argcv) {    // method n, line 12
      var returnTarget = invocationCount;
      invocationCount++;
      setModuleName("testConfidential_test");
      var if7 = GraceDone;
      setLineNumber(13);    // compilenode call
      if (var_a === undefined) raiseUninitializedVariable("a");
      // call case 4: self request
      var call8 = selfRequest(this, "isMe(1)", [1], var_a);
      if (Grace_isTrue(call8)) {
        if7 = new GraceNum(47);
      } else {
        // call case 6: other requests
        var call9 = request(new GraceNum(20), "prefix-", [0]);
        if7 = call9;
      }
      assertTypeOrMsg(if7, var_Number, "result of method n", "Number");
      return if7;
    };    // end of method n
    func6.confidential = true;
    this.methods["n"] = func6;
    func6.paramCounts = [0];
    func6.paramNames = [];
    func6.typeParamNames = [];
    func6.definitionLine = 12;
    func6.definitionModule = "testConfidential_test";
    for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
        var oneAlias = aliases[aix];
        this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
    }
    for (var exName in inheritedExclusions) {
        if (inheritedExclusions.hasOwnProperty(exName)) {
            if (inheritedExclusions[exName]) {
                this.methods[exName] = inheritedExclusions[exName];
            } else {
                delete this.methods[exName];
            }
        }
    }
    var obj3_init = function() {    // init of object on line 10
      setModuleName("testConfidential_test");
    };
    return obj3_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
  };
  var obj3 = emptyGraceObject("a", "testConfidential_test", 10);
  var obj3_init = obj3_build.call(obj3, null, this, [], []);
  obj3_init.call(obj3);  // end of compileobject
  var var_a = obj3;
  var reader10_a = function() {  // reader method a
      if (var_a === undefined) raiseUninitializedVariable("a");
      return var_a;
  };
  reader10_a.isDef = true;
  reader10_a.confidential = true;
  this.methods["a"] = reader10_a;
  setLineNumber(10);    // typecheck
  assertTypeOrMsg(var_a, var_A, "value of def a", "A");
  setLineNumber(19);    // compilenode member
  // call case 6: other requests
  if (var_a === undefined) raiseUninitializedVariable("a");
  var call11 = request(var_a, "m", [0]);
  Grace_print(call11);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_testConfidential__95__test = gracecode_testConfidential__95__test;
if (typeof window !== "undefined")
  window.gracecode_testConfidential__95__test = gracecode_testConfidential__95__test;
gracecode_testConfidential__95__test.imports = ["StaticTyping"];
