;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["testReturn_test"] = "classes:\nconfidential:\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/testReturn_test.grace\npublic:\n f(1)\npublicMethod:f(1):\n f(hh:Number) \u2192 Number\npublicMethodTypes:\n f(hh:Number) \u2192 Number\ntypes:\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["testReturn_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "method f(hh: Number) → Number {",
    "    if (hh == 0) then {",
    "        return 12}",
    "    hh*9",
    "}",
    "",
    "print (f(0))",
    "print \"f(1) is {f(1)}\"" ];
}
function gracecode_testReturn__95__test() {
  setModuleName("testReturn_test");
  importedModules["testReturn_test"] = this;
  var module$testReturn__95__test = this;
  this.definitionModule = "testReturn_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_testReturn__95__test_0");
  this.outer_testReturn__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv, var_hh) {    // method f(_), line 3
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_hh, var_Number, "argument to request of `f(_)`", "Number");
    setModuleName("testReturn_test");
    var if1 = GraceDone;
    setLineNumber(4);    // compilenode num
    var opresult2 = request(var_hh, "==(1)", [1], new GraceNum(0));
    if (Grace_isTrue(opresult2)) {
      setLineNumber(5);    // typecheck
      assertTypeOrMsg(new GraceNum(12), var_Number, "return value", "Number");
      return new GraceNum(12);
    }
    setLineNumber(6);    // compilenode num
    var prod3 = request(var_hh, "*(1)", [1], new GraceNum(9));
    assertTypeOrMsg(prod3, var_Number, "result of method f(_)", "Number");
    return prod3;
  };    // end of method f(_)
  func0.paramTypes = [];
  func0.paramTypes.push([type_Number, "hh"]);
  this.methods["f(1)"] = func0;
  func0.paramCounts = [1];
  func0.paramNames = ["hh"];
  func0.typeParamNames = [];
  func0.definitionLine = 3;
  func0.definitionModule = "testReturn_test";
  setLineNumber(9);    // compilenode num
  // call case 2: outer request
  var call4 = selfRequest(importedModules["testReturn_test"], "f(1)", [1], new GraceNum(0));
  Grace_print(call4);
  setLineNumber(10);    // compilenode string
  var string5 = new GraceString("f(1) is ");
  // call case 2: outer request
  var call6 = selfRequest(importedModules["testReturn_test"], "f(1)", [1], new GraceNum(1));
  var opresult7 = request(string5, "++(1)", [1], call6);
  var string8 = new GraceString("");
  var opresult9 = request(opresult7, "++(1)", [1], string8);
  Grace_print(opresult9);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_testReturn__95__test = gracecode_testReturn__95__test;
if (typeof window !== "undefined")
  window.gracecode_testReturn__95__test = gracecode_testReturn__95__test;
gracecode_testReturn__95__test.imports = ["StaticTyping"];
