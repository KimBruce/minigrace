;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["testid_test"] = "classes:\nconfidential:\n ifval\n m\n m:=(m': String) \u2192 Done\n n\n z\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/testid_test.grace\npublic:\n A\n q(1)\npublicMethod:q(1):\n q(k:Number) \u2192 Number\npublicMethodTypes:\n q(k:Number) \u2192 Number\ntypedec-of:A:\n type A = interface {\n            p(np:Number) \u2192 Number\n            const \u2192 Number\n            r \u2192 String\n            r:=(r':String) \u2192 Done}\ntypes:\n A\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["testid_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "def n: Number = 12",
    "",
    "var m: String := \"abc\"",
    "",
    "m := \"def\"",
    "",
    "method q(k: Number) → Number {k + 1}",
    "",
    "q(4)",
    "",
    "def ifval: Number = if (false) then {n} else {12}",
    "print (ifval)",
    "",
    "type A = {",
    "    p(np:Number) -> Number",
    "    const → Number",
    "    r → String",
    "    r:=(r':String) → Done",
    "}",
    "",
    "def z : A = object {",
    "    var r: String is public := \"zzz\"",
    "    def const: Number is public = 12",
    "    method p(nz:Number) -> Number {nz - const}",
    "}",
    "",
    "print (\"z.p(3) is {z.p(3)}\")",
    "print (z.const)",
    "print (z.r)",
    "z.r := \"aaa\"",
    "print (z.r)",
    "",
    "if (z.const > 0) then {print \"positive\"}" ];
}
function gracecode_testid__95__test() {
  setModuleName("testid_test");
  importedModules["testid_test"] = this;
  var module$testid__95__test = this;
  this.definitionModule = "testid_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_testid__95__test_0");
  this.outer_testid__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv, var_k) {    // method q(_), line 9
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_k, var_Number, "argument to request of `q(_)`", "Number");
    setModuleName("testid_test");
    setLineNumber(9);    // compilenode num
    var sum1 = request(var_k, "+(1)", [1], new GraceNum(1));
    assertTypeOrMsg(sum1, var_Number, "result of method q(_)", "Number");
    return sum1;
  };    // end of method q(_)
  func0.paramTypes = [];
  func0.paramTypes.push([type_Number, "k"]);
  this.methods["q(1)"] = func0;
  func0.paramCounts = [1];
  func0.paramNames = ["k"];
  func0.typeParamNames = [];
  func0.definitionLine = 9;
  func0.definitionModule = "testid_test";
  setLineNumber(3);    // compilenode num
  var var_n = new GraceNum(12);
  var reader2_n = function() {  // reader method n
      if (var_n === undefined) raiseUninitializedVariable("n");
      return var_n;
  };
  reader2_n.isDef = true;
  reader2_n.confidential = true;
  this.methods["n"] = reader2_n;
  assertTypeOrMsg(var_n, var_Number, "value of def n", "Number");
  setLineNumber(5);    // compilenode string
  var string3 = new GraceString("abc");
  assertTypeOrMsg(string3, var_String, "initial value of var m", "String");
  var var_m = string3;
  var reader4_m = function() {  // reader method m
      if (var_m === undefined) raiseUninitializedVariable("m");
      return var_m;
  };
  reader4_m.isVar = true;
  reader4_m.confidential = true;
  this.methods["m"] = reader4_m;
  var writer5_m = function(argcv, n) {   // writer method m:=(_)
    assertTypeOrMsg(n, var_String, "argument to m:=(_)", "String");
    var_m = n;
    return GraceDone;
  };
  writer5_m.confidential = true;
  this.methods["m:=(1)"] = writer5_m;
  setLineNumber(7);    // compilenode string
  var string6 = new GraceString("def");
  var_m = string6;
  setLineNumber(11);    // compilenode num
  // call case 2: outer request
  var call7 = selfRequest(importedModules["testid_test"], "q(1)", [1], new GraceNum(4));
  var if8 = GraceDone;
  setLineNumber(13);    // compilenode if
  if (Grace_isTrue(GraceFalse)) {
    if (var_n === undefined) raiseUninitializedVariable("n");
    if8 = var_n;
  } else {
    if8 = new GraceNum(12);
  }
  var var_ifval = if8;
  var reader9_ifval = function() {  // reader method ifval
      if (var_ifval === undefined) raiseUninitializedVariable("ifval");
      return var_ifval;
  };
  reader9_ifval.isDef = true;
  reader9_ifval.confidential = true;
  this.methods["ifval"] = reader9_ifval;
  assertTypeOrMsg(var_ifval, var_Number, "value of def ifval", "Number");
  setLineNumber(14);    // compilenode call
  if (var_ifval === undefined) raiseUninitializedVariable("ifval");
  Grace_print(var_ifval);
  setLineNumber(16);    // compilenode typedec
  // Type decl A
  //   Type literal 
  var typeLit11 = new GraceType("A");
  typeLit11.typeMethods.push("p(1)");
  typeLit11.typeMethods.push("const");
  typeLit11.typeMethods.push("r");
  typeLit11.typeMethods.push("r:=(1)");
  var var_A = typeLit11;
  var type10 = typeLit11;
  var func12 = function(argcv) {     // accessor method A
    return var_A;
  };    // end of method A
  this.methods["A"] = func12;
  func12.paramCounts = [0];
  func12.paramNames = [];
  func12.typeParamNames = [];
  func12.definitionLine = 1;
  func12.definitionModule = "testid_test";
  setLineNumber(23);    // compilenode object
  var obj13_build = function(ignore, outerObj, aliases, exclusions) {
    this.closureKeys = this.closureKeys || [];
    this.closureKeys.push("outer_testid__95__test_23");
    this.outer_testid__95__test_23 = outerObj;
    var inheritedExclusions = { };
    for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
        var exMeth = exclusions[eix];
        inheritedExclusions[exMeth] = this.methods[exMeth];
    }
    this.data.r = undefined;
    var reader14_r = function() {  // reader method r
        if (this.data.r === undefined) raiseUninitializedVariable("r");
        return this.data.r;
    };
    reader14_r.isVar = true;
    this.methods["r"] = reader14_r;
    var writer15_r = function(argcv, n) {   // writer method r:=(_)
      assertTypeOrMsg(n, var_String, "argument to r:=(_)", "String");
      this.data.r = n;
      return GraceDone;
    };
    this.methods["r:=(1)"] = writer15_r;
    this.data.const = undefined;
    var reader16_const = function() {  // reader method const
        if (this.data.const === undefined) raiseUninitializedVariable("const");
        return this.data.const;
    };
    reader16_const.isDef = true;
    this.methods["const"] = reader16_const;
    var func17 = function(argcv, var_nz) {    // method p(_), line 26
      var returnTarget = invocationCount;
      invocationCount++;
      assertTypeOrMsg(var_nz, var_Number, "argument to request of `p(_)`", "Number");
      setModuleName("testid_test");
      setLineNumber(26);    // compilenode member
      // call case 4: self request
      var call18 = selfRequest(this, "const", [0]);
      var diff19 = request(var_nz, "-(1)", [1], call18);
      assertTypeOrMsg(diff19, var_Number, "result of method p(_)", "Number");
      return diff19;
    };    // end of method p(_)
    func17.paramTypes = [];
    func17.paramTypes.push([type_Number, "nz"]);
    this.methods["p(1)"] = func17;
    func17.paramCounts = [1];
    func17.paramNames = ["nz"];
    func17.typeParamNames = [];
    func17.definitionLine = 26;
    func17.definitionModule = "testid_test";
    this.mutable = true;
    for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
        var oneAlias = aliases[aix];
        this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
    }
    for (var exName in inheritedExclusions) {
        if (inheritedExclusions.hasOwnProperty(exName)) {
            if (inheritedExclusions[exName]) {
                this.methods[exName] = inheritedExclusions[exName];
            } else {
                delete this.methods[exName];
            }
        }
    }
    var obj13_init = function() {    // init of object on line 23
      setModuleName("testid_test");
      setLineNumber(24);    // compilenode string
      var string20 = new GraceString("zzz");
      assertTypeOrMsg(string20, var_String, "value assigned to r", "String");
      this.data.r = string20;
      setLineNumber(25);    // typecheck
      assertTypeOrMsg(new GraceNum(12), var_Number, "value bound to const", "Number");
      this.data.const = new GraceNum(12);
    };
    return obj13_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
  };
  var obj13 = emptyGraceObject("z", "testid_test", 23);
  var obj13_init = obj13_build.call(obj13, null, this, [], []);
  obj13_init.call(obj13);  // end of compileobject
  var var_z = obj13;
  var reader21_z = function() {  // reader method z
      if (var_z === undefined) raiseUninitializedVariable("z");
      return var_z;
  };
  reader21_z.isDef = true;
  reader21_z.confidential = true;
  this.methods["z"] = reader21_z;
  setLineNumber(23);    // typecheck
  assertTypeOrMsg(var_z, var_A, "value of def z", "A");
  setLineNumber(29);    // compilenode string
  var string22 = new GraceString("z.p(3) is ");
  // call case 6: other requests
  if (var_z === undefined) raiseUninitializedVariable("z");
  var call23 = request(var_z, "p(1)", [1], new GraceNum(3));
  var opresult24 = request(string22, "++(1)", [1], call23);
  var string25 = new GraceString("");
  var opresult26 = request(opresult24, "++(1)", [1], string25);
  Grace_print(opresult26);
  setLineNumber(30);    // compilenode member
  // call case 6: other requests
  if (var_z === undefined) raiseUninitializedVariable("z");
  var call27 = request(var_z, "const", [0]);
  Grace_print(call27);
  setLineNumber(31);    // compilenode member
  // call case 6: other requests
  if (var_z === undefined) raiseUninitializedVariable("z");
  var call28 = request(var_z, "r", [0]);
  Grace_print(call28);
  setLineNumber(32);    // compilenode string
  var string30 = new GraceString("aaa");
  // call case 6: other requests
  if (var_z === undefined) raiseUninitializedVariable("z");
  var call29 = request(var_z, "r:=(1)", [1], string30);
  setLineNumber(33);    // compilenode member
  // call case 6: other requests
  if (var_z === undefined) raiseUninitializedVariable("z");
  var call31 = request(var_z, "r", [0]);
  Grace_print(call31);
  var if32 = GraceDone;
  setLineNumber(35);    // compilenode member
  // call case 6: other requests
  if (var_z === undefined) raiseUninitializedVariable("z");
  var call33 = request(var_z, "const", [0]);
  var opresult34 = request(call33, ">(1)", [1], new GraceNum(0));
  if (Grace_isTrue(opresult34)) {
    var string35 = new GraceString("positive");
    Grace_print(string35);
    if32 = GraceDone;
  }
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_testid__95__test = gracecode_testid__95__test;
if (typeof window !== "undefined")
  window.gracecode_testid__95__test = gracecode_testid__95__test;
gracecode_testid__95__test.imports = ["StaticTyping"];
