;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["tryExceptional"] = "classes:\nconfidential:\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/tryExceptional.grace\npublic:\n tryExceptional\npublicMethod:tryExceptional:\n tryExceptional \u2192 String | Done\npublicMethodTypes:\n tryExceptional \u2192 String | Done\ntypes:\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["tryExceptional"] = [
    "dialect \"StaticTyping\"",
    "",
    "method tryExceptional -> String | Done {",
    "    try {",
    "        ProgrammingError.raise \"an error occurred\"",
    "        \"hello\"",
    "    } catch {e: ProgrammingError ->",
    "        print (4)",
    "    }",
    "}" ];
}
function gracecode_tryExceptional() {
  setModuleName("tryExceptional");
  importedModules["tryExceptional"] = this;
  var module$tryExceptional = this;
  this.definitionModule = "tryExceptional";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_tryExceptional_0");
  this.outer_tryExceptional_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv) {    // method tryExceptional, line 3
    var returnTarget = invocationCount;
    invocationCount++;
    setModuleName("tryExceptional");
    setLineNumber(4);    // compilenode block
    var block2 = new GraceBlock(this, 4, 0);
    var matches3 = function() {
      setModuleName("tryExceptional");
      return true;
    };
    block2.guard = matches3;
    block2.real = function() {
      setModuleName("tryExceptional");
      setLineNumber(5);    // compilenode string
      var string5 = new GraceString("an error occurred");
      // call case 6: other requests
      // call case 2: outer request
      var call6 = selfRequest(var_prelude, "ProgrammingError", [0]);
      var call4 = request(call6, "raise(1)", [1], string5);
      setLineNumber(6);    // compilenode string
      var string7 = new GraceString("hello");
      return string7;
    };
    var cases1 = [];
    setLineNumber(7);    // compilenode block
    var block8 = new GraceBlock(this, 7, 1);
    // call case 2: outer request
    var call9 = selfRequest(var_prelude, "ProgrammingError", [0]);
    block8.paramTypes = [call9];
    var matches10 = function(var_e) {
      setModuleName("tryExceptional");
      // call case 2: outer request
      var call11 = selfRequest(var_prelude, "ProgrammingError", [0]);
      if (!Grace_isTrue(request(call11, "match(1)", [1], var_e)))
          return false;
      return true;
    };
    block8.guard = matches10;
    block8.real = function(var_e) {
      setModuleName("tryExceptional");
      setLineNumber(8);    // compilenode num
      Grace_print(new GraceNum(4));
      return GraceDone;
    };
    cases1.push(block8);
    setLineNumber(4);    // compiletrycatch
    var catchres1 = tryCatch(block2,cases1,false);
    setModuleName("tryExceptional");
    setLineNumber(3);    // compilenode op
    var opresult12 = request(var_String, "|(1)", [1], var_Done);
    setLineNumber(4);    // typecheck
    assertTypeOrMsg(catchres1, opresult12, "result of method tryExceptional", "String | Done");
    return catchres1;
  };    // end of method tryExceptional
  this.methods["tryExceptional"] = func0;
  func0.paramCounts = [0];
  func0.paramNames = [];
  func0.typeParamNames = [];
  func0.definitionLine = 3;
  func0.definitionModule = "tryExceptional";
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_tryExceptional = gracecode_tryExceptional;
if (typeof window !== "undefined")
  window.gracecode_tryExceptional = gracecode_tryExceptional;
gracecode_tryExceptional.imports = ["StaticTyping"];
