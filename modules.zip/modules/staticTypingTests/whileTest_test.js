;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["whileTest_test"] = "classes:\nconfidential:\n x\n x:=(x': Number) \u2192 Done\ndialect:\n StaticTyping\nfresh-methods:\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/staticTypingTests/whileTest_test.grace\npublic:\npublicMethodTypes:\ntypes:\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["whileTest_test"] = [
    "dialect \"StaticTyping\"",
    "",
    "var x:Number := 0",
    "",
    "while {x < 3} do {",
    "    print(x)",
    "    x:= x + 1",
    "}" ];
}
function gracecode_whileTest__95__test() {
  setModuleName("whileTest_test");
  importedModules["whileTest_test"] = this;
  var module$whileTest__95__test = this;
  this.definitionModule = "whileTest_test";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_whileTest__95__test_0");
  this.outer_whileTest__95__test_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  setLineNumber(3);    // typecheck
  assertTypeOrMsg(new GraceNum(0), var_Number, "initial value of var x", "Number");
  var var_x = new GraceNum(0);
  var reader0_x = function() {  // reader method x
      if (var_x === undefined) raiseUninitializedVariable("x");
      return var_x;
  };
  reader0_x.isVar = true;
  reader0_x.confidential = true;
  this.methods["x"] = reader0_x;
  var writer1_x = function(argcv, n) {   // writer method x:=(_)
    assertTypeOrMsg(n, var_Number, "argument to x:=(_)", "Number");
    var_x = n;
    return GraceDone;
  };
  writer1_x.confidential = true;
  this.methods["x:=(1)"] = writer1_x;
  setLineNumber(5);    // compilenode block
  var block3 = new GraceBlock(this, 5, 0);
  var matches4 = function() {
    setModuleName("whileTest_test");
    return true;
  };
  block3.guard = matches4;
  block3.real = function() {
    setModuleName("whileTest_test");
    setLineNumber(5);    // compilenode op
    if (var_x === undefined) raiseUninitializedVariable("x");
    var opresult5 = request(var_x, "<(1)", [1], new GraceNum(3));
    return opresult5;
  };
  var block6 = new GraceBlock(this, 5, 0);
  var matches7 = function() {
    setModuleName("whileTest_test");
    return true;
  };
  block6.guard = matches7;
  block6.real = function() {
    setModuleName("whileTest_test");
    setLineNumber(6);    // compilenode call
    if (var_x === undefined) raiseUninitializedVariable("x");
    Grace_print(var_x);
    setLineNumber(7);    // compilenode op
    if (var_x === undefined) raiseUninitializedVariable("x");
    var sum8 = request(var_x, "+(1)", [1], new GraceNum(1));
    var_x = sum8;
    return GraceDone;
  };
  // call case 2: outer request
  var call2 = selfRequest(var_prelude, "while(1)do(1)", [1, 1], block3, block6);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_whileTest__95__test = gracecode_whileTest__95__test;
if (typeof window !== "undefined")
  window.gracecode_whileTest__95__test = gracecode_whileTest__95__test;
gracecode_whileTest__95__test.imports = ["StaticTyping"];
