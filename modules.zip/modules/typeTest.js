;"use strict";
var___95__prelude = do_import("standardGrace", gracecode_standardGrace);
if (typeof gctCache !== "undefined")
  gctCache["typeTest"] = "classes:\nconfidential:\n firstPerson\n secondPerson\n superMan\ndialect:\n StaticTyping\nfresh-methods:\n personNamed(1)\n superNamed(1)\nfresh:personNamed(1):\n greet(1)\nfresh:superNamed(1):\n fly\n giveBirth\n greet(1)\nmodules:\n ObjectTypeModule\n ScopeModule\n SharedTypes\n StaticTyping\n ast\n collectionsPrelude\n errormessages\n identifierKinds\n io\n lexer\n mirrors\n parser\n parser2\n standardGrace\n stringMap\n sys\n unicode\n unixFilePath\n util\n xmodule\npath:\n /Users/irenazracoskun/Desktop/minigrace/modules/typeTest.grace\npublic:\n Person\n Superman\n personNamed(1)\n superNamed(1)\npublicMethod:personNamed(1):\n personNamed(nameVal:String) \u2192 Person\npublicMethod:superNamed(1):\n superNamed(nameVal:String) \u2192 Superman\npublicMethodTypes:\n personNamed(nameVal:String) \u2192 Person\n superNamed(nameVal:String) \u2192 Superman\ntypedec-of:Person:\n type Person = interface {\n            greet(name:String) \u2192 Done}\ntypedec-of:Superman:\n type Superman = interface {\n            greet(name:String) \u2192 Done\n            fly \u2192 Done\n            giveBirth \u2192 Person}\ntypes:\n Person\n Superman\n";
if (typeof originalSourceLines !== "undefined") {
  originalSourceLines["typeTest"] = [
    "dialect \"StaticTyping\"",
    "",
    "",
    "type Person = {",
    "    greet (name: String) -> Done ",
    "}",
    "",
    "type Superman = {",
    "    greet (name:String) -> Done",
    "    fly -> Done",
    "    giveBirth -> Person",
    "}",
    "",
    "",
    "",
    "class personNamed (nameVal: String)  -> Person {",
    "    ",
    "    method greet (name: String) -> Done {",
    "        print (\"Hello there, {name}. My name is {nameVal}.\")",
    "    }",
    "}",
    "",
    "class superNamed (nameVal: String)  -> Superman {",
    "    method greet (name: String) -> Done {",
    "        print (\"Hello there, {name}. My name is {nameVal}.\")",
    "    }",
    "",
    "    method fly -> Done {",
    "        print (\"Flying\")",
    "    }",
    "",
    "    method giveBirth -> Person {",
    "        return personNamed (\"baby\")",
    "    }",
    "}",
    "",
    "",
    "",
    "",
    "def firstPerson: Person= personNamed (\"Shezad\") ",
    "",
    "def secondPerson: Person = personNamed(\"Charles\") ",
    "",
    "def superMan: Superman = superNamed (\"Iren\")",
    "",
    "firstPerson.greet(\"Pauvle\")",
    "superMan.fly",
    "superMan.giveBirth" ];
}
function gracecode_typeTest() {
  setModuleName("typeTest");
  importedModules["typeTest"] = this;
  var module$typeTest = this;
  this.definitionModule = "typeTest";
  this.definitionLine = 0;
  var var_prelude = var___95__prelude;
  this.closureKeys = this.closureKeys || [];
  this.closureKeys.push("outer_typeTest_0");
  this.outer_typeTest_0 = var_prelude;
  setLineNumber(1);    // compilenode dialect
  // Dialect "StaticTyping"
  var_prelude = do_import("StaticTyping", gracecode_StaticTyping);
  this.outer = var_prelude;
  var func0 = function(argcv, var_nameVal) {    // method personNamed(_), line 16
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_nameVal, var_String, "argument to request of `personNamed(_)`", "String");
    var ouc = emptyGraceObject("personNamed(_)", "typeTest", 16);
    var ouc_init = this.methods["personNamed(1)$build(3)"].call(this, null, var_nameVal, ouc, [], []);
    ouc_init.call(ouc);
    setLineNumber(25);    // typecheck
    assertTypeOrMsg(ouc, var_Person, "object returned from personNamed(_)", "Person");
    return ouc;
  };    // end of method personNamed(_)
  func0.paramTypes = [];
  func0.paramTypes.push([type_String, "nameVal"]);
  this.methods["personNamed(1)"] = func0;
  func0.paramCounts = [1];
  func0.paramNames = ["nameVal"];
  func0.typeParamNames = [];
  func0.definitionLine = 16;
  func0.definitionModule = "typeTest";
  var func1 = function(argcv, var_nameVal, inheritingObject, aliases, exclusions) {    // method personNamed(_)$build(_,_,_), line 16
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_nameVal, var_String, "argument to request of `personNamed(_)`", "String");
    var obj2_build = function(ignore, var_nameVal, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_typeTest_16");
      this.outer_typeTest_16 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func3 = function(argcv, var_name) {    // method greet(_), line 18
        var returnTarget = invocationCount;
        invocationCount++;
        assertTypeOrMsg(var_name, var_String, "argument to request of `greet(_)`", "String");
        setModuleName("typeTest");
        setLineNumber(19);    // compilenode string
        var string4 = new GraceString("Hello there, ");
        var opresult5 = request(string4, "++(1)", [1], var_name);
        var string6 = new GraceString(". My name is ");
        var opresult7 = request(opresult5, "++(1)", [1], string6);
        var opresult8 = request(opresult7, "++(1)", [1], var_nameVal);
        var string9 = new GraceString(".");
        var opresult10 = request(opresult8, "++(1)", [1], string9);
        Grace_print(opresult10);
        return GraceDone;
      };    // end of method greet(_)
      func3.paramTypes = [];
      func3.paramTypes.push([type_String, "name"]);
      this.methods["greet(1)"] = func3;
      func3.paramCounts = [1];
      func3.paramNames = ["name"];
      func3.typeParamNames = [];
      func3.definitionLine = 18;
      func3.definitionModule = "typeTest";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj2_init = function() {    // init of object on line 16
        setModuleName("typeTest");
      };
      return obj2_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj2_init = obj2_build.call(inheritingObject, null, var_nameVal, this, aliases, exclusions);
    return obj2_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method personNamed(_)$build(_,_,_)
  func1.paramTypes = [];
  func1.paramTypes.push([type_String, "nameVal"]);
  this.methods["personNamed(1)$build(3)"] = func1;
  func1.paramCounts = [1];
  func1.paramNames = ["nameVal"];
  func1.typeParamNames = [];
  func1.definitionLine = 16;
  func1.definitionModule = "typeTest";
  var func11 = function(argcv, var_nameVal) {    // method superNamed(_), line 23
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_nameVal, var_String, "argument to request of `superNamed(_)`", "String");
    var ouc = emptyGraceObject("superNamed(_)", "typeTest", 23);
    var ouc_init = this.methods["superNamed(1)$build(3)"].call(this, null, var_nameVal, ouc, [], []);
    ouc_init.call(ouc);
    assertTypeOrMsg(ouc, var_Superman, "object returned from superNamed(_)", "Superman");
    return ouc;
  };    // end of method superNamed(_)
  func11.paramTypes = [];
  func11.paramTypes.push([type_String, "nameVal"]);
  this.methods["superNamed(1)"] = func11;
  func11.paramCounts = [1];
  func11.paramNames = ["nameVal"];
  func11.typeParamNames = [];
  func11.definitionLine = 23;
  func11.definitionModule = "typeTest";
  var func12 = function(argcv, var_nameVal, inheritingObject, aliases, exclusions) {    // method superNamed(_)$build(_,_,_), line 23
    var returnTarget = invocationCount;
    invocationCount++;
    assertTypeOrMsg(var_nameVal, var_String, "argument to request of `superNamed(_)`", "String");
    var obj13_build = function(ignore, var_nameVal, outerObj, aliases, exclusions) {
      this.closureKeys = this.closureKeys || [];
      this.closureKeys.push("outer_typeTest_23");
      this.outer_typeTest_23 = outerObj;
      var inheritedExclusions = { };
      for (var eix = 0, eLen = exclusions.length; eix < eLen; eix ++) {
          var exMeth = exclusions[eix];
          inheritedExclusions[exMeth] = this.methods[exMeth];
      }
      var func14 = function(argcv, var_name) {    // method greet(_), line 24
        var returnTarget = invocationCount;
        invocationCount++;
        assertTypeOrMsg(var_name, var_String, "argument to request of `greet(_)`", "String");
        setModuleName("typeTest");
        setLineNumber(25);    // compilenode string
        var string15 = new GraceString("Hello there, ");
        var opresult16 = request(string15, "++(1)", [1], var_name);
        var string17 = new GraceString(". My name is ");
        var opresult18 = request(opresult16, "++(1)", [1], string17);
        var opresult19 = request(opresult18, "++(1)", [1], var_nameVal);
        var string20 = new GraceString(".");
        var opresult21 = request(opresult19, "++(1)", [1], string20);
        Grace_print(opresult21);
        return GraceDone;
      };    // end of method greet(_)
      func14.paramTypes = [];
      func14.paramTypes.push([type_String, "name"]);
      this.methods["greet(1)"] = func14;
      func14.paramCounts = [1];
      func14.paramNames = ["name"];
      func14.typeParamNames = [];
      func14.definitionLine = 24;
      func14.definitionModule = "typeTest";
      var func22 = function(argcv) {    // method fly, line 28
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("typeTest");
        setLineNumber(29);    // compilenode string
        var string23 = new GraceString("Flying");
        Grace_print(string23);
        return GraceDone;
      };    // end of method fly
      this.methods["fly"] = func22;
      func22.paramCounts = [0];
      func22.paramNames = [];
      func22.typeParamNames = [];
      func22.definitionLine = 28;
      func22.definitionModule = "typeTest";
      var func24 = function(argcv) {    // method giveBirth, line 32
        var returnTarget = invocationCount;
        invocationCount++;
        setModuleName("typeTest");
        setLineNumber(33);    // compilenode string
        var string26 = new GraceString("baby");
        // call case 2: outer request
        var call25 = selfRequest(importedModules["typeTest"], "personNamed(1)", [1], string26);
        assertTypeOrMsg(call25, var_Person, "return value", "Person");
        return call25;
      };    // end of method giveBirth
      this.methods["giveBirth"] = func24;
      func24.paramCounts = [0];
      func24.paramNames = [];
      func24.typeParamNames = [];
      func24.definitionLine = 32;
      func24.definitionModule = "typeTest";
      for (var aix = 0, aLen = aliases.length; aix < aLen; aix++) {
          var oneAlias = aliases[aix];
          this.methods[oneAlias.newName] = this.methods[oneAlias.oldName];
      }
      for (var exName in inheritedExclusions) {
          if (inheritedExclusions.hasOwnProperty(exName)) {
              if (inheritedExclusions[exName]) {
                  this.methods[exName] = inheritedExclusions[exName];
              } else {
                  delete this.methods[exName];
              }
          }
      }
      var obj13_init = function() {    // init of object on line 23
        setModuleName("typeTest");
      };
      return obj13_init;   // from compileBuildAndInitFunctions(_)inMethod(_)
    };
    var obj13_init = obj13_build.call(inheritingObject, null, var_nameVal, this, aliases, exclusions);
    return obj13_init;      // from compileBuildMethodFor(_)withObjCon(_)inside(_)
  };    // end of method superNamed(_)$build(_,_,_)
  func12.paramTypes = [];
  func12.paramTypes.push([type_String, "nameVal"]);
  this.methods["superNamed(1)$build(3)"] = func12;
  func12.paramCounts = [1];
  func12.paramNames = ["nameVal"];
  func12.typeParamNames = [];
  func12.definitionLine = 23;
  func12.definitionModule = "typeTest";
  setLineNumber(4);    // compilenode typedec
  // Type decl Person
  //   Type literal 
  var typeLit28 = new GraceType("Person");
  typeLit28.typeMethods.push("greet(1)");
  var var_Person = typeLit28;
  var type27 = typeLit28;
  var func29 = function(argcv) {     // accessor method Person
    return var_Person;
  };    // end of method Person
  this.methods["Person"] = func29;
  func29.paramCounts = [0];
  func29.paramNames = [];
  func29.typeParamNames = [];
  func29.definitionLine = 1;
  func29.definitionModule = "typeTest";
  setLineNumber(8);    // compilenode typedec
  // Type decl Superman
  //   Type literal 
  var typeLit31 = new GraceType("Superman");
  typeLit31.typeMethods.push("greet(1)");
  typeLit31.typeMethods.push("fly");
  typeLit31.typeMethods.push("giveBirth");
  var var_Superman = typeLit31;
  var type30 = typeLit31;
  var func32 = function(argcv) {     // accessor method Superman
    return var_Superman;
  };    // end of method Superman
  this.methods["Superman"] = func32;
  func32.paramCounts = [0];
  func32.paramNames = [];
  func32.typeParamNames = [];
  func32.definitionLine = 1;
  func32.definitionModule = "typeTest";
  setLineNumber(40);    // compilenode string
  var string34 = new GraceString("Shezad");
  // call case 2: outer request
  var call33 = selfRequest(importedModules["typeTest"], "personNamed(1)", [1], string34);
  var var_firstPerson = call33;
  var reader35_firstPerson = function() {  // reader method firstPerson
      if (var_firstPerson === undefined) raiseUninitializedVariable("firstPerson");
      return var_firstPerson;
  };
  reader35_firstPerson.isDef = true;
  reader35_firstPerson.confidential = true;
  this.methods["firstPerson"] = reader35_firstPerson;
  assertTypeOrMsg(var_firstPerson, var_Person, "value of def firstPerson", "Person");
  setLineNumber(42);    // compilenode string
  var string37 = new GraceString("Charles");
  // call case 2: outer request
  var call36 = selfRequest(importedModules["typeTest"], "personNamed(1)", [1], string37);
  var var_secondPerson = call36;
  var reader38_secondPerson = function() {  // reader method secondPerson
      if (var_secondPerson === undefined) raiseUninitializedVariable("secondPerson");
      return var_secondPerson;
  };
  reader38_secondPerson.isDef = true;
  reader38_secondPerson.confidential = true;
  this.methods["secondPerson"] = reader38_secondPerson;
  assertTypeOrMsg(var_secondPerson, var_Person, "value of def secondPerson", "Person");
  setLineNumber(44);    // compilenode string
  var string40 = new GraceString("Iren");
  // call case 2: outer request
  var call39 = selfRequest(importedModules["typeTest"], "superNamed(1)", [1], string40);
  var var_superMan = call39;
  var reader41_superMan = function() {  // reader method superMan
      if (var_superMan === undefined) raiseUninitializedVariable("superMan");
      return var_superMan;
  };
  reader41_superMan.isDef = true;
  reader41_superMan.confidential = true;
  this.methods["superMan"] = reader41_superMan;
  assertTypeOrMsg(var_superMan, var_Superman, "value of def superMan", "Superman");
  setLineNumber(46);    // compilenode string
  var string43 = new GraceString("Pauvle");
  // call case 6: other requests
  if (var_firstPerson === undefined) raiseUninitializedVariable("firstPerson");
  var call42 = request(var_firstPerson, "greet(1)", [1], string43);
  setLineNumber(47);    // compilenode member
  // call case 6: other requests
  if (var_superMan === undefined) raiseUninitializedVariable("superMan");
  var call44 = request(var_superMan, "fly", [0]);
  setLineNumber(48);    // compilenode member
  // call case 6: other requests
  if (var_superMan === undefined) raiseUninitializedVariable("superMan");
  var call45 = request(var_superMan, "giveBirth", [0]);
  return this;
}
if (typeof global !== "undefined")
  global.gracecode_typeTest = gracecode_typeTest;
if (typeof window !== "undefined")
  window.gracecode_typeTest = gracecode_typeTest;
gracecode_typeTest.imports = ["StaticTyping"];
